<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'brizapp_WPUEK');

/** MySQL database username */
define('DB_USER', 'brizapp_WPUEK');

/** MySQL database password */
define('DB_PASSWORD', '1oZahhOIHOZahlVw2');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', '317bcaae941c22c6d81e3306b634834d28c327316af32a4ca2319ba74da150a5');
define('SECURE_AUTH_KEY', '4d577cc37ea77274b00916da37e5aae8052e66d8c66f00ca418015f488c5c97b');
define('LOGGED_IN_KEY', '94eb619a7d78126b1c1e69a5f2e3c8c76b1d78d218c95defda4526a0871460b9');
define('NONCE_KEY', '41d141b71406bfffc66a4c881734e7356ee6c770fc7afe903106cff15b662211');
define('AUTH_SALT', '93152c082feabac27c23daa249dd3b12865b2d1522737b785f34f7f9f23a03f5');
define('SECURE_AUTH_SALT', 'fdc3255aae1832ca0afdd905bda7ba2a983545419982bc45c75155e09ca4ac0f');
define('LOGGED_IN_SALT', '0ce732bb3afd379df5dacc0c8179165fbcc2001953b29b66179cfaed15fdc72c');
define('NONCE_SALT', 'b1fc6aec1b99401e63b4de7af7a2ac670adde79fed9081a02ad0a8c74aeca9cb');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'briz_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

define( 'WP_CRON_LOCK_TIMEOUT', 120   ); 
define( 'AUTOSAVE_INTERVAL',    300   );
define( 'WP_POST_REVISIONS',    5     );
define( 'EMPTY_TRASH_DAYS',     7     );
define( 'WP_AUTO_UPDATE_CORE',  true  );


