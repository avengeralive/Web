<?php
// Heading
$_['heading_title']        = 'Партнерcкий раздел';

// Text
$_['text_account']         = 'Кабинет партнера';
$_['text_my_account']      = 'Моя учетная запись';
$_['text_my_tracking']     = 'Мои рефералы';
$_['text_my_transactions'] = 'История выплат';
$_['text_edit']            = 'Редактировать учетную запись';
$_['text_password']        = 'Изменить пароль';
$_['text_payment']         = 'Изменить платежные реквизиты';
$_['text_tracking']        = 'Реферальный код';
$_['text_transaction']     = 'Посмотреть историю выплат';
