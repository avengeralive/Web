<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'btour_site' );

/** MySQL database username */
define( 'DB_USER', 'btour_site' );

/** MySQL database password */
define( 'DB_PASSWORD', 'PZJnC7skNcrvg2ju' );

/** MySQL hostname */
define( 'DB_HOST', 'btour.mysql' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '0-v|{yCNzg=ghbQWdPWSdI0q9NW?A74LB@DR{60kLIx2Q|XDBdGx[A4H6}+A36^@' );
define( 'SECURE_AUTH_KEY',  'm::HFoD;.OtQ.I0#R7<n[&3EYq/yMWn8m)Jvdo;cs}b3+=4<A-nc2OzVmpv{m`6&' );
define( 'LOGGED_IN_KEY',    '9/2qdwqTyOTUR]f3q!`ii_2V^]TnwTln%-;#cF)%RndX9cx>Hz~*g@q}7[E`Ob/0' );
define( 'NONCE_KEY',        'P%3=|JOnDQ~N@vjN)mFe;fT=CZ~[YZpI4*K>Z}UMM!f)oEgm1=YVS?}2u=0kkFGu' );
define( 'AUTH_SALT',        '|sdj585W0;]Qgt?`#[2F0QgGa_(w&>SqTTw[8!!aqNG.9XzX-`XG$KQq438jy]2m' );
define( 'SECURE_AUTH_SALT', '#MJW{p6V1L*PM1V3Wp_eR14,x7_~PPh-y4e]zR$H> ]R)^{$Vl?U[k6sR4/ek,+?' );
define( 'LOGGED_IN_SALT',   '?#@ngn&[}C1(QIuz]mvU}]XWT&tc-Sax{$d(9]*84r{nC%Skc/gWq@~ uk0.{(Sj' );
define( 'NONCE_SALT',       ';NZ&#^8cHm/C9`ubqnc%c /q~t=c%~EjpY/Z%)rE-d![u.Q_]Z%dJ~pp!bV0<sVL' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'bt_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
