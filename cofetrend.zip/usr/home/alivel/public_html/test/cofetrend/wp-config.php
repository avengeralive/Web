<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'hostingdata');

/** MySQL database username */
define('DB_USER', 'hostingdata');

/** MySQL database password */
define('DB_PASSWORD', 'gDdRtUh9Tf3eRBiz');

/** MySQL hostname */
define('DB_HOST', 'sql439.your-server.de');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ':Ngqy.SZwzqeK87<rsS81sH=7IzDCd#ri ~)+nGV6jOR{Gw2KeM%O1#i/tUj{N*S');
define('SECURE_AUTH_KEY',  'Xj9cIo<X~e5]xI[SCtyf+/Jg72}vj>R#og63]m?_=cM-4d$yQvmM#`~xQN9o}p[]');
define('LOGGED_IN_KEY',    'r)O&G&_Z[O4Rr~}t4|gd1Y9mk5ZWct+ -{7)8h>JDBDtn.$KmZ`D*>^WPV,j:i@[');
define('NONCE_KEY',        '|$T:0:Lw=kCuC!5Vzwv<&9=U hFGWvt>Q=:gtrH3p75)%Z&BdO=:lWZ[]+N @*2d');
define('AUTH_SALT',        'Ttv=[%v@.H)OO*K.Q !g[a:I$`cvcs2eh(%=n,n>+oj<):kOm5(+SeZAqVp#*j~4');
define('SECURE_AUTH_SALT', 'x2_r7JFqRck+1w0,rj?X2i{ijBZP{*maYk5MP2gTA]VRLiRN^76 E_{DphdeqaG|');
define('LOGGED_IN_SALT',   'I:n id.~oW-mfZ5Ff4xcs[ytCb)+S++Q7m+RpR X}yAs-*tv-%~D@zk 6`})5_G5');
define('NONCE_SALT',       'YY=UBbzV X%`7?2%a5 iAP.f(*h-I$m3Mc@Ej`zI0,w%a+@Dt=o+T|)Slv*9sO c');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'ct_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
