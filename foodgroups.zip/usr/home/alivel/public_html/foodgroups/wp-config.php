<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'hostingdata');

/** MySQL database username */
define('DB_USER', 'hostingdata');

/** MySQL database password */
define('DB_PASSWORD', 'gDdRtUh9Tf3eRBiz');

/** MySQL hostname */
define('DB_HOST', 'sql439.your-server.de');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'i]@n^xC_Og:@v gApp!S!C+Nii%B+]e*aNNEP.crH{HGL|f~5!+3a8[Z:7U+MSF4');
define('SECURE_AUTH_KEY',  'G~1^*8,tr{d&0:s}6!,CtT*FK*b89]^,bZmerK+xy[Rk8P mA@A3NougJi^HDr0k');
define('LOGGED_IN_KEY',    'cG7opTZ6_N*g+:Ed.dP?cKva|`6KX#UB<s_H>PR:duk9^A@XK.YB(DcuYk5i;ZJc');
define('NONCE_KEY',        '7l^;p[u3E-zf29y`hK+%} Qg*,=&{k@QQca[XNi /hlJM*z c]u+%tCHZ%k3pFOI');
define('AUTH_SALT',        '`H1KZz2iAHog!x!x0#p#Ry;n5q)UU4(X:$,gfZ&U eC|(r5jI$mq8KMkoSC?p{St');
define('SECURE_AUTH_SALT', 'hx]==47y-S5HISm,^Bh,hjqQT>beZ0SPe-0HCke>]}jsb]lY=5o#?41+8Tia?lz@');
define('LOGGED_IN_SALT',   '~wDKM9:(r #Akv2tq.|JJTlw:.E[1p(IWE@5D: .yQuI1Y8r+$a45H*rmn]})%0S');
define('NONCE_SALT',       ';2H-xZrRT<S<(t}><bD[.yxBmF13*rUv22Mu2qskE<2L|BttlJzutr>xO89:c*3o');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'fg_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
