exec "./cards"
