<?php
class DATABASE_CONFIG {

	public $default = array(
		'datasource' => 'Database/Mysql',
		'persistent' => false,
		'host' => 'localhost',
		'login' => 'andrbu_lvse',
		'password' => '4T38$@=C0b))',
		'database' => 'andrbu_lvse',
		'prefix' => '',
		'encoding' => 'utf8',
	);
}

