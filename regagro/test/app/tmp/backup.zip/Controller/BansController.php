<?php
// app/Controller/BansController.php

class BansController extends AppController {

	public $components = array('RequestHandler', 'Paginator');
	public $helpers = array(
		'Html' => array('className' => 'BoostCake.BoostCakeHtml'),
		'Form' => array('className' => 'BoostCake.BoostCakeForm'),
		'Paginator' => array('className' => 'BoostCake.BoostCakePaginator'),
	);
	
	public function beforeFilter() {
		parent::beforeFilter();
		if (in_array($this->Auth->user('role'),  array('Сотрудник','Администратор'))) {
			$this->Auth->allow('index', 'add', 'edit', 'delete');
		}
		
		if (!$this->Auth->user('lab_id') || $this->Auth->user('lab_id')==0) {
			$this->Session->setFlash('Вы не можете заполнять журнал, т.к. не числитесь в лаборатории.', 'alert', array(
				'plugin' => 'BoostCake',
				'class' => 'alert-danger'
			), 'danger');
			$this->redirect('/');
		}
		
		if(in_array($this->action, array('edit','delete'))) {
			$this->Ban->id = $this->request->params['pass'][0];
			$ban = $this->Ban->read();
			$lab = $ban['Registration']['lab_id'];
			//$lab = $this->Ban->Registration->field('lab_id');
			if ($this->Auth->user('lab_id')!=$lab)
			{
				$this->Session->setFlash('Вы не можете работать с чужим журналом.', 'alert', array(
				'plugin' => 'BoostCake',
				'class' => 'alert-danger'
				), 'danger');
				$this->redirect('/');
			}
		}
		
		//запрет на правку данных за прошедшие дни
		if($this->Auth->user('role')!='Администратор' && in_array($this->action, array(/*'add', 'edit',*/ 'delete'))) {
			$registration_id=0;
			$registration_id = ($this->action=='add'?$this->request->params['pass'][0]:$this->Ban->field('registration_id', array('id'=>$this->request->params['pass'][0])));
			$reg_date = $this->Ban->Registration->field('date', array('id'=>$registration_id));
			if($reg_date<date('Y-m-d')){
				$this->Session->setFlash('Вы не можете править или удалять данные за прошедшие дни.', 'alert', array(
				'plugin' => 'BoostCake',
				'class' => 'alert-danger'
				), 'danger');
				$this->redirect($this->referer());
			}
		}
	}
	
	public function isAuthorized($user) {
		if (isset($user['role']) && in_array($user['role'], array('Администратор','Сотрудник'))) {
            return true;
        }
    
        return parent::isAuthorized($user);
    }
	
	public function beforeRender() {
		if ($this->Auth->user('role') === 'Администратор') {
			$this->userActions[] = array('title'=>'Справочники','url'=>Router::url(array('controller'=>'pages','action'=>'lists')));
		}
		if (in_array($this->Auth->user('role'),  array('Сотрудник','Администратор'))) {
			$this->userActions[] = array('title'=>'Журнал','url'=>Router::url(array('controller'=>'registrations','action'=>'index')));
		}
		parent::beforeRender();
	}
	
	public function add($registration_id=null) {
		$this->set('title_for_layout', 'Добавление снятия с реализации');
		
		if (in_array($this->Auth->user('role'),  array('Сотрудник','Администратор'))) {
			$this->userActions[] = array('title'=>'Запись в журнале','url'=>Router::url(array('controller'=>'registrations','action'=>'overview', $registration_id)));
		}

		if (!$registration_id) {
			throw new NotFoundException("Несуществующая запись в журнале");
		}
		
		$registration = $this->Ban->Registration->findById($registration_id);
		if (!$registration) {
			throw new NotFoundException("Несуществующая запись журнале");
		}
		
		$this->request->data['Ban']['registration_id'] = $registration_id;
        if ($this->request->is('post')) {
            $this->Ban->create();
            if ($this->Ban->save($this->request->data)) {
				$this->Session->setFlash('Запись добавлена.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-success'
				), 'success');
				//$this->redirect($this->referer());
				$this->redirect(array('controller'=>'registrations', 'action'=>'overview', $registration_id));
			} else {
				$this->Session->setFlash('Ошибки заполнения формы.'/*.print_r($this->Ban->validationErrors, true)*/, 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-danger'
				), 'success');
			}
		}
		$productions = $this->Ban->Production->find('list',
													array('conditions'=>array(
														'production_type_id'=>$registration['Registration']['production_type_id'],
														'id IN (SELECT production_id FROM expertises WHERE registration_id='.$registration['Registration']['id'].')'
													)));
		$this->set(compact('productions'));
		$banTypes = $this->Ban->BanType->find('list', array(
										'conditions'=>array('BanTypesProductionTypes.production_type_id'=>$registration['Registration']['production_type_id']),
										'joins'=>array(
													array(
														'type'=>'inner',
														'table'=>'ban_types_production_types',
														'alias'=>'BanTypesProductionTypes',
														'conditions'=>array(
															'BanTypesProductionTypes.ban_type_id = BanType.id'
														)
													))));
		$this->set(compact('banTypes'));
		$banReasons = $this->Ban->BanReason->find('list', array(
										'conditions'=>array('BanReasonsProductionTypes.production_type_id'=>$registration['Registration']['production_type_id']),
										'joins'=>array(
													array(
														'type'=>'inner',
														'table'=>'ban_reasons_production_types',
														'alias'=>'BanReasonsProductionTypes',
														'conditions'=>array(
															'BanReasonsProductionTypes.ban_reason_id = BanReason.id'
														)
													))));
		$this->set(compact('banReasons'));
		$useOrders = $this->Ban->UseOrder->find('list');
		$this->set(compact('useOrders'));
		$expertises = $this->Ban->Expertise->find('list', array('conditions'=>array('Expertise.registration_id'=>$registration['Registration']['id'])));
		$this->set(compact('expertises'));
		$this->set(compact('registration'));
		//$this->render('edit');
	}
	
	public function edit($id=null) {
		$this->set('title_for_layout', 'Редактирование снятия с реализации');
		if (!$id) {
			throw new NotFoundException("Несуществующая запись");
		}
		
		$ban = $this->Ban->findById($id);
		if (!$ban) {
			throw new NotFoundException("Несуществующая запись");
		}
		
		if (!$this->request->data) {
			$this->request->data = $ban;
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			$this->Ban->id = $id;
            if ($this->Ban->save($this->request->data)) {
				$this->Session->setFlash('Запись изменена.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-success'
				), 'success');
				$this->redirect(array('controller'=>'registrations', 'action'=>'overview', $ban['Ban']['registration_id']));
			} else {
				$this->Session->setFlash('Не удалось сохранить изменения.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-danger'
				), 'danger');
			}
		}
		
		$productions = $this->Ban->Production->find('list',
													array('conditions'=>array(
														'production_type_id'=>$ban['Registration']['production_type_id'],
														'id IN (SELECT production_id FROM expertises WHERE registration_id='.$ban['Registration']['id'].')'
													)));
		$this->set(compact('productions'));
		$banTypes = $this->Ban->BanType->find('list', array(
										'conditions'=>array('BanTypesProductionTypes.production_type_id'=>$ban['Registration']['production_type_id']),
										'joins'=>array(
													array(
														'type'=>'inner',
														'table'=>'ban_types_production_types',
														'alias'=>'BanTypesProductionTypes',
														'conditions'=>array(
															'BanTypesProductionTypes.ban_type_id = BanType.id'
														)
													))));
		$this->set(compact('banTypes'));
		$banReasons = $this->Ban->BanReason->find('list', array(
										'conditions'=>array('BanReasonsProductionTypes.production_type_id'=>$ban['Registration']['production_type_id']),
										'joins'=>array(
													array(
														'type'=>'inner',
														'table'=>'ban_reasons_production_types',
														'alias'=>'BanReasonsProductionTypes',
														'conditions'=>array(
															'BanReasonsProductionTypes.ban_reason_id = BanReason.id'
														)
													))));
		$this->set(compact('banReasons'));
		$useOrders = $this->Ban->UseOrder->find('list');
		$this->set(compact('useOrders'));
		$expertises = $this->Ban->Expertise->find('list', array('conditions'=>array('Expertise.registration_id'=>$ban['Registration']['id'])));
		$this->set(compact('expertises'));

		$this->set('ban', $ban);
	}
	
	public function index() {
		$this->Paginator->settings = array(
			'limit' => 30,
			'order' => array('Ban.id'=>'asc')
		);
		$bans = $this->Paginator->paginate('Ban');
		$this->set('bans', $bans);
	}
	
	public function delete($id) {
		if ($this->Ban->delete($id)) {
			$this->Session->setFlash('Запись с ИД '.$id.' удалена.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-success'
				), 'success');
			return $this->redirect($this->referer());
		}
	}
}
?>