<?php
// app/Controller/ExpertisesController.php

class ExpertisesController extends AppController {

	public $components = array('RequestHandler', 'Paginator');
	public $helpers = array(
		'Html' => array('className' => 'BoostCake.BoostCakeHtml'),
		'Form' => array('className' => 'BoostCake.BoostCakeForm'),
		'Paginator' => array('className' => 'BoostCake.BoostCakePaginator'),
	);
	
	public function beforeFilter() {
		parent::beforeFilter();
		if (in_array($this->Auth->user('role'),  array('Сотрудник','Администратор'))) {
			$this->Auth->allow('*');
		}
		
		if (!$this->Auth->user('lab_id') || $this->Auth->user('lab_id')==0) {
			$this->Session->setFlash('Вы не можете заполнять журнал, т.к. не числитесь в лаборатории.', 'alert', array(
				'plugin' => 'BoostCake',
				'class' => 'alert-danger'
			), 'danger');
			$this->redirect('/');
		}
		
		if(in_array($this->action, array('edit','delete'))) {
			$this->Expertise->id = $this->request->params['pass'][0];
			$expertise = $this->Expertise->read();
			$lab = $expertise['Registration']['lab_id'];
			//$lab = $this->Expertise->Registration->field('lab_id');
			if ($this->Auth->user('lab_id')!=$lab)
			{
				$this->Session->setFlash('Вы не можете работать с чужим журналом.', 'alert', array(
				'plugin' => 'BoostCake',
				'class' => 'alert-danger'
				), 'danger');
				$this->redirect('/');
			}
		}
		
		//запрет на правку данных за прошедшие дни
		if($this->Auth->user('role')!='Администратор' && in_array($this->action, array('add', 'edit', 'delete'))) {
			$registration_id=0;
			$registration_id = ($this->action=='add'?$this->request->params['pass'][0]:$this->Expertise->field('registration_id', array('id'=>$this->request->params['pass'][0])));
			$reg_date = $this->Expertise->Registration->field('date', array('id'=>$registration_id));
			if($reg_date<date('Y-m-d')){
				$this->Session->setFlash('Вы не можете править или удалять данные за прошедшие дни.', 'alert', array(
				'plugin' => 'BoostCake',
				'class' => 'alert-danger'
				), 'danger');
				$this->redirect($this->referer());
			}
		}
	}
	
	public function isAuthorized($user) {
		if (isset($user['role']) && in_array($user['role'], array('Администратор','Сотрудник'))) {
            return true;
        }
    
        return parent::isAuthorized($user);
    }
	
	public function beforeRender() {
		if ($this->Auth->user('role') === 'Администратор') {
			$this->userActions[] = array('title'=>'Справочники','url'=>Router::url(array('controller'=>'pages','action'=>'lists')));
		}
		if (in_array($this->Auth->user('role'),  array('Сотрудник','Администратор'))) {
			$this->userActions[] = array('title'=>'Журнал','url'=>Router::url(array('controller'=>'registrations','action'=>'index')));
		}
		parent::beforeRender();
	}
	
	public function add($registration_id=null) {
		$this->set('title_for_layout', 'Добавление экспертизы');
		
		if (in_array($this->Auth->user('role'),  array('Сотрудник','Администратор'))) {
			$this->userActions[] = array('title'=>'Запись в журнале','url'=>Router::url(array('controller'=>'registrations','action'=>'overview', $registration_id)));
		}

		if (!$registration_id) {
			throw new NotFoundException("Несуществующая запись в журнале");
		}
		
		$registration = $this->Expertise->Registration->findById($registration_id);
		if (!$registration) {
			throw new NotFoundException("Несуществующая запись журнале");
		}
		
		$this->request->data['Expertise']['registration_id'] = $registration_id;
        if ($this->request->is('post')) {
            $this->Expertise->create();
            if ($this->Expertise->save($this->request->data)) {
				$this->Session->setFlash('Запись добавлена.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-success'
				), 'success');
				$this->redirect(array('controller'=>'registrations', 'action'=>'overview', $registration_id));
			} else {
				$this->Session->setFlash('Ошибки заполнения формы.'/*.print_r($this->Expertise->validationErrors,true)*/, 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-danger'
				), 'success');
			}
		}
		$productions = $this->Expertise->Production->find('list', array('conditions'=>array('production_type_id'=>$registration['Registration']['production_type_id'])));
		$this->set(compact('productions'));
		$detections = $this->Expertise->Detection->find('list', array(
										'conditions'=>array('DetectionsProductionTypes.production_type_id'=>$registration['Registration']['production_type_id']),
										'joins'=>array(
													array(
														'type'=>'inner',
														'table'=>'detections_production_types',
														'alias'=>'DetectionsProductionTypes',
														'conditions'=>array(
															'DetectionsProductionTypes.detection_id = Detection.id'
														)
													))));
		$this->set(compact('detections'));
		$conclusions = $this->Expertise->Conclusion->find('list');
		$this->set(compact('conclusions'));
		
		$this->set(compact('registration'));
		//$this->render('edit');
	}
	
	public function edit($id=null) {
		$this->set('title_for_layout', 'Редактирование экспертизы');
		if (!$id) {
			throw new NotFoundException("Несуществующая запись");
		}
		
		$expertise = $this->Expertise->findById($id);
		if (!$expertise) {
			throw new NotFoundException("Несуществующая запись");
		}

		if (!$this->request->data) {
			$this->request->data = $expertise;
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			$this->Expertise->id = $id;
            if ($this->Expertise->save($this->request->data)) {
				$this->Session->setFlash('Запись изменена.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-success'
				), 'success');
				$this->redirect(array('controller'=>'registrations', 'action'=>'overview', $expertise['Expertise']['registration_id']));
			} else {
				$this->Session->setFlash('Не удалось сохранить изменения.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-danger'
				), 'danger');
			}
		}
		
		$productions = $this->Expertise->Production->find('list', array('conditions'=>array('production_type_id'=>$expertise['Registration']['production_type_id'])));
		$this->set(compact('productions'));
		$detections = $this->Expertise->Detection->find('list', array(
										'conditions'=>array('DetectionsProductionTypes.production_type_id'=>$expertise['Registration']['production_type_id']),
										'joins'=>array(
													array(
														'type'=>'inner',
														'table'=>'detections_production_types',
														'alias'=>'DetectionsProductionTypes',
														'conditions'=>array(
															'DetectionsProductionTypes.detection_id = Detection.id'
														)
													))));
		$this->set(compact('detections'));
		$conclusions = $this->Expertise->Conclusion->find('list');
		$this->set(compact('conclusions'));

		
		$this->set('expertise', $expertise);
	}
	
	public function index() {
		$this->Paginator->settings = array(
			'limit' => 30,
			'order' => array('Expertise.id'=>'asc')
		);
		$expertises = $this->Paginator->paginate('Expertise');
		$this->set('expertises', $expertises);
	}
	
	public function delete($id) {
		if ($this->Expertise->delete($id, true)) {
			$this->Session->setFlash('Запись с ИД '.$id.' удалена.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-success'
				), 'success');
			return $this->redirect($this->referer());
		}
	}
}
?>