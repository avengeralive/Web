<?php
// app/Controller/LabsController.php

class LabsController extends AppController {

	public $components = array('RequestHandler', 'Paginator');
	public $helpers = array(
		'Html' => array('className' => 'BoostCake.BoostCakeHtml'),
		'Form' => array('className' => 'BoostCake.BoostCakeForm'),
		'Paginator' => array('className' => 'BoostCake.BoostCakePaginator'),
	);
	
	public function beforeRender() {
		if ($this->Auth->user('role') === 'Администратор') {
			$this->userActions[] = array('title'=>'Справочники','url'=>Router::url(array('controller'=>'pages','action'=>'lists')));
		}
		
		parent::beforeRender();
	}
	
	public function beforeFilter() {
		parent::beforeFilter();
		if (in_array($this->Auth->user('role'),  array('Сотрудник','Администратор'))) {
			$this->Auth->allow('getByInstitution');
		}
	}
    
    public function getByInstitution() {
		$institution_id = $this->request->data['institution_id'];
		
		if ($institution_id=='all')
		{
			if (in_array($this->Auth->user('role'), array('Администратор'))) {
				$labs = $this->Lab->find('all');
				$labs = array_merge(array(array('Lab'=>array('id'=>'all','name'=>'все'))), $labs);
			} else if ($this->Auth->user('organ_id')&&$this->Auth->user('organ_id')!=0) {
				$labs = $this->Lab->find('all', 
									array('conditions'=>array('Lab.institution_id IN (SELECT id FROM institutions WHERE organ_id='.$this->Auth->user('organ_id').')'))
								);
				$labs = array_merge(array(array('Lab'=>array('id'=>'all','name'=>'все'))), $labs);
			} else if ($this->Auth->user('institution_id')&&$this->Auth->user('institution_id')!=0) {
				$labs = $this->Lab->find('all', 
									array('conditions'=>array('Lab.institution_id'=>$this->Auth->user('institution_id')))
								);
				$labs = array_merge(array(array('Lab'=>array('id'=>'all','name'=>'все'))), $labs);
			} else {
				$lab_id = $this->Auth->user('lab_id');
				$labs = $this->Lab->find('all', array('conditions'=>array('Lab.id'=>$lab_id)));
			}
		} else 
		{
			if($this->request->params['ext']=='json'){
				$labs = $this->Lab->find('all', array(
					'conditions' => array('Lab.institution_id' => $institution_id)
					));
				$labs = array_merge(array(array('Lab'=>array('id'=>'all','name'=>'все'))), $labs);
			} else {
				$labs = $this->Lab->find('list', array(
					'conditions' => array('Lab.institution_id' => $institution_id),
					'recursive' => -1
					));
				//$labs = array('all'=>'все') + $labs;
				$labs = array_merge(array('all'=>'все'), $labs);
			}
		}
		$this->set('labs', $labs);
		$this->layout = 'ajax';
	}
	
	public function add() {
		$this->set('title_for_layout', 'Добавление новой лаборатории');
        if ($this->request->is('post')) {
            $this->Lab->create();
            if ($this->Lab->save($this->request->data)) {
				$this->Session->setFlash('Запись добавлена.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-success'
				), 'success');
				$this->redirect(array('action' => 'index'));
			}
		}
		$regions = $this->Lab->Region->find('list');
		$this->set(compact('regions'));
		$institutions = $this->Lab->Institution->find('list');
		$this->set(compact('institutions'));
		$this->render('edit');
	}
	
	public function edit($id=null) {
		$this->set('title_for_layout', 'Редактирование лаборатории');
		if (!$id) {
			throw new NotFoundException("Несуществующая запись");
		}
		
		$lab = $this->Lab->findById($id);
		if (!$lab) {
			throw new NotFoundException("Несуществующая запись");
		}
		
		if (!$this->request->data) {
			$this->request->data = $lab;
		}
		
		if ($this->request->is('post') || $this->request->is('put')) {
			$this->Lab->id = $id;
            if ($this->Lab->save($this->request->data)) {
				$this->Session->setFlash('Запись изменена.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-success'
				), 'success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash('Не удалось сохранить изменения.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-danger'
				), 'danger');
			}
		}
		
		$regions = $this->Lab->Region->find('list');
		$this->set(compact('regions'));
		$institutions = $this->Lab->Institution->find('list');
		$this->set(compact('institutions'));
		$this->set('lab', $lab);
	}
	
	public function index() {
		$this->Paginator->settings = array(
			'limit' => 30,
			'order' => array('Lab.name'=>'asc')
		);
		// $regions = $this->Lab->Region->find('list');
		// $this->set(compact('regions'));
		$labs = $this->Paginator->paginate('Lab');
		$this->set('labs', $labs);
	}
	
	public function delete($id) {
		if ($this->Lab->delete($id)) {
			$this->Session->setFlash('Запись с ИД '.$id.' удалена.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-success'
				), 'success');
			return $this->redirect(array('action' => 'index'));
		}
	}
}
?>