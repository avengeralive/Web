<?php
// app/Controller/RegistrationsController.php
class RegistrationsController extends AppController {

	public $components = array('RequestHandler', 'Paginator');
	public $helpers = array('Js', 'Number',
		'Html' => array('className' => 'BoostCake.BoostCakeHtml'),
		'Form' => array('className' => 'BoostCake.BoostCakeForm'),
		'Paginator' => array('className' => 'BoostCake.BoostCakePaginator'),
	);
	
	public function beforeFilter() {
		$this->set('title_for_layout', 'Журнал');
		parent::beforeFilter();
		if (in_array($this->Auth->user('role'),  array('Сотрудник','Администратор'))) {
			//$this->Auth->allow('index', 'add', 'edit', 'delete', 'overview');
			$this->Auth->allow('*');
		}
		
		if (!$this->Auth->user()) {
			$this->Session->setFlash('Вы не авторизовались в системе.', 'alert', array(
				'plugin' => 'BoostCake',
				'class' => 'alert-danger'
			), 'danger');
			$this->redirect(array('controller'=>'users', 'action'=>'login'));
		}
		$hasLab = ($this->Auth->user('lab_id') || $this->Auth->user('lab_id')!=0);
		$hasInstitution = ($this->Auth->user('institution_id') || $this->Auth->user('institution_id')!=0);
		$hasOrgan = ($this->Auth->user('organ_id') || $this->Auth->user('organ_id')!=0);
		$lookingReports = !(strpos($this->action,'vet5')===false)||($this->action=='reports')||($this->action=='expertises_prices');
		if (
			!($hasLab||($lookingReports&&($hasInstitution||$hasOrgan)))
		   )
		{
			$this->Session->setFlash('Вы не можете заполнять журнал, т.к. не числитесь в лаборатории.', 'alert', array(
				'plugin' => 'BoostCake',
				'class' => 'alert-danger'
			), 'danger');
			$this->redirect('/');
		}
		
		if(in_array($this->action, array('overview','edit','delete'))) {
			$this->Registration->id = $this->request->params['pass'][0];
			$lab = $this->Registration->field('lab_id');
			if ($this->Auth->user('lab_id')!=$lab)
			{
				$this->Session->setFlash('Вы не можете работать с чужим журналом.', 'alert', array(
				'plugin' => 'BoostCake',
				'class' => 'alert-danger'
				), 'danger');
				$this->redirect('/');
			}
		}
	}
	
	public function isAuthorized($user) {
		if (isset($user['role']) && in_array($user['role'], array('Администратор','Сотрудник'))) {
            return true;
        }
    
        return parent::isAuthorized($user);
    }
	
	public function beforeRender() {
		
		if ($this->Auth->user('role') === 'Администратор') {
			$this->userActions[] = array('title'=>'Справочники','url'=>Router::url(array('controller'=>'pages','action'=>'lists')));
		}
		if (in_array($this->Auth->user('role'),  array('Сотрудник','Администратор'))) {
			$this->userActions[] = array('title'=>'Журнал','url'=>Router::url(array('controller'=>'registrations','action'=>'index')));
			$this->userActions[] = array('title'=>'Отчеты','url'=>Router::url(array('controller'=>'registrations','action'=>'reports')));
		}

		parent::beforeRender();
	}
	
	public function overview($id=null) {
	
		$this->userActions[] = array('title'=>'Редактировать запись','url'=>Router::url(array('controller'=>'registrations','action'=>'edit', $id)));
		
		if (!$id) {
			throw new NotFoundException("Несуществующая запись");
		}
		$this->Registration->recursive=3;
		$registration = $this->Registration->findById($id);
		if (!$registration) {
			throw new NotFoundException("Несуществующая запись");
		}
		
		
		$this->set('registration', $registration);
	}
	
	public function add() {
		$this->set('title_for_layout', 'Добавление новой записи в журнал');
        if ($this->request->is('post')) {
            $this->Registration->create();
            if ($this->Registration->save($this->request->data)) {
				$this->Session->setFlash('Запись добавлена.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-success'
				), 'success');
				$this->redirect(array('action' => 'index'));
			}
		}
		
		$productionTypes = $this->Registration->ProductionType->find('list');
		$this->set(compact('productionTypes'));
		
		$users = $this->Registration->User->find('list', array('conditions'=>array('id'=>$this->Auth->user('id'))));
		$this->set(compact('users'));

		$labs = $this->Registration->Lab->find('list', array('conditions'=>array('id'=>$this->Auth->user('lab_id'))));
		$this->set(compact('labs'));
		
		$regions = $this->Registration->Region->find('list');
		$this->set(compact('regions'));
		
		//$districts = $this->Registration->District->find('list');
		//$this->set(compact('districts'));
	}
	
	public function edit($id=null) {
		$this->set('title_for_layout', 'Редактирование записи в журнале');
		if (!$id) {
			throw new NotFoundException("Несуществующая запись");
		}
		
		$registration = $this->Registration->findById($id);
		if (!$registration) {
			throw new NotFoundException("Несуществующая запись");
		}
		
		if (!$this->request->data) {
			$this->request->data = $registration;
		}
		
		if ($this->request->is('post') || $this->request->is('put')) {
			$this->Registration->id = $id;
            if ($this->Registration->save($this->request->data)) {
				$this->Session->setFlash('Запись изменена.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-success'
				), 'success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash('Не удалось сохранить изменения.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-danger'
				), 'danger');
			}
		}

		$productionTypes = $this->Registration->ProductionType->find('list');
		$this->set(compact('productionTypes'));
		
		$users = $this->Registration->User->find('list', array('conditions'=>array('id'=>$this->Auth->user('id'))));
		$this->set(compact('users'));

		$labs = $this->Registration->Lab->find('list', array('conditions'=>array('id'=>$this->Auth->user('lab_id'))));
		$this->set(compact('labs'));
		
		$regions = $this->Registration->Region->find('list');
		$this->set(compact('regions'));
		
		$districts = $this->Registration->District->find('list', array('conditions'=>array('region_id'=>$this->request->data['Registration']['region_id'])));
		$this->set(compact('districts'));
		
		$this->set('registration', $registration);
	}
	
	public function index() {
		$this->userActions[] = array('title'=>'Добавить запись','url'=>Router::url(array('controller'=>'registrations','action'=>'add')));

		$this->Paginator->settings = array(
			'conditions' => array('Registration.lab_id'=>$this->Auth->user('lab_id')),
			'limit' => 30,
			'order' =>  array('Registration.code'=>'DESC')
		);
		$registrations = $this->Paginator->paginate('Registration');
		$this->set('registrations', $registrations);
	}
	
	public function delete($id=null) {
		if (!$id) {
			throw new NotFoundException("Несуществующая запись");
		}
		if ($this->Registration->delete($id)) {
			$this->Session->setFlash('Запись в журнале с ИД '.$id.' удален.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-success'
				), 'success');
			$this->redirect($this->referer());
		}
	}
	
	public function ban_doc($id = null)	{
		Configure::write('debug', 0);
		$this->layout = null;
		$this->Registration->recursive=3;
		if (!$id) {
			throw new NotFoundException("Несуществующая запись");
		}
		
		$registration = $this->Registration->findById($id);
		if (!$registration) {
			throw new NotFoundException("Несуществующая запись");
		}
		
		//$date = date_format(date_create($registration['Registration']['date']),'Y-m-d 00:00:00');
		$date = date('Y-m-d 00:00:00');
		$bans = $this->Registration->Ban->find('all', array('conditions'=>array('Registration.id'=>$id,
																				'Ban.modified > \''.$date.'\'',
																				'Ban.modified < \''.date_format(date_create($date),'Y-m-d 23:59:59').'\'')));
		if (!$bans) {
			throw new NotFoundException("За сегодня нет снятой с реализации продукции в этой экспертизе");
		}
		$this->set(compact('registration'));
		$this->set(compact('bans'));
	}
	
	public function daily_registrations_doc($date = null) {
		$date = $date?$date:date('Y-m-d');
		Configure::write('debug', 0);
		$this->layout = null;
		$this->Registration->recursive=3;
		$registrations = $this->Registration->find('all', array('conditions'=>
																array(
																	'date'=>$date,
																	'Registration.lab_id'=>$this->Auth->user('lab_id')
																),
																'order'=>'Registration.production_type_id'
																));
		if (!$registrations) {
			throw new NotFoundException('Не найдены записи за текущую дату.');
		}
		
		$this->set(compact('registrations'));
		$this->set(compact('date'));
	}
	//$production_type: 'meat_fish' - это 'мясо, рыба'; 'other' - это пищевые продукты
	public function denaturation_doc($production_type = 'meat_fish', $date = null)	{
		$production_type = in_array($production_type, array('meat_fish','other'))?$production_type:'meat_fish';
		$date = $date?$date:date('Y-m-d');
		//Configure::write('debug', 0);
		$this->Registration->Expertise->recursive=2;
		$this->layout = null;
		$this->Registration->unbindModel(array('belongsTo' => array('ProductionType', 'Region', 'District')));
		$this->Registration->unbindModel(array('hasMany' => array('Expertise','Research', 'Ban', 'Sample', 'Distribution')));
		$this->Registration->Expertise->unbindModel(array('belongsTo' => array('Conclusion')));
		$this->Registration->Expertise->unbindModel(array('hasAndBelongsToMany' => array('Detection')));
		$this->Registration->Expertise->unbindModel(array('hasMany' => array('Research', 'Ban', 'Sample', 'Distribution')));
		//Мясо и мясопродукты production_type_id=1
		//Рыба морская production_type_id=5
		//Рыба речная production_type_id=23
		$prod_type_condition = 'Expertise.production_id '.($production_type=='meat_fish'?'IN':'NOT IN').' (SELECT id FROM productions WHERE production_type_id IN (1,5,23))';
		$expertises = $this->Registration->Expertise->find('all', array('conditions'=>array(
																		$prod_type_condition,
																		'DATE(Registration.date)'=>$date,
																		'Registration.lab_id'=>$this->Auth->user('lab_id')
																	),
																	'order'=>'Production.production_type_id'
																)
															);
		$this->set(compact('expertises'));
		$this->set('user',$this->Auth->user());
		$lab = $this->Registration->Lab->findById($this->Auth->user('lab_id'));
		$this->set(compact('lab'));
		$this->set(compact('date'));
		$this->set('denaturation_action', $production_type=='meat_fish'?'уничтожению':'утилизации');
		$this->set('production_type', $production_type=='meat_fish'?'мясо, рыба':'пищевые продукты');
	}
	
	public function daily_registrations_xml($date = null) {
		$date = $date?$date:date('Y-m-d');
		Configure::write('debug', 0);
		$this->layout = null;
		$this->Registration->recursive=3;
		$registrations = $this->Registration->find('all', array('conditions'=>
																array(
																	'DATE(Registration.date)'=>$date,
																	'Registration.lab_id'=>$this->Auth->user('lab_id')
																),
																'order'=>'Registration.production_type_id'
																));
		if (!$registrations) {
			throw new NotFoundException('Не найдены записи за текущую дату.');
		}
		
		$modified_bans = $this->Registration->Ban->find('all', array('conditions'=>array('Ban.modified > \''.$date.'\'',
																						 'Ban.modified < \''.date_format(date_create($date),'Y-m-d 23:59:59').'\'',
																						 'Registration.date < \''.date_format(date_create($date),'Y-m-d 00:00:00').'\'')));
		$this->set(compact('modified_bans'));
		$this->set(compact('registrations'));
		$this->set(compact('date'));
	}
	
	public function distributor_doc($id=null, $name = null, $type = 0) {
		if (!$name) {
			throw new NotFoundException("Не указано имя торгующего");
		}
		if (!$id) {
			throw new NotFoundException("Несуществующая запись в журнале");
		}
		
		Configure::write('debug', 0);
		$this->layout = null;
		$this->Registration->recursive=2;
		$this->Registration->bindModel(
			array('hasMany' => array(
						'Distribution' => array(
							'className' => 'Distribution',
							'conditions' => array('Distribution.distributor'=>$name)
						)
					)
				)
			);
		$this->Registration->unbindModel(array('belongsTo' => array('ProductionType', 'Region', 'District')));
		$this->Registration->unbindModel(array('hasMany' => array('Expertise','Research', 'Ban', 'Sample')));
		$registration = $this->Registration->findById($id);
		if (!$registration) {
			throw new NotFoundException('Не найдены записи c указанным торгующим.');
		}

		$this->set(compact('registration'));
		$this->set('name',$name);
		$this->set('type',$type);
	}
	
	public function sample_doc($id=null, $sample_id = null) {
		if (!$sample_id) {
			throw new NotFoundException("Не указан отбор пробы");
		}
		if (!$id) {
			throw new NotFoundException("Несуществующая запись в журнале");
		}
		
		Configure::write('debug', 0);
		$this->layout = null;
		$this->Registration->recursive=3;
		$this->Registration->bindModel(
			array('hasMany' => array(
						'Sample' => array(
							'className' => 'Sample',
							'conditions' => array('Sample.id'=>$sample_id)
						)
					)
				)
			);
		$this->Registration->unbindModel(array('belongsTo' => array('ProductionType')));
		$this->Registration->unbindModel(array('hasMany' => array('Expertise', 'Research', 'Ban', 'Distribution')));
		$this->Registration->Sample->unbindModel(array('belongsTo' => array('Registration')));
		$this->Registration->Region->unbindModel(array('hasMany' => array('District')));
		$registration = $this->Registration->findById($id);
		if (!$registration['Sample']) {
			throw new NotFoundException("Указанный отбор пробы не найден.");
		}
		if (!$registration) {
			throw new NotFoundException('Не найдены записи c указанным торгующим.');
		}
		
		$this->set(compact('registration'));
	}
	
	public function sample_act_doc($id=null, $sample_id = null) {
		if (!$sample_id) {
			throw new NotFoundException("Не указан отбор пробы");
		}
		if (!$id) {
			throw new NotFoundException("Несуществующая запись в журнале");
		}
		
		//Configure::write('debug', 0);
		$this->layout = null;
		$this->Registration->recursive=3;
		$this->Registration->bindModel(
			array('hasMany' => array(
						'Sample' => array(
							'className' => 'Sample',
							'conditions' => array('Sample.id'=>$sample_id)
						)
					)
				)
			);
		$this->Registration->unbindModel(array('belongsTo' => array('ProductionType')));
		$this->Registration->unbindModel(array('hasMany' => array('Expertise', 'Research', 'Ban', 'Distribution')));
		$this->Registration->Sample->unbindModel(array('belongsTo' => array('Registration')));
		$this->Registration->Region->unbindModel(array('hasMany' => array('District')));
		$registration = $this->Registration->findById($id);
		if (!$registration['Sample']) {
			throw new NotFoundException("Указанный отбор пробы не найден.");
		}
		if (!$registration) {
			throw new NotFoundException('Не найдены записи c указанным торгующим.');
		}
		
		$this->set(compact('registration'));
	}
	
	public function reports() {
		$this->set('title_for_layout', 'Отчеты');
		$this->LoadModel('Report');
		
		if ($this->request->is('post') || $this->request->is('put')) {
			if (!isset($this->request->data['Report']['lab_id']))
			{
				$this->request->data['Report']['lab_id'] = $this->Auth->user('lab_id');
			}
			$selectedInstitutionId = $this->request->data['Report']['institution_id'];
			$this->Report->set($this->request->data);
			if($this->Report->validates())
			{
				$this->set('data', $this->request->data);
			} else {
				$this->Session->setFlash('Ошибки заполнения формы.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-danger'
				), 'danger');
			}
		}
		
		if (in_array($this->Auth->user('role'), array('Администратор'))) {
            $institutions = $this->Registration->Lab->Institution->find('list');
            $institutions = array('all'=>'все') + $institutions;
			if (!isset($selectedInstitutionId)||$selectedInstitutionId=='all')
			{
				$labs = $this->Registration->Lab->find('list');
			} else 
			{
				$labs = $this->Registration->Lab->find('list', array('conditions'=>array('Lab.institution_id'=>$selectedInstitutionId)));
			}
			$labs = array('all'=>'все') + $labs;
		} else if ($this->Auth->user('organ_id')&&$this->Auth->user('organ_id')!=0) {
            $institutions = $this->Registration->Lab->Institution->find('list',
								array('conditions'=>array('organ_id'=>$this->Auth->user('organ_id')))
							);
            $institutions = array('all'=>'все') + $institutions;
			if (!isset($selectedInstitutionId)||$selectedInstitutionId=='all')
			{
				$labs = $this->Registration->Lab->find('list', 
								array('conditions'=>array('Lab.institution_id IN (SELECT id FROM institutions WHERE organ_id='.$this->Auth->user('organ_id').')'))
							);
			} else {
				$labs = $this->Registration->Lab->find('list', 
								array('conditions'=>array('Lab.institution_id=\''.$selectedInstitutionId.'\' 
															AND Lab.institution_id IN (SELECT id FROM institutions 
															WHERE organ_id='.$this->Auth->user('organ_id').')'))
							);
			}
			$labs = array('all'=>'все') + $labs;
			//$labs = array_merge(array('all'=>'все'), $labs);
		} else if ($this->Auth->user('institution_id')&&$this->Auth->user('institution_id')!=0) {
			$institutions = $this->Registration->Lab->Institution->find('list',
								array('conditions'=>array('Institution.id'=>$this->Auth->user('institution_id')))
							);
			$labs = $this->Registration->Lab->find('list', 
								array('conditions'=>array('Lab.institution_id'=>$this->Auth->user('institution_id')))
							);
			$labs = array('all'=>'все') + $labs;
		} else {
			$lab_id = $this->Auth->user('lab_id');
			$labs = $this->Registration->Lab->find('list', array('conditions'=>array('Lab.id'=>$lab_id)));
			$institutions = $this->Registration->Lab->Institution->find('list',
								array('conditions'=>array('Institution.id'=>$this->Auth->user('institution_id')))
							);
		}
		$this->set(compact('labs'));
		$this->set(compact('institutions'));
	}
	
	public function expertises_prices($institution_id=null, $lab_id=null, $date_from=null, $date_to=null){
		Configure::write('debug', 0);
		$this->layout = null;
		
		$lab_ids = $this->_getLabIds($institution_id, $lab_id);
		$this->_setVet5CommonData($institution_id, $lab_id);
		$this->set(compact('date_from'));
		$this->set(compact('date_to'));
		$this->Registration->Expertise->virtualFields['count'] = 0;
		$this->Registration->Expertise->virtualFields['price'] = 0;
		$data = $this->Registration->query('
		SELECT ProductionType.name, Production.name, Measure.name, SUM(Expertise.count) AS Expertise__count, SUM(Expertise.price) AS Expertise__price
		FROM production_types AS ProductionType,
			 expertises AS Expertise,
			 productions AS Production,
			 measures AS Measure,
			 registrations AS Registration
		WHERE ProductionType.id = Production.production_type_id
			AND Production.id = Expertise.production_id
			AND Registration.id = Expertise.registration_id
			AND Measure.id = Production.measure_id
			AND DATE(Registration.date) between \''.$date_from.'\' AND \''.$date_to.'\'
			AND Registration.lab_id IN ('.$lab_ids.')
		GROUP BY ProductionType.name, Production.name, Measure.name');
		
		$this->set(compact('data'));
	}
	
	// получаем id доступныx пользователю лабораторий
	// в зависимости от выбранных id учреждения и лаборатории
	public function _getLabIds($institution_id=null, $lab_id=null) {
		if ($lab_id && $lab_id!=0 && $lab_id!='all')
		{
			//если кто угодно выбрал свою лабораторию, то её и возвращаем
			if ($lab_id==$this->Auth->user('lab_id')) {
				return $lab_id;
			}
		
			//админ может выбрать любую лабораторию
			if ($this->Auth->user('role')=='Администратор') {
				return $lab_id;
			}
			
			//сотрудник учреждения
			if ($this->Auth->user('institution_id')&&$this->Auth->user('institution_id')!=0) {
				$labs = $this->Registration->Lab->find('all', array('conditions'=>array('Lab.institution_id'=>$this->Auth->user('institution_id'))) );
				if (in_array($lab_id, Set::extract('/Lab/id',$labs))) {
					return $lab_id;
				} else {
					return 0;
				}
			}
			
			//сотрудник органа управления
			if ($this->Auth->user('organ_id')&&$this->Auth->user('organ_id')!=0) {
				$labs = $this->Registration->Lab->find('all', array('conditions'=>array('Lab.institution_id IN (SELECT id FROM institutions WHERE organ_id='.$this->Auth->user('organ_id').')')) );
				if (in_array($lab_id, Set::extract('/Lab/id',$labs))) {
					return $lab_id;
				} else {
					return 0;
				}
			}
		}
		
		if ($institution_id == 'all' && $lab_id == 'all')//все учреждения
		{
			if ($this->Auth->user('role')=='Администратор') {
				$labs = $this->Registration->Lab->find('all');
				return implode(",",Set::extract('/Lab/id',$labs));
			}
			
			if ($this->Auth->user('organ_id')&&$this->Auth->user('organ_id')!=0) {
				$labs = $this->Registration->Lab->find('all', array('conditions'=>array('Lab.institution_id IN (SELECT id FROM institutions WHERE organ_id='.$this->Auth->user('organ_id').')')) );
				return implode(",",Set::extract('/Lab/id',$labs));
			}
			
			return 0;
		}
		
		if ($institution_id && $institution_id!=0 && $lab_id == 'all')//все лаборатории
		{
			if ($this->Auth->user('role')=='Администратор') {
				$labs = $this->Registration->Lab->find('all', array('conditions'=>array('Lab.institution_id'=>$institution_id)));
				return implode(",",Set::extract('/Lab/id',$labs));
			}
			
			if ($this->Auth->user('organ_id') && $this->Auth->user('organ_id')!=0) {
				$institutions = $this->Registration->Lab->Institution->find('all', array('conditions'=>array('organ_id'=>$this->Auth->user('organ_id'))) );
				if (in_array($institution_id, Set::extract('/Institution/id',$institutions))) {
					$labs = $this->Registration->Lab->find('all', array('conditions'=>array('Lab.institution_id'=>$institution_id)) );
					return implode(",",Set::extract('/Lab/id',$labs));
				} else {
					return 0;
				}
			}
			
			if ($this->Auth->user('institution_id') && $this->Auth->user('institution_id')!=0) {
				if ($institution_id == $this->Auth->user('institution_id')) {
					$labs = $this->Registration->Lab->find('all', array('conditions'=>array('Lab.institution_id'=>$institution_id)) );
					return implode(",",Set::extract('/Lab/id',$labs));
				} else {
					return 0;
				}
			}
			return 0;
		}
		return 0;
	}
	
	public function _setVet5CommonData($institution_id=null, $lab_id=null) {
		if ($institution_id=='all' && $lab_id=='all') {
			$org_type = 'Органа управления ветеринарии';
			$organ = $this->Registration->Lab->Institution->Organ->findById($this->Auth->user('organ_id'));
			$org_name = isset($organ['Organ']['name'])?$organ['Organ']['name']:'';
			$signer_job = '';
			$signer_name = '';
		} else if ($institution_id && $institution_id!=0 && $lab_id=='all') {
			$org_type = 'Учреждения ветеринарии';
			//$institution = $this->Registration->Lab->Institution->findById($this->Auth->user('institution_id'));
			$institution = $this->Registration->Lab->Institution->findById($institution_id);
			$org_name = $institution['Institution']['name'];
			$signer_job = '';
			$signer_name = '';
		} else if ($lab_id && $lab_id!=0 && $lab_id!='all') {
			$org_type = 'Лаборатории ветеринарно-санитарной экспертизы';
			$lab = $this->Registration->Lab->findById($lab_id);
			$org_name = $lab['Lab']['name'];
			$this->set('institution_name', $lab['Institution']['name']);
			$signer_job = 'Заведующий ЛВСЭ';
			//Заведующий ЛВСЭ job_id=2
			$signer_name = $this->Registration->query("SELECT displayname FROM users WHERE job_id=2 AND lab_id = ".$lab_id." LIMIT 1");
			$signer_name = $signer_name?$signer_name[0]['users']['displayname']:'Нет заведующего';
		}
		$this->set(compact('org_type'));
		$this->set(compact('org_name'));
		$this->set(compact('signer_job'));
		$this->set(compact('signer_name'));
		
	}	
	
	public function vet5_xml($institution_id=null, $lab_id=null, $date_from=null, $date_to=null) {
		$lab_id = $this->_getLabIds($institution_id, $lab_id);

		if (!$date_from||!$date_to) {
			throw new NotFoundException("Не указан период выборки для документа.");
		}
		//Configure::write('debug', 0);
		$this->layout = null;
		
		$data3_1_query = "
			SELECT ReportProduction.name, ReportResearch.name, SUM(Research.count) as count
			FROM researches as Research,
				 research_types as ResearchType,
				 report_researches as ReportResearch,
				 registrations as Registration,
				 report_productions as ReportProduction,
				 productions as Production
			WHERE Research.production_id IN (SELECT id FROM productions WHERE production_type_id IN (1,5,23)) 
				AND Production.id = Research.production_id
				AND ResearchType.id = Research.research_type_id
				AND ReportResearch.id = ResearchType.report_research_id
				AND ReportProduction.id = Production.report_production_id
				AND Research.registration_id=Registration.id
				AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
				AND Registration.lab_id IN (".$lab_id.")
				#AND Registration.industrial = 0
				AND (Registration.industrial = 0 OR Research.production_id IN (SELECT id FROM productions WHERE production_type_id IN (5,23)))
			Group BY ReportProduction.name, ReportResearch.name";
		$data3_1 = $this->Registration->query($data3_1_query);
		$flat = array();
 	    foreach ($data3_1 as $key => $value) {
	 	    $flat[mb_strtolower($data3_1[$key]['ReportResearch']['name'])][mb_strtolower($data3_1[$key]['ReportProduction']['name'])] = $data3_1[$key][0]['count'];
	    }
		$data3_1 = $flat;
		$this->set(compact('data3_1'));		
		
		// $totals3_1_query = "
			// SELECT ReportProduction.name, SUM(Research.count) as count
			// FROM researches as Research,
				 // research_types as ResearchType,
				 // report_researches as ReportResearch,
				 // registrations as Registration,
				 // report_productions as ReportProduction,
				 // productions as Production
			// WHERE Research.production_id IN (SELECT id FROM productions WHERE production_type_id IN (1,5,23)) 
				// AND Production.id = Research.production_id
				// AND ResearchType.id = Research.research_type_id
				// AND ReportResearch.id = ResearchType.report_research_id
				// AND ReportProduction.id = Production.report_production_id
				// AND Research.registration_id=Registration.id
				// AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
				// AND Registration.lab_id IN (".$lab_id.")
				// AND Registration.industrial = 0
			// Group BY ReportProduction.name";		
		$totals3_1_query = "
			SELECT ReportProduction.name, SUM(Expertise.count) as count
			FROM expertises as Expertise,
				 registrations as Registration,
				 report_productions as ReportProduction,
				 productions as Production
			WHERE Expertise.production_id IN (SELECT id FROM productions WHERE production_type_id IN (1,5,23)) 
				AND Production.id = Expertise.production_id
				AND ReportProduction.id = Production.report_production_id
				AND Expertise.registration_id=Registration.id
				AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
				AND Registration.lab_id IN (".$lab_id.")
				#AND Registration.industrial = 0
				AND (Registration.industrial = 0 OR Expertise.production_id IN (SELECT id FROM productions WHERE production_type_id IN (5,23)))
			Group BY ReportProduction.name";		
		$totals3_1 = $this->Registration->query($totals3_1_query);
		$flat = array();
 	    foreach ($totals3_1 as $key => $value) {
	 	    $flat[mb_strtolower($totals3_1[$key]['ReportProduction']['name'])]=$totals3_1[$key][0]['count'];
	    }
		$totals3_1 = $flat;
		$this->set(compact('totals3_1'));
		
		$totals3_2_query = "
			SELECT ReportProduction.name, SUM(Research.count) as count
			FROM researches as Research,
				 registrations as Registration,
				 report_productions as ReportProduction,
				 productions as Production
			WHERE Research.production_id IN (SELECT id FROM productions WHERE production_type_id IN (1,5,23)) 
				AND Production.id = Research.production_id
				AND ReportProduction.id = Production.report_production_id
				AND Research.registration_id=Registration.id
				AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
				AND Registration.lab_id IN (".$lab_id.")
				#AND Registration.industrial = 0
				AND (Registration.industrial = 0 OR Research.production_id IN (SELECT id FROM productions WHERE production_type_id IN (5,23)))
			Group BY ReportProduction.name";
		$totals3_2 = $this->Registration->query($totals3_2_query);
		$flat = array();
 	    foreach ($totals3_2 as $key => $value) {
	 	    $flat[mb_strtolower($totals3_2[$key]['ReportProduction']['name'])]=$totals3_2[$key][0]['count'];
	    }
		$totals3_2 = $flat;
		$this->set(compact('totals3_2'));
		
		$data3_3_query = "
		SELECT ReportProduction.name, ReportDetection.name, SUM(Expertise.count) as count #COUNT(Detection.id) as count
		FROM 
			registrations as Registration,
			report_productions as ReportProduction,
			productions as Production,
			detections as Detection,
			expertises_detections,
			report_detections as ReportDetection,
			expertises as Expertise
		WHERE Expertise.production_id IN (SELECT id FROM productions WHERE production_type_id IN (1,5,23)) 
			AND Production.id = Expertise.production_id
			AND ReportProduction.id = Production.report_production_id
			AND Expertise.registration_id=Registration.id
			AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
			AND Registration.lab_id IN (".$lab_id.")
			AND expertises_detections.expertise_id = Expertise.id
			AND Detection.id = expertises_detections.detection_id
			AND ReportDetection.id = Detection.report_detection_id
			#AND Registration.industrial = 0
			AND (Registration.industrial = 0 OR Expertise.production_id IN (SELECT id FROM productions WHERE production_type_id IN (5,23)))
		Group BY ReportProduction.name, ReportDetection.name";
		$data3_3 = $this->Registration->query($data3_3_query);
		$flat = array();
 	    foreach ($data3_3 as $key => $value) {
	 	    $flat[mb_strtolower($data3_3[$key]['ReportDetection']['name'])][mb_strtolower($data3_3[$key]['ReportProduction']['name'])] = $data3_3[$key][0]['count'];
	    }
		$data3_3 = $flat;
		$this->set(compact('data3_3'));
		
		$totals3_3_query = "
		SELECT ReportProduction.name, SUM(Expertise.count) as count #COUNT(Detection.id) as count
		FROM 
			registrations as Registration,
			report_productions as ReportProduction,
			productions as Production,
			expertises as Expertise,
			detections as Detection,
			expertises_detections
		WHERE Expertise.production_id IN (SELECT id FROM productions WHERE production_type_id IN (1,5,23)) 
			AND Production.id = Expertise.production_id
			AND ReportProduction.id = Production.report_production_id
			AND Expertise.registration_id=Registration.id
			AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
			AND Registration.lab_id IN (".$lab_id.")
			AND Registration.industrial = 0
			#AND (Registration.industrial = 0 OR Expertise.production_id IN (SELECT id FROM productions WHERE production_type_id IN (5,23)))
			AND expertises_detections.expertise_id = Expertise.id
			AND Detection.id = expertises_detections.detection_id
		Group BY ReportProduction.name";
		$totals3_3 = $this->Registration->query($totals3_3_query);
		$flat = array();
 	    foreach ($totals3_3 as $key => $value) {
	 	    $flat[mb_strtolower($totals3_3[$key]['ReportProduction']['name'])]=$totals3_3[$key][0]['count'];
	    }
		$totals3_3 = $flat;
		$this->set(compact('totals3_3'));
		
		$data3_4_query="
			SELECT ReportProduction.name, ReportBanReason.name, ROUND(SUM(Ban.weight)/1000,4) count
			FROM 
				registrations as Registration,
				report_productions as ReportProduction,
				productions as Production,
				ban_reasons as BanReason,
				report_ban_reasons as ReportBanReason,
				bans as Ban
			WHERE Ban.production_id IN (SELECT id FROM productions WHERE production_type_id IN (1,5,23)) 
				AND Production.id = Ban.production_id
				AND ReportProduction.id = Production.report_production_id
				AND Ban.registration_id=Registration.id
				AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
				AND Registration.lab_id IN (".$lab_id.")
				#AND Registration.industrial = 0
				AND (Registration.industrial = 0 OR Ban.production_id IN (SELECT id FROM productions WHERE production_type_id IN (5,23)))
				AND BanReason.id = Ban.ban_reason_id
				AND ReportBanReason.id = BanReason.report_ban_reason_id
				AND Ban.use_order_id = 3
				AND Ban.ban_type_id in (SELECT id from ban_types where report_ban_type_id=4)
			Group BY ReportProduction.name, ReportBanReason.name;";
		$data3_4 = $this->Registration->query($data3_4_query);
		$flat = array();
 	    foreach ($data3_4 as $key => $value) {
	 	    $flat[mb_strtolower($data3_4[$key]['ReportBanReason']['name'])][mb_strtolower($data3_4[$key]['ReportProduction']['name'])] = $data3_4[$key][0]['count'];
	    }
		$data3_4 = $flat;
		$this->set(compact('data3_4'));
		
		$totals3_4_query="
			SELECT ReportProduction.name, ROUND(SUM(Ban.weight)/1000,4) count
			FROM 
				registrations as Registration,
				report_productions as ReportProduction,
				productions as Production,
				bans as Ban
			WHERE Ban.production_id IN (SELECT id FROM productions WHERE production_type_id IN (1,5,23)) 
				AND Production.id = Ban.production_id
				AND ReportProduction.id = Production.report_production_id
				AND Ban.registration_id=Registration.id
				AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
				AND Registration.lab_id IN (".$lab_id.")
				#AND Registration.industrial = 0
				AND (Registration.industrial = 0 OR Ban.production_id IN (SELECT id FROM productions WHERE production_type_id IN (5,23)))
				AND Ban.use_order_id = 3
				AND Ban.ban_type_id in (SELECT id from ban_types where report_ban_type_id=4)
			Group BY ReportProduction.name;";
		$totals3_4 = $this->Registration->query($totals3_4_query);
		$flat = array();
 	    foreach ($totals3_4 as $key => $value) {
	 	    $flat[mb_strtolower($totals3_4[$key]['ReportProduction']['name'])]=$totals3_4[$key][0]['count'];
	    }
		$totals3_4 = $flat;
		$this->set(compact('totals3_4'));
		
		$data3_5_query="
			SELECT ReportProduction.name, ReportBanReason.name, ROUND(SUM(Ban.weight)/1000,4) count
			FROM 
				registrations as Registration,
				report_productions as ReportProduction,
				productions as Production,
				ban_reasons as BanReason,
				report_ban_reasons as ReportBanReason,
				bans as Ban
			WHERE Ban.production_id IN (SELECT id FROM productions WHERE production_type_id IN (1,5,23)) 
				AND Production.id = Ban.production_id
				AND ReportProduction.id = Production.report_production_id
				AND Ban.registration_id=Registration.id
				AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
				AND Registration.lab_id IN (".$lab_id.")
				#AND Registration.industrial = 0
				AND (Registration.industrial = 0 OR Ban.production_id IN (SELECT id FROM productions WHERE production_type_id IN (5,23)))
				AND BanReason.id = Ban.ban_reason_id
				AND ReportBanReason.id = BanReason.report_ban_reason_id
				AND Ban.use_order_id = 3
				AND Ban.ban_type_id in (SELECT id from ban_types where report_ban_type_id=5)
			Group BY ReportProduction.name, ReportBanReason.name;";
		$data3_5 = $this->Registration->query($data3_5_query);
		$flat = array();
 	    foreach ($data3_5 as $key => $value) {
	 	    $flat[mb_strtolower($data3_5[$key]['ReportBanReason']['name'])][mb_strtolower($data3_5[$key]['ReportProduction']['name'])] = $data3_5[$key][0]['count'];
	    }
		$data3_5 = $flat;
		$this->set(compact('data3_5'));
		
		$totals3_5_query="
			SELECT ReportProduction.name, ROUND(SUM(Ban.weight)/1000,4) count
			FROM 
				registrations as Registration,
				report_productions as ReportProduction,
				productions as Production,
				bans as Ban
			WHERE Ban.production_id IN (SELECT id FROM productions WHERE production_type_id IN (1,5,23)) 
				AND Production.id = Ban.production_id
				AND ReportProduction.id = Production.report_production_id
				AND Ban.registration_id=Registration.id
				AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
				AND Registration.lab_id IN (".$lab_id.")
				#AND Registration.industrial = 0
				AND (Registration.industrial = 0 OR Ban.production_id IN (SELECT id FROM productions WHERE production_type_id IN (5,23)))
				AND Ban.use_order_id = 3
				AND Ban.ban_type_id in (SELECT id from ban_types where report_ban_type_id=5)
			Group BY ReportProduction.name;";
		$totals3_5 = $this->Registration->query($totals3_5_query);
		$flat = array();
 	    foreach ($totals3_5 as $key => $value) {
	 	    $flat[mb_strtolower($totals3_5[$key]['ReportProduction']['name'])]=$totals3_5[$key][0]['count'];
	    }
		$totals3_5 = $flat;
		$this->set(compact('totals3_5'));
		
		//6. Направлено на утилизацию  мяса (тонн
		//use_order_id: 2-Возвращено владельцу, 4-Утилизация, 6-В корм животным
		$data3_6_query="
			SELECT ReportProduction.name, ReportBanReason.name, ROUND(SUM(Ban.weight)/1000,4) count
			FROM 
				registrations as Registration,
				report_productions as ReportProduction,
				productions as Production,
				ban_reasons as BanReason,
				report_ban_reasons as ReportBanReason,
				bans as Ban
			WHERE Ban.production_id IN (SELECT id FROM productions WHERE production_type_id IN (1,5,23)) 
				AND Production.id = Ban.production_id
				AND ReportProduction.id = Production.report_production_id
				AND Ban.registration_id=Registration.id
				AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
				AND Registration.lab_id IN (".$lab_id.")
				#AND Registration.industrial = 0
				AND (Registration.industrial = 0 OR Ban.production_id IN (SELECT id FROM productions WHERE production_type_id IN (5,23)))
				AND BanReason.id = Ban.ban_reason_id
				AND ReportBanReason.id = BanReason.report_ban_reason_id
				AND Ban.use_order_id IN (2,4,6)
				AND Ban.ban_type_id in (SELECT id from ban_types where report_ban_type_id=4)
			Group BY ReportProduction.name, ReportBanReason.name;";
		$data3_6 = $this->Registration->query($data3_6_query);
		$flat = array();
 	    foreach ($data3_6 as $key => $value) {
	 	    $flat[mb_strtolower($data3_6[$key]['ReportBanReason']['name'])][mb_strtolower($data3_6[$key]['ReportProduction']['name'])] = $data3_6[$key][0]['count'];
	    }
		$data3_6 = $flat;
		$this->set(compact('data3_6'));
		
		$totals3_6_query="
			SELECT ReportProduction.name, ROUND(SUM(Ban.weight)/1000,4) count
			FROM 
				registrations as Registration,
				report_productions as ReportProduction,
				productions as Production,
				bans as Ban
			WHERE Ban.production_id IN (SELECT id FROM productions WHERE production_type_id IN (1,5,23)) 
				AND Production.id = Ban.production_id
				AND ReportProduction.id = Production.report_production_id
				AND Ban.registration_id=Registration.id
				AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
				AND Registration.lab_id IN (".$lab_id.")
				#AND Registration.industrial = 0
				AND (Registration.industrial = 0 OR Ban.production_id IN (SELECT id FROM productions WHERE production_type_id IN (5,23)))
				AND Ban.use_order_id IN (2,4,6)
				AND Ban.ban_type_id in (SELECT id from ban_types where report_ban_type_id=4)
			Group BY ReportProduction.name;";
		$totals3_6 = $this->Registration->query($totals3_6_query);
		$flat = array();
 	    foreach ($totals3_6 as $key => $value) {
	 	    $flat[mb_strtolower($totals3_6[$key]['ReportProduction']['name'])]=$totals3_6[$key][0]['count'];
	    }
		$totals3_6 = $flat;
		$this->set(compact('totals3_6'));
		
		
		$data3_7_query="
			SELECT ReportProduction.name, ReportBanType.name, ROUND(SUM(Ban.weight)/1000,4) count
			FROM 
				registrations as Registration,
				report_productions as ReportProduction,
				productions as Production,
				ban_types as BanType,
				report_ban_types as ReportBanType,
				bans as Ban
			WHERE Ban.production_id IN (SELECT id FROM productions WHERE production_type_id IN (1,5,23)) 
				AND Production.id = Ban.production_id
				AND ReportProduction.id = Production.report_production_id
				AND Ban.registration_id=Registration.id
				AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
				AND Registration.lab_id IN (".$lab_id.")
				#AND Registration.industrial = 0
				AND (Registration.industrial = 0 OR Ban.production_id IN (SELECT id FROM productions WHERE production_type_id IN (5,23)))
				AND BanType.id = Ban.ban_type_id
				AND ReportBanType.id = BanType.report_ban_type_id
				AND Ban.use_order_id = 5
			Group BY ReportProduction.name, ReportBanType.name;";
		$data3_7 = $this->Registration->query($data3_7_query);
		$flat = array();
 	    foreach ($data3_7 as $key => $value) {
	 	    $flat[mb_strtolower($data3_7[$key]['ReportBanType']['name'])][mb_strtolower($data3_7[$key]['ReportProduction']['name'])] = $data3_7[$key][0]['count'];
	    }
		$data3_7 = $flat;
		$this->set(compact('data3_7'));
		
		$totals3_7_query="
			SELECT ReportProduction.name, ROUND(SUM(Ban.weight)/1000,4) count
			FROM 
				registrations as Registration,
				report_productions as ReportProduction,
				productions as Production,
				bans as Ban
			WHERE Ban.production_id IN (SELECT id FROM productions WHERE production_type_id IN (1,5,23)) 
				AND Production.id = Ban.production_id
				AND ReportProduction.id = Production.report_production_id
				AND Ban.registration_id=Registration.id
				AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
				AND Registration.lab_id IN (".$lab_id.")
				#AND Registration.industrial = 0
				AND (Registration.industrial = 0 OR Ban.production_id IN (SELECT id FROM productions WHERE production_type_id IN (5,23)))
				AND Ban.use_order_id = 5
			Group BY ReportProduction.name;";
		$totals3_7 = $this->Registration->query($totals3_7_query);
		$flat = array();
 	    foreach ($totals3_7 as $key => $value) {
	 	    $flat[mb_strtolower($totals3_7[$key]['ReportProduction']['name'])]=$totals3_7[$key][0]['count'];
	    }
		$totals3_7 = $flat;
		$this->set(compact('totals3_7'));
		
		// $totals4_1_query = "
			// SELECT (CASE WHEN Registration.industrial=1 THEN 'Другие пищевые продукты' ELSE ReportProduction.name END) production_name, SUM(Research.count) as count
			// FROM researches as Research,
				 // research_types as ResearchType,
				 // report_researches as ReportResearch,
				 // registrations as Registration,
				 // report_productions as ReportProduction,
				 // productions as Production
			// WHERE (Research.production_id IN (SELECT id FROM productions WHERE production_type_id NOT IN (1,5,23))
				// OR Registration.industrial=1)
				// AND Production.id = Research.production_id
				// AND ResearchType.id = Research.research_type_id
				// AND ReportResearch.id = ResearchType.report_research_id
				// AND ReportProduction.id = Production.report_production_id
				// AND Research.registration_id=Registration.id
				// AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
				// AND Registration.lab_id IN (".$lab_id.")
			// Group BY production_name";

		$totals4_1_query = "SELECT (CASE WHEN Registration.industrial=1 THEN 'Другие пищевые продукты' ELSE ReportProduction.name END) production_name, SUM(Expertise.count) as count
			FROM expertises as Expertise,
				 registrations as Registration,
				 report_productions as ReportProduction,
				 productions as Production
			WHERE Expertise.production_id IN (SELECT id FROM productions WHERE production_type_id NOT IN (1,5,23)) 
				AND Production.id = Expertise.production_id
				AND ReportProduction.id = Production.report_production_id
				AND Expertise.registration_id=Registration.id
				AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
				AND Registration.lab_id IN (".$lab_id.")
			Group BY ReportProduction.name";			
		$totals4_1 = $this->Registration->query($totals4_1_query);
		$flat = array();
 	    foreach ($totals4_1 as $key => $value) {
	 	    $flat[mb_strtolower($totals4_1[$key][0]['production_name'])]=$totals4_1[$key][0]['count'];
	    }
		$totals4_1 = $flat;
		$this->set(compact('totals4_1'));
		
		$totals4_2_query = "
			SELECT (CASE WHEN Registration.industrial=1 THEN 'Другие пищевые продукты' ELSE ReportProduction.name END) production_name, SUM(Research.count) as count
			FROM researches as Research,
				 research_types as ResearchType,
				 report_researches as ReportResearch,
				 registrations as Registration,
				 report_productions as ReportProduction,
				 productions as Production
			WHERE (Research.production_id IN (SELECT id FROM productions WHERE production_type_id NOT IN (1,5,23))
				OR Registration.industrial=1)
				AND Production.id = Research.production_id
				AND ResearchType.id = Research.research_type_id
				AND ReportResearch.id = ResearchType.report_research_id
				AND ReportProduction.id = Production.report_production_id
				AND Research.registration_id=Registration.id
				AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
				AND Registration.lab_id IN (".$lab_id.")
			Group BY production_name";
		$totals4_2 = $this->Registration->query($totals4_2_query);
		$flat = array();
 	    foreach ($totals4_2 as $key => $value) {
	 	    $flat[mb_strtolower($totals4_2[$key][0]['production_name'])]=$totals4_2[$key][0]['count'];
	    }
		$totals4_2 = $flat;
		$this->set(compact('totals4_2'));
		
		$totals4_3_query="
			SELECT (CASE WHEN Registration.industrial=1 THEN 'Другие пищевые продукты' ELSE ReportProduction.name END) production_name, ROUND(SUM(Ban.weight)/1000,4) count
			FROM 
				registrations as Registration,
				report_productions as ReportProduction,
				productions as Production,
				bans as Ban
			WHERE (Ban.production_id IN (SELECT id FROM productions WHERE production_type_id NOT IN (1,5,23))
				OR Registration.industrial=1)
				AND Production.id = Ban.production_id
				AND ReportProduction.id = Production.report_production_id
				AND Ban.registration_id=Registration.id
				AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
				AND Registration.lab_id IN (".$lab_id.")
				AND Ban.use_order_id = 3
			Group BY production_name";
		$totals4_3 = $this->Registration->query($totals4_3_query);
		$flat = array();
 	    foreach ($totals4_3 as $key => $value) {
	 	    $flat[mb_strtolower($totals4_3[$key][0]['production_name'])]=$totals4_3[$key][0]['count'];
	    }
		$totals4_3 = $flat;
		$this->set(compact('totals4_3'));

		$totals4_4_query="
			SELECT (CASE WHEN Registration.industrial=1 THEN 'Другие пищевые продукты' ELSE ReportProduction.name END) production_name, ROUND(SUM(Ban.weight)/1000,4) count
			FROM 
				registrations as Registration,
				report_productions as ReportProduction,
				productions as Production,
				bans as Ban
			WHERE (Ban.production_id IN (SELECT id FROM productions WHERE production_type_id NOT IN (1,5,23))
				OR Registration.industrial=1)
				AND Production.id = Ban.production_id
				AND ReportProduction.id = Production.report_production_id
				AND Ban.registration_id=Registration.id
				AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
				AND Registration.lab_id IN (".$lab_id.")
				AND Ban.use_order_id IN (2,4)
			Group BY production_name";
		$totals4_4 = $this->Registration->query($totals4_4_query);
		$flat = array();
 	    foreach ($totals4_4 as $key => $value) {
	 	    $flat[mb_strtolower($totals4_4[$key][0]['production_name'])]=$totals4_4[$key][0]['count'];
	    }
		$totals4_4 = $flat;
		$this->set(compact('totals4_4'));
		
		$totals4_5_query="
			SELECT (CASE WHEN Registration.industrial=1 THEN 'Другие пищевые продукты' ELSE ReportProduction.name END) production_name, ROUND(SUM(Ban.weight)/1000,4) count
			FROM 
				registrations as Registration,
				report_productions as ReportProduction,
				productions as Production,
				bans as Ban
			WHERE (Ban.production_id IN (SELECT id FROM productions WHERE production_type_id NOT IN (1,5,23))
				OR Registration.industrial=1)
				AND Production.id = Ban.production_id
				AND ReportProduction.id = Production.report_production_id
				AND Ban.registration_id=Registration.id
				AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
				AND Registration.lab_id IN (".$lab_id.")
				AND Ban.use_order_id = 5
			Group BY production_name";
		$totals4_5 = $this->Registration->query($totals4_5_query);
		$flat = array();
 	    foreach ($totals4_5 as $key => $value) {
	 	    $flat[mb_strtolower($totals4_5[$key][0]['production_name'])]=$totals4_5[$key][0]['count'];
	    }
		$totals4_5 = $flat;
		$this->set(compact('totals4_5'));
		
		$data4_6_query = "
			SELECT (CASE WHEN Registration.industrial=1 THEN 'Другие пищевые продукты' ELSE ReportProduction.name END) production_name, ReportResearch.name, SUM(Research.count) as count
			FROM researches as Research,
				 research_types as ResearchType,
				 report_researches as ReportResearch,
				 registrations as Registration,
				 report_productions as ReportProduction,
				 productions as Production
			WHERE (Research.production_id IN (SELECT id FROM productions WHERE production_type_id NOT IN (1,5,23)) 
				OR Registration.industrial=1)
				AND Production.id = Research.production_id
				AND ResearchType.id = Research.research_type_id
				AND ReportResearch.id = ResearchType.report_research_id
				AND ReportProduction.id = Production.report_production_id
				AND Research.registration_id=Registration.id
				AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
				AND Registration.lab_id IN (".$lab_id.")
			Group BY production_name, ReportResearch.name";
		$data4_6 = $this->Registration->query($data4_6_query);
		$flat = array();
 	    foreach ($data4_6 as $key => $value) {
	 	    $flat[mb_strtolower($data4_6[$key]['ReportResearch']['name'])][mb_strtolower($data4_6[$key][0]['production_name'])] = $data4_6[$key][0]['count'];
	    }
		$data4_6 = $flat;
		$this->set(compact('data4_6'));		
		
	}
	
	public function vet5_1_doc($institution_id=null, $lab_id=null, $date_from=null, $date_to=null) {		
		if (!$date_from||!$date_to) {
			throw new NotFoundException("Не указан период выборки для документа.");
		}
		Configure::write('debug', 0);
		$this->layout = null;
		
		$lab_ids = $this->_getLabIds($institution_id, $lab_id);
		$this->_setVet5CommonData($institution_id, $lab_id);
		$this->set(compact('date_from'));
		$this->set(compact('date_to'));
		//Другие виды животных report_production_id=6
		//Другие виды птицы report_production_id=8
		$other_animals_query = "
			SELECT Production.name, SUM(Expertise.count) as count
			FROM expertises AS Expertise, registrations AS Registration, productions as Production
			WHERE production_id IN (SELECT id FROM productions WHERE report_production_id=6)
			AND Expertise.registration_id=Registration.id
			AND Expertise.production_id=Production.id
			AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
			AND Registration.lab_id IN (".$lab_ids.")
			GROUP BY Production.name";
		$other_birds_query = "
			SELECT Production.name, SUM(Expertise.count) as count
			FROM expertises AS Expertise, registrations AS Registration, productions as Production
			WHERE production_id IN (SELECT id FROM productions WHERE report_production_id=8)
			AND Expertise.registration_id=Registration.id
			AND Expertise.production_id=Production.id
			AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
			AND Registration.lab_id IN (".$lab_ids.")
			AND Registration.industrial = 0
			GROUP BY Production.name";
		$other_animals = $this->Registration->query($other_animals_query);
		$other_birds = $this->Registration->query($other_birds_query);
		$this->set(compact('other_animals'));
		$this->set(compact('other_birds'));
	}
	
	public function vet5_2_xml($institution_id=null, $lab_id=null, $date_from=null, $date_to=null) {
		if (!$date_from||!$date_to) {
			throw new NotFoundException("Не указан период выборки для документа.");
		}
		Configure::write('debug', 0);
		$this->layout = null;
		
		$lab_ids = $this->_getLabIds($institution_id, $lab_id);
		$this->_setVet5CommonData($institution_id, $lab_id);
		$this->set(compact('date_from'));
		$this->set(compact('date_to'));
		
		//Мясо и мясопродукты production_type_id=1
		//Рыба морская production_type_id=5
		//Рыба речная production_type_id=23
		$data = $this->Registration->query("
		SELECT ReportProduction.name, ReportResearch.name, ResearchType.name, ResearchResult.name, SUM(Research.count) AS count
		FROM researches as Research,
			 research_types as ResearchType,
			 registrations as Registration,
			 productions as Production,
			 report_productions as ReportProduction,
			 report_researches as ReportResearch,
			 research_results as ResearchResult
		WHERE Research.production_id IN (SELECT id FROM productions WHERE production_type_id IN (1,5,23)) 
			AND Research.registration_id=Registration.id
			AND Production.id = Research.production_id
			AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
			AND Registration.lab_id IN (".$lab_ids.")
			AND ReportProduction.id = Production.report_production_id
			AND ResearchType.id = Research.research_type_id
			AND ReportResearch.id = ResearchType.report_research_id
			AND ResearchResult.id = Research.research_result_id
			AND Registration.industrial = 0
		GROUP BY ReportProduction.name, ReportResearch.name, ResearchType.name, ResearchResult.name
		ORDER BY ReportProduction.name, ReportResearch.name, ResearchType.name, ResearchResult.name;");
		
		$this->set(compact('data'));
	}
	
	public function vet5_3_xml($institution_id=null, $lab_id=null, $date_from=null, $date_to=null) {
		if (!$date_from||!$date_to) {
			throw new NotFoundException("Не указан период выборки для документа.");
		}
		Configure::write('debug', 0);
		$this->layout = null;
		
		$lab_ids = $this->_getLabIds($institution_id, $lab_id);
		$this->_setVet5CommonData($institution_id, $lab_id);
		$this->set(compact('date_from'));
		$this->set(compact('date_to'));
		
		//Мясо и мясопродукты production_type_id=1
		//Рыба морская production_type_id=5
		//Рыба речная production_type_id=23
		$data = $this->Registration->query("
		SELECT ReportProduction.name, ReportDetection.name, Detection.name, SUM(Expertise.count) as count
		FROM expertises AS Expertise, registrations AS Registration,
			 productions as Production, detections AS Detection,
			 report_detections AS ReportDetection, report_productions AS ReportProduction, expertises_detections
		WHERE Expertise.production_id IN (SELECT id FROM productions WHERE production_type_id IN (1,5,23)) 
			AND Expertise.registration_id=Registration.id
			AND Production.id = Expertise.production_id
			AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
			AND Registration.lab_id IN (".$lab_ids.")
			AND expertises_detections.expertise_id = Expertise.id
			AND Detection.id = expertises_detections.detection_id
			AND ReportDetection.id = Detection.report_detection_id
			AND ReportProduction.id = Production.report_production_id
			AND Registration.industrial = 0
		GROUP BY ReportProduction.name, ReportDetection.name, Detection.name
		ORDER BY ReportProduction.name, ReportDetection.name, Detection.name;");
		
		$this->set(compact('data'));
	}
	
	public function vet5_4_xml($institution_id=null, $lab_id=null, $date_from=null, $date_to=null)
	{
		if (!$date_from||!$date_to) {
			throw new NotFoundException("Не указан период выборки для документа.");
		}
		Configure::write('debug', 0);
		$this->layout = null;
		
		$lab_ids = $this->_getLabIds($institution_id, $lab_id);
		$this->_setVet5CommonData($institution_id, $lab_id);
		$this->set(compact('date_from'));
		$this->set(compact('date_to'));
		
		//Мясо и мясопродукты production_type_id=1
		//Рыба морская production_type_id=5
		//Рыба речная production_type_id=23
		$data = $this->Registration->query("
		SELECT ReportProduction.name, UseOrder.name, BanReason.name, ReportBanType.name, ROUND(SUM(Ban.weight),2) AS weight 
		FROM bans AS Ban, report_productions AS ReportProduction, productions AS Production,
			 registrations as Registration, use_orders AS UseOrder, ban_reasons AS BanReason,
			 report_ban_types as ReportBanType, ban_types AS BanType
		WHERE Ban.production_id IN (SELECT id FROM productions WHERE production_type_id IN (1,5,23)) 
			AND Ban.registration_id=Registration.id
			AND Production.id = Ban.production_id
			AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
			AND Registration.lab_id IN (".$lab_ids.")
			AND ReportProduction.id = Production.report_production_id
			AND UseOrder.id = Ban.use_order_id
			AND BanReason.id = Ban.ban_reason_id
			AND BanType.id = Ban.ban_type_id
			AND ReportBanType.id = BanType.report_ban_type_id
			AND Registration.industrial = 0
		GROUP BY ReportProduction.name, UseOrder.name, BanReason.name, ReportBanType.name
		ORDER BY ReportProduction.name, UseOrder.name, BanReason.name, ReportBanType.name");
		
		$this->set(compact('data'));
	}
	
	public function vet5_5_xml($institution_id=null, $lab_id=null, $date_from=null, $date_to=null)
	{
		if (!$date_from||!$date_to) {
			throw new NotFoundException("Не указан период выборки для документа.");
		}
		Configure::write('debug', 0);
		$this->layout = null;
		
		$lab_ids = $this->_getLabIds($institution_id, $lab_id);
		$this->_setVet5CommonData($institution_id, $lab_id);
		$this->set(compact('date_from'));
		$this->set(compact('date_to'));
		
		//Мясо и мясопродукты production_type_id=1
		//Рыба морская production_type_id=5
		//Рыба речная production_type_id=23
		//Другие пищевые продукты ReportProduction.id = 16
		$data = $this->Registration->query("
		SELECT (CASE WHEN Registration.industrial=1 THEN 'Другие пищевые продукты' ELSE ReportProduction.name END) AS production_name, Production.name, SUM(Expertise.count) as count
		FROM expertises AS Expertise, registrations AS Registration,
			 productions as Production, report_productions AS ReportProduction
		WHERE (Expertise.production_id NOT IN (SELECT id FROM productions WHERE production_type_id IN (1,5,23)) 
			OR Registration.industrial=1)
		AND Expertise.registration_id=Registration.id
		AND Production.id = Expertise.production_id
		AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
		AND Registration.lab_id IN (".$lab_ids.")
		AND ReportProduction.id = Production.report_production_id
		AND (ReportProduction.id = 16 OR Registration.industrial=1)
		GROUP BY production_name, Production.name
		ORDER BY production_name, Production.name;");
		
		$this->set(compact('data'));
	}
	
	public function vet5_6_xml($institution_id=null, $lab_id=null, $date_from=null, $date_to=null)
	{
		if (!$date_from||!$date_to) {
			throw new NotFoundException("Не указан период выборки для документа.");
		}
		Configure::write('debug', 0);
		$this->layout = null;
		
		$lab_ids = $this->_getLabIds($institution_id, $lab_id);
		$this->_setVet5CommonData($institution_id, $lab_id);
		$this->set(compact('date_from'));
		$this->set(compact('date_to'));
		
		//Мясо и мясопродукты production_type_id=1
		//Рыба production_type_id=5
		$data = $this->Registration->query("
		SELECT (CASE WHEN Registration.industrial=1 THEN 'Другие пищевые продукты' ELSE ReportProduction.name END) AS production_name, ReportResearch.name, ResearchType.name, ResearchResult.name, SUM(Research.count) AS count
		FROM researches as Research,
			 research_types as ResearchType,
			 registrations as Registration,
			 productions as Production,
			 report_productions as ReportProduction,
			 report_researches as ReportResearch,
			 research_results as ResearchResult
		WHERE (Research.production_id NOT IN (SELECT id FROM productions WHERE production_type_id IN (1,5,23)) 
			OR Registration.industrial=1)
			AND Research.registration_id=Registration.id
			AND Production.id = Research.production_id
			AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
			AND Registration.lab_id IN (".$lab_ids.")
			AND ReportProduction.id = Production.report_production_id
			AND ResearchType.id = Research.research_type_id
			AND ReportResearch.id = ResearchType.report_research_id
			AND ResearchResult.id = Research.research_result_id
		GROUP BY production_name, ReportResearch.name, ResearchType.name, ResearchResult.name
		ORDER BY production_name, ReportResearch.name, ResearchType.name, ResearchResult.name;");
		
		$this->set(compact('data'));
	}
		
	public function vet5_7_xml($institution_id=null, $lab_id=null, $date_from=null, $date_to=null)
	{
		if (!$date_from||!$date_to) {
			throw new NotFoundException("Не указан период выборки для документа.");
		}
		Configure::write('debug', 0);
		$this->layout = null;
		
		$lab_ids = $this->_getLabIds($institution_id, $lab_id);
		$this->_setVet5CommonData($institution_id, $lab_id);
		$this->set(compact('date_from'));
		$this->set(compact('date_to'));
		
		//Мясо и мясопродукты production_type_id=1
		//Рыба production_type_id=5
		$data = $this->Registration->query("
		SELECT (CASE WHEN Registration.industrial=1 THEN 'Другие пищевые продукты' ELSE ReportProduction.name END) AS production_name, ReportDetection.name, Detection.name, SUM(Expertise.count) as count
		FROM expertises AS Expertise, registrations AS Registration,
			 productions as Production, detections AS Detection,
			 report_detections AS ReportDetection, report_productions AS ReportProduction, expertises_detections
		WHERE (Expertise.production_id NOT IN (SELECT id FROM productions WHERE production_type_id IN (1,5,23)) 
			OR Registration.industrial=1)
			AND Expertise.registration_id=Registration.id
			AND Production.id = Expertise.production_id
			AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
			AND Registration.lab_id IN (".$lab_ids.")
			AND expertises_detections.expertise_id = Expertise.id
			AND Detection.id = expertises_detections.detection_id
			AND ReportDetection.id = Detection.report_detection_id
			AND ReportProduction.id = Production.report_production_id
		GROUP BY production_name, ReportDetection.name, Detection.name
		ORDER BY production_name, ReportDetection.name, Detection.name;");
		
		$this->set(compact('data'));
	}
	
	public function vet5_8_xml($institution_id=null, $lab_id=null, $date_from=null, $date_to=null)
	{
		if (!$date_from||!$date_to) {
			throw new NotFoundException("Не указан период выборки для документа.");
		}
		Configure::write('debug', 0);
		$this->layout = null;
		
		$lab_ids = $this->_getLabIds($institution_id, $lab_id);
		$this->_setVet5CommonData($institution_id, $lab_id);
		$this->set(compact('date_from'));
		$this->set(compact('date_to'));
		
		//Мясо и мясопродукты production_type_id=1
		//Рыба production_type_id=5
		$data = $this->Registration->query("
		SELECT (CASE WHEN Registration.industrial=1 THEN 'Другие пищевые продукты' ELSE ReportProduction.name END) AS production_name, UseOrder.name, BanReason.name, BanType.name, ROUND(SUM(Ban.weight),2) AS weight 
		FROM bans AS Ban, report_productions AS ReportProduction, productions AS Production,
			 registrations as Registration, use_orders AS UseOrder, ban_reasons AS BanReason,
			 ban_types AS BanType
		WHERE (Ban.production_id NOT IN (SELECT id FROM productions WHERE production_type_id IN (1,5,23)) 
			OR Registration.industrial=1)
			AND Ban.registration_id=Registration.id
			AND Production.id = Ban.production_id
			AND DATE(Registration.date) between '".$date_from."' AND '".$date_to."'
			AND Registration.lab_id IN (".$lab_ids.")
			AND ReportProduction.id = Production.report_production_id
			AND UseOrder.id = Ban.use_order_id
			AND BanReason.id = Ban.ban_reason_id
			AND BanType.id = Ban.ban_type_id
		GROUP BY production_name, UseOrder.name, BanReason.name, BanType.name
		ORDER BY production_name, UseOrder.name, BanReason.name, BanType.name");
		
		$this->set(compact('data'));
	}
}
?>