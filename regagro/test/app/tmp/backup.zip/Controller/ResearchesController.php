<?php
// app/Controller/ResearchesController.php

class ResearchesController extends AppController {

	public $components = array('RequestHandler', 'Paginator');
	public $helpers = array(
		'Html' => array('className' => 'BoostCake.BoostCakeHtml'),
		'Form' => array('className' => 'BoostCake.BoostCakeForm'),
		'Paginator' => array('className' => 'BoostCake.BoostCakePaginator'),
	);
	
	public function beforeFilter() {
		parent::beforeFilter();
		if (in_array($this->Auth->user('role'),  array('Сотрудник','Администратор'))) {
			$this->Auth->allow('*');
		}
		
		if (!$this->Auth->user('lab_id') || $this->Auth->user('lab_id')==0) {
			$this->Session->setFlash('Вы не можете заполнять журнал, т.к. не числитесь в лаборатории.', 'alert', array(
				'plugin' => 'BoostCake',
				'class' => 'alert-danger'
			), 'danger');
			$this->redirect('/');
		}
		
		if(in_array($this->action, array('edit','delete'))) {
			$this->Research->id = $this->request->params['pass'][0];
			$research = $this->Research->read();
			$lab = $research['Registration']['lab_id'];
			//$lab = $this->Research->Registration->field('lab_id');
			if ($this->Auth->user('lab_id')!=$lab)
			{
				$this->Session->setFlash('Вы не можете работать с чужим журналом.', 'alert', array(
				'plugin' => 'BoostCake',
				'class' => 'alert-danger'
				), 'danger');
				$this->redirect('/');
			}
		}
		
		//запрет на правку данных за прошедшие дни
		if($this->Auth->user('role')!='Администратор' && in_array($this->action, array('add', 'edit', 'delete'))) {
			$registration_id=0;
			$registration_id = ($this->action=='add'?$this->request->params['pass'][0]:$this->Research->field('registration_id', array('id'=>$this->request->params['pass'][0])));
			$reg_date = $this->Research->Registration->field('date', array('id'=>$registration_id));
			if($reg_date<date('Y-m-d')){
				$this->Session->setFlash('Вы не можете править или удалять данные за прошедшие дни.', 'alert', array(
				'plugin' => 'BoostCake',
				'class' => 'alert-danger'
				), 'danger');
				$this->redirect($this->referer());
			}
		}
	}
	
	public function isAuthorized($user) {
		if (isset($user['role']) && in_array($user['role'], array('Администратор','Сотрудник'))) {
            return true;
        }
    
        return parent::isAuthorized($user);
    }
	
	public function beforeRender() {
		if ($this->Auth->user('role') === 'Администратор') {
			$this->userActions[] = array('title'=>'Справочники','url'=>Router::url(array('controller'=>'pages','action'=>'lists')));
		}
		if (in_array($this->Auth->user('role'),  array('Сотрудник','Администратор'))) {
			$this->userActions[] = array('title'=>'Журнал','url'=>Router::url(array('controller'=>'registrations','action'=>'index')));
		}
		parent::beforeRender();
	}
	
	public function add($registration_id=null) {
		$this->set('title_for_layout', 'Добавление исследования');
		
		if (in_array($this->Auth->user('role'),  array('Сотрудник','Администратор'))) {
			$this->userActions[] = array('title'=>'Запись в журнале','url'=>Router::url(array('controller'=>'registrations','action'=>'overview', $registration_id)));
		}

		if (!$registration_id) {
			throw new NotFoundException("Несуществующая запись в журнале");
		}
		
		$registration = $this->Research->Registration->findById($registration_id);
		if (!$registration) {
			throw new NotFoundException("Несуществующая запись журнале");
		}
		
		//$this->request->data['Research']['registration_id'] = $registration_id;
        if ($this->request->is('post')) {
			unset($this->request->data['Research']['production_id']);
			unset($this->request->data['Research']['expertise_id']);
			$this->request->data = $this->request->data['Research'];
            $this->Research->create();
            if ($this->Research->saveMany($this->request->data)) {
				$this->Session->setFlash('Запись добавлена.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-success'
				), 'success');
				//$this->redirect($this->referer());
				$this->redirect(array('controller'=>'registrations', 'action'=>'overview', $registration_id));
			} else {
				$this->Session->setFlash('Ошибка'/*.print_r($this->Research->validationErrors, true)*/, 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-danger'
				), 'success');
			}
		}
		$productions = $this->Research->Production->find('list', 
															array('conditions'=>array(
																'production_type_id'=>$registration['Registration']['production_type_id'],
																'id IN (SELECT production_id FROM expertises WHERE registration_id='.$registration['Registration']['id'].')'
															)));
		$this->set(compact('productions'));
		$researchTypes = $this->Research->ResearchType->find('list', array(
										'order'=>'ResearchType.Name',
										'conditions'=>array('ResearchTypesProductionTypes.production_type_id'=>$registration['Registration']['production_type_id']),
										'joins'=>array(
													array(
														'type'=>'inner',
														'table'=>'research_types_production_types',
														'alias'=>'ResearchTypesProductionTypes',
														'conditions'=>array(
															'ResearchTypesProductionTypes.research_type_id = ResearchType.id'
														)
													))));
		$this->set(compact('researchTypes'));
		$researchResults = $this->Research->ResearchResult->find('list');
		$this->set(compact('researchResults'));
		$this->set(compact('registration'));
		$expertises = $this->Research->Expertise->find('list', array('conditions'=>array('Expertise.registration_id'=>$registration_id)));
		$this->set(compact('expertises'));
		//$this->render('edit');
	}
	
	public function edit($id=null) {
		$this->set('title_for_layout', 'Редактирование исследования');
		if (!$id) {
			throw new NotFoundException("Несуществующая запись");
		}
		
		$research = $this->Research->findById($id);
		if (!$research) {
			throw new NotFoundException("Несуществующая запись");
		}
		
		if (!$this->request->data) {
			$this->request->data = $research;
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			$this->Research->id = $id;
            if ($this->Research->save($this->request->data)) {
				$this->Session->setFlash('Запись изменена.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-success'
				), 'success');
				$this->redirect(array('controller'=>'registrations', 'action'=>'overview', $research['Research']['registration_id']));
			} else {
				$this->Session->setFlash('Не удалось сохранить изменения.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-danger'
				), 'danger');
			}
		}
		
		$productions = $this->Research->Production->find('list',
															array('conditions'=>array(
																'production_type_id'=>$research['Registration']['production_type_id'],
																'id IN (SELECT production_id FROM expertises WHERE registration_id='.$research['Registration']['id'].')'
															)));
		$this->set(compact('productions'));
		$researchTypes = $this->Research->ResearchType->find('list', array(
										'order'=>'ResearchType.Name',
										'conditions'=>array('ResearchTypesProductionTypes.production_type_id'=>$research['Registration']['production_type_id']),
										'joins'=>array(
													array(
														'type'=>'inner',
														'table'=>'research_types_production_types',
														'alias'=>'ResearchTypesProductionTypes',
														'conditions'=>array(
															'ResearchTypesProductionTypes.research_type_id = ResearchType.id'
														)
													))));
		$this->set(compact('researchTypes'));
		$researchResults = $this->Research->ResearchResult->find('list');
		$this->set(compact('researchResults'));
		$expertises = $this->Research->Expertise->find('list', array('conditions'=>array('Expertise.registration_id'=>$research['Registration']['id'])));
		$this->set(compact('expertises'));
		
		$this->set('research', $research);
	}
	
	public function index() {
		$this->Paginator->settings = array(
			'limit' => 30,
			'order' => array('Research.id'=>'asc')
		);
		$researches = $this->Paginator->paginate('Research');
		$this->set('researches', $researches);
	}
	
	public function delete($id) {
		if ($this->Research->delete($id)) {
			$this->Session->setFlash('Запись с ИД '.$id.' удалена.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-success'
				), 'success');
			return $this->redirect(array('action' => 'index'));
		}
	}
}
?>