<?php
// app/Controller/SamplesController.php

class SamplesController extends AppController {

	public $components = array('RequestHandler', 'Paginator');
	public $helpers = array(
		'Html' => array('className' => 'BoostCake.BoostCakeHtml'),
		'Form' => array('className' => 'BoostCake.BoostCakeForm'),
		'Paginator' => array('className' => 'BoostCake.BoostCakePaginator'),
	);
	
	public function beforeFilter() {
		parent::beforeFilter();
		if (in_array($this->Auth->user('role'),  array('Сотрудник','Администратор'))) {
			$this->Auth->allow('index', 'add', 'edit', 'delete');
		}
		
		if (!$this->Auth->user('lab_id') || $this->Auth->user('lab_id')==0) {
			$this->Session->setFlash('Вы не можете заполнять журнал, т.к. не числитесь в лаборатории.', 'alert', array(
				'plugin' => 'BoostCake',
				'class' => 'alert-danger'
			), 'danger');
			$this->redirect('/');
		}
		
		if(in_array($this->action, array('edit','delete'))) {
			$this->Sample->id = $this->request->params['pass'][0];
			$sample = $this->Sample->read();
			$lab = $sample['Registration']['lab_id'];
			//$lab = $this->Sample->Registration->field('lab_id');
			if ($this->Auth->user('lab_id')!=$lab)
			{
				$this->Session->setFlash('Вы не можете работать с чужим журналом.', 'alert', array(
				'plugin' => 'BoostCake',
				'class' => 'alert-danger'
				), 'danger');
				$this->redirect('/');
			}
		}
		
		//запрет на правку данных за прошедшие дни
		if($this->Auth->user('role')!='Администратор' && in_array($this->action, array('add', 'edit', 'delete'))) {
			$registration_id=0;
			$registration_id = ($this->action=='add'?$this->request->params['pass'][0]:$this->Sample->field('registration_id', array('id'=>$this->request->params['pass'][0])));
			$reg_date = $this->Sample->Registration->field('date', array('id'=>$registration_id));
			if($reg_date<date('Y-m-d')){
				$this->Session->setFlash('Вы не можете править или удалять данные за прошедшие дни.', 'alert', array(
				'plugin' => 'BoostCake',
				'class' => 'alert-danger'
				), 'danger');
				$this->redirect($this->referer());
			}
		}
	}
	
	public function isAuthorized($user) {
		if (isset($user['role']) && in_array($user['role'], array('Администратор','Сотрудник'))) {
            return true;
        }
    
        return parent::isAuthorized($user);
    }
	
	public function beforeRender() {
		if ($this->Auth->user('role') === 'Администратор') {
			$this->userActions[] = array('title'=>'Справочники','url'=>Router::url(array('controller'=>'pages','action'=>'lists')));
		}
		if (in_array($this->Auth->user('role'),  array('Сотрудник','Администратор'))) {
			$this->userActions[] = array('title'=>'Журнал','url'=>Router::url(array('controller'=>'registrations','action'=>'index')));
		}
		parent::beforeRender();
	}
	
	public function add($registration_id=null) {
		$this->set('title_for_layout', 'Добавление отбора проб');
		
		if (in_array($this->Auth->user('role'),  array('Сотрудник','Администратор'))) {
			$this->userActions[] = array('title'=>'Запись в журнале','url'=>Router::url(array('controller'=>'registrations','action'=>'overview', $registration_id)));
		}

		if (!$registration_id) {
			throw new NotFoundException("Несуществующая запись в журнале");
		}
		
		$registration = $this->Sample->Registration->findById($registration_id);
		if (!$registration) {
			throw new NotFoundException("Несуществующая запись журнале");
		}
		
		$this->request->data['Sample']['registration_id'] = $registration_id;
		$this->request->data['Sample']['lab_id'] = $registration['Registration']['lab_id'];
        if ($this->request->is('post')) {
            $this->Sample->create();
            if ($this->Sample->save($this->request->data)) {
				$this->Session->setFlash('Запись добавлена.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-success'
				), 'success');
				//$this->redirect($this->referer());
				$this->redirect(array('controller'=>'registrations', 'action'=>'overview', $registration_id));
			} else {
				$this->Session->setFlash('Ошибка:'.print_r($this->Sample->validationErrors, true), 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-danger'
				), 'success');
			}
		}
		$productions = $this->Sample->Production->find('list',
														array('conditions'=>array(
															'production_type_id'=>$registration['Registration']['production_type_id'],
															'id IN (SELECT production_id FROM expertises WHERE registration_id='.$registration['Registration']['id'].')'
														)));
		$this->set(compact('productions'));
		
		$vetlabs = $this->Sample->Vetlab->find('list', array('conditions'=>array(
															'Vetlab.organ_id = (SELECT organ_id FROM institutions WHERE id='.$registration['Lab']['institution_id'].')'
															)));
		$this->set(compact('vetlabs'));
		$expertises = $this->Sample->Expertise->find('list', array('conditions'=>array('Expertise.registration_id'=>$registration_id)));
		$samplePurposes = $this->Sample->SamplePurpose->find('list');
		$this->set(compact('samplePurposes'));
		$this->set(compact('expertises'));
		$this->set(compact('registration'));
		//$this->render('edit');
	}
	
	public function edit($id=null) {
		$this->set('title_for_layout', 'Редактирование отбора проб');
		if (!$id) {
			throw new NotFoundException("Несуществующая запись");
		}
		
		$sample = $this->Sample->findById($id);
		if (!$sample) {
			throw new NotFoundException("Несуществующая запись");
		}
		
		if (!$this->request->data) {
			$this->request->data = $sample;
		}
		
		if ($this->request->data['Sample']['lab_id'] == 0) {
			$this->request->data['Sample']['lab_id'] = $sample['Registration']['lab_id'];
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			$this->Sample->id = $id;
            if ($this->Sample->save($this->request->data)) {
				$this->Session->setFlash('Запись изменена.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-success'
				), 'success');
				$this->redirect(array('controller'=>'registrations', 'action'=>'overview', $sample['Sample']['registration_id']));
			} else {
				$this->Session->setFlash('Не удалось сохранить изменения.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-danger'
				), 'danger');
			}
		}
		
		$productions = $this->Sample->Production->find('list',
														array('conditions'=>array(
															'production_type_id'=>$sample['Registration']['production_type_id'],
															'id IN (SELECT production_id FROM expertises WHERE registration_id='.$sample['Registration']['id'].')'
														)));
		$this->set(compact('productions'));
		
		$vetlabs = $this->Sample->Vetlab->find('list', array('conditions'=>array(
													'Vetlab.organ_id = (SELECT organ_id FROM institutions WHERE id='.$sample['Lab']['institution_id'].')'
													)));$this->set(compact('vetlabs'));
		$expertises = $this->Sample->Expertise->find('list', array('conditions'=>array('Expertise.registration_id'=>$sample['Registration']['id'])));
		$samplePurposes = $this->Sample->SamplePurpose->find('list');
		$this->set(compact('samplePurposes'));
		$this->set(compact('expertises'));
		$this->set('sample', $sample);
	}
	
	public function index() {
		$this->Paginator->settings = array(
			'limit' => 30,
			'order' => array('Sample.id'=>'asc')
		);
		$samples = $this->Paginator->paginate('Sample');
		$this->set('samples', $samples);
	}
	
	public function delete($id) {
		if ($this->Sample->delete($id)) {
			$this->Session->setFlash('Запись с ИД '.$id.' удалена.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-success'
				), 'success');
			return $this->redirect($this->referer());
		}
	}
}
?>