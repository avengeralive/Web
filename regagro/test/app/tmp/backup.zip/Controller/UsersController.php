<?php

class UsersController extends AppController {

	public $components = array('RequestHandler', 'Paginator');
	public $helpers = array(
		'Html' => array('className' => 'BoostCake.BoostCakeHtml'),
		'Form' => array('className' => 'BoostCake.BoostCakeForm'),
		'Paginator' => array('className' => 'BoostCake.BoostCakePaginator'),
	);

    public function beforeFilter() {
		parent::beforeFilter();
        //$this->Auth->allow('view', 'paginated');
		//$this->Auth->deny('index','add', 'edit', 'delete');
		$this->Auth->deny('*');
    }
	
	public function beforeRender() {
		if ($this->Auth->user('role') === 'Администратор') {
			$this->userActions[] = array('title'=>'Все пользователи','url'=>Router::url(array('action'=>'index')));
			$this->userActions[] = array('title'=>'Добавить пользователя','url'=>Router::url(array('action'=>'add')));
		}
		parent::beforeRender();
	}
    
    public function isAuthorized($user) {
		if ($user['blocked']==1)
		{
			$this->setFlash('Ваш логин заблокирован администратором системы.','alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-danger'
				), 'danger');
			$this->redirect($this->Auth->logout());
			return false;
		}
	
        if (in_array($this->action, array('logout'))) {
            return true;
        }
		
		if (!isset($user['role']) || !in_array($user['role'], array('Администратор'))) {
			if (in_array($this->action, array('add', 'edit', 'delete', 'index')))
			{
				$this->Session->setFlash('Недостаточно прав.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-danger'
				), 'danger');
				return false;
			}
        }
    
        return parent::isAuthorized($user);
    }
	
	public function add() {
        if ($this->request->is('post')) {
            $this->User->create();
            if ($this->User->save($this->request->data)) {
				$this->Session->setFlash('Пользователь добавлен.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-success'
				), 'success');
				$this->redirect(array('action' => 'index'));
			}
		}		
		
		$labs = $this->User->Lab->find('list');
		$this->set(compact('labs'));
		$institutions = $this->User->Institution->find('list');
		$this->set(compact('institutions'));
		$organs = $this->User->Organ->find('list');
		$this->set(compact('organs'));
		$jobs = $this->User->Job->find('list');
		$this->set(compact('jobs'));
	}
	
	public function edit($id=null) {
		if (!$id) {
			throw new NotFoundException("Несуществующий пользователь");
		}
		
		$user = $this->User->findById($id);
		if (!$user) {
			throw new NotFoundException("Несуществующий пользователь");
		}
		
		if (!$this->request->data) {
			$this->request->data = $user;
		}

		if ($this->request->is('post') || $this->request->is('put')) {
			$this->User->id = $id;
			if ($this->request->data['User']['changepass']==false)
			{
				unset($this->request->data['User']['password']); //пароль не меняем
			}
            if ($this->User->save($this->request->data)) {
				$this->Session->setFlash('Пользователь изменен.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-success'
				), 'success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash('Не удалось сохранить изменения.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-danger'
				), 'danger');
			}
		}
		
		$labs = $this->User->Lab->find('list');
		$this->set(compact('labs'));
		$institutions = $this->User->Institution->find('list');
		$this->set(compact('institutions'));
		$organs = $this->User->Organ->find('list');
		$this->set(compact('organs'));
		$jobs = $this->User->Job->find('list');
		$this->set(compact('jobs'));
	}
	
	public function index() {
		$conditions = array();
		if ($this->request->is('post')) {
			$conditions = array("User.displayname LIKE '%".$this->request->data['User']['displayname']."%'");
		}
		$this->Paginator->settings = array(
			'limit' => 30,
			'conditions' => $conditions,
			'order' => array('User.displayname'=>'asc')
		);
		$users = $this->Paginator->paginate('User');
		$this->set('users', $users);
	}
	
	public function delete($id) {
		if ($this->User->delete($id)) {
			$this->Session->setFlash('Пользователь с ИД '.$id.' удален.', 'alert', array(
					'plugin' => 'BoostCake',
					'class' => 'alert-success'
				), 'success');
			return $this->redirect(array('action' => 'index'));
		}
	}
	
	public function login(){
        if ($this->request->is('post')) {
            if ($this->Auth->login()) {
                //$this->Session->setFlash('Вы успешно авторизованы на сайте<br /><span>у вас есть возможность оставить комментарий или задать вопрос</span>', 'modal_flash', array('type'=>'success'));
				return $this->redirect($this->Auth->redirectUrl());
            } else
			{
				$user = $this->User->findByUsername($this->request->data['User']['username']);
				if ($user&&$user['User']['blocked'])
				{
					$this->Session->setFlash('Вы не авторизовались<br /><span>Ваш логин заблокирован администратором системы</span>','alert', array(
						'plugin' => 'BoostCake',
						'class' => 'alert-danger'
					), 'danger');
				} else {
					$this->Session->setFlash('Вы не авторизовались<br /><span>имя пользователя или пароль указаны неверно</span>','alert', array(
						'plugin' => 'BoostCake',
						'class' => 'alert-danger'
					), 'danger');
				}
			}
        } 
    }
    
    public function logout() {
		$this->redirect($this->Auth->logout());
    }
}
?>