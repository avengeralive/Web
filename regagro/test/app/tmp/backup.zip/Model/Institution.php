<?php
// app/Model/Institution.php
class Institution extends AppModel {
    public $name = 'Institution';
	public $belongsTo = 'Organ';
	public $validate = array(
        'name' => array(
            'required' => array(
                'rule' => 'notEmpty',
                'required' => true,
                'message' => 'Название не указано.'
            )
		)
	);
}
?>