<?php
// app/Model/Lab.php
class Lab extends AppModel {
    public $name = 'Lab';
	public $belongsTo = array('Region','Institution');
	public $validate = array(
        'name' => array(
            'required' => array(
                'rule' => 'notEmpty',
                'required' => true,
                'message' => 'Название не указано.'
            )
		)
	);
}
?>