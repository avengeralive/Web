<?php
// app/Model/Measure.php
class Measure extends AppModel {
    public $name = 'Measure';
	public $validate = array(
        'name' => array(
            'required' => array(
                'rule' => 'notEmpty',
                'required' => true,
                'message' => 'Название не указано.'
            )
		)
	);
}
?>