<?php
// app/Model/Organ.php
class Organ extends AppModel {
    public $name = 'Organ';
	public $validate = array(
        'name' => array(
            'required' => array(
                'rule' => 'notEmpty',
                'required' => true,
                'message' => 'Название не указано.'
            )
		)
	);
}
?>