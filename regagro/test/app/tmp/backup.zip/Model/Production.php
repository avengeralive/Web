<?php
// app/Model/Production.php
class Production extends AppModel {
    public $name = 'Production';
	public $belongsTo = array('ProductionType', 'ReportProduction', 'Measure');
	public $validate = array(
        'name' => array(
            'required' => array(
                'rule' => 'notEmpty',
                'required' => true,
                'message' => 'Название не указано.'
            )
		)
	);
}
?>