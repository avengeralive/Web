<?php
// app/Model/Registration.php
class Registration extends AppModel {
    public $name = 'Registration';
	public $actsAs = array('Subsequenced' => array('field' => 'code', 'foreign_key' => 'lab_id'));
	public $belongsTo = array('ProductionType', 'User', 'Region', 'District', 'Lab');
	public $hasMany = array(
		'Expertise'=>array(
			'order'=>'Expertise.id ASC',
            'dependent' => true
			),
		'Research', 'Ban', 'Distribution', 'Sample');
	public $order = array('Registration.code'=>'DESC', 'Expertise.id'=>'ASC');
}

?>