<?php
// app/Model/Sample.php
App::uses('AppModel', 'Model');
class Sample extends AppModel {
    public $name = 'Sample';
	public $actsAs = array('Subsequenced' => array('field' => 'code', 'foreign_key' => 'lab_id'));
	public $belongsTo = array('Production', 'Expertise', 'Registration', 'Vetlab', 'Lab', 'SamplePurpose');
	public $validate = array(
        'count' => array(
            'required' => array(
                'rule' => 'notEmpty',
                'required' => true,
                'message' => 'Количество проб не указано.'
            )
		),
		'samples_weight' => array(
            'required' => array(
                'rule' => 'notEmpty',
                'required' => true,
                'message' => 'Вес проб не указан.'
            )
		)
	);
	
	public function beforeValidate($options = array()) {
		$this->data['Sample']['samples_weight'] = str_replace(',','.',$this->data['Sample']['samples_weight']);
		return true;
	}
	
	public function beforeSave($options = array()) {
		$expertise = $this->Expertise->findById($this->data['Sample']['expertise_id']);
		$this->data['Sample']['production_id'] = $expertise['Expertise']['production_id'];
		return true;
	}
}
?>