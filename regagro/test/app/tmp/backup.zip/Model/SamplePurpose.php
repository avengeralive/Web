<?php
// app/Model/SamplePurpose.php
App::uses('AppModel', 'Model');
class SamplePurpose extends AppModel {
	public $name = 'SamplePurpose';
	public $hasMany = array('Sample');
}