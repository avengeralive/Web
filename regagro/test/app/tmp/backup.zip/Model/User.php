<?php
// app/Model/User.php
class User extends AppModel {
    public $name = 'User';
	public $belongsTo = array('Lab','Job','Institution','Organ');
	public $displayField = 'displayname';
    public $validate = array(
        'username' => array(
            'required' => array(
                'rule' => 'notEmpty',
                'required' => true,
                'message' => 'Имя пользователя не указано.'
            ),
            'isUnique' => array(
                'rule' => 'isUnique',
                'required' => true,
                'message' => 'Такое имя пользователя уже используется.'
            )
        ),
        'displayname' => array(
            'required' => array(
                'rule' => 'notEmpty',
                'required' => true,
                'message' => 'Представьтесь пожалуйста, что бы мы знали как к вам обращаться.'
            )
        ),
        'password' => array(
            array(
            'rule' => 'notEmpty',
            'message' => 'Пароль не может быть пустым.'
            ),
            array(
            'rule' => array('minLength', 6),
            'message' => 'Пароль должен содержать минимум 6 символов.'
            ),
            array(
            'rule' => array('passCompare'),
            'message' => 'Пароль не совпадает.'
            )
        ),
        'role' => array(
            'valid' => array(
                'rule' => array('inList', 
                            array('Администратор', 'Сотрудник')
                          ),
                'message' => 'Пожалуста укажите существующую роль.',
                'allowEmpty' => false
            )
        )
    );
    
    public function passCompare() {
        return ($this->data[$this->alias]['password'] === $this->data[$this->alias]['password_confirm']);        
    }
	
	
    public function beforeSave() {
		if (isset($this->data['User']['password']))
		{
			$this->data['User']['password'] = AuthComponent::password($this->data['User']['password']);
		}
        return true;
    }
}
?>