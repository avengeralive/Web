<?php
// app/Model/Vetlab.php
class Vetlab extends AppModel {
    public $name = 'Vetlab';
	public $order = 'Vetlab.name';
	public $belongsTo = 'Organ';
	public $validate = array(
        'name' => array(
            'required' => array(
                'rule' => 'notEmpty',
                'required' => true,
                'message' => 'Название не указано.'
            )
		)
	);
}
?>