<div class="row">
	<div class="col-md-1">
		<h4>Причины обезвреживания</h4>
	</div>
	<div class="col-md-11">
		<?php echo $this->Form->create('BanReason', array(
			'action'=> 'add',
			'inputDefaults' => array(
				'div' => 'form-group',
				'label' => false,
				'wrapInput' => false,
				'class' => 'form-control'
			),
			'class' => 'form-inline text-right'
		)); ?>
				<?php 
				echo $this->Form->input('name', array(
					'placeholder' => 'Название...',
					'div' => 'form-group'
				));
				?>
				<?php
				echo $this->Form->input('report_ban_reason_id');
				echo $this->Form->input('ProductionType');
				?>
				<?php
				echo $this->Form->submit('Добавить', array(
					'div' => 'form-group',
					'class' => 'btn btn-primary'
				));?>
		<?php echo $this->Form->end(); ?>
	</div>
</div>
<?php echo $this->Paginator->pagination(array(
	'ul' => 'pagination pagination-sm'
)); ?>
<table class="table">
	<tr>
		<th>Название</th>
		<th>Название (отчет)</th>
		<th>Виды продукции</th>
		<th>Удалить</th>
	</tr>
	<? 
	foreach ($banReasons as $banReason)
	{
		echo '
		<tr>
			<td>'.$this->Html->link($banReason['BanReason']['name'], array(
					'action' => 'edit', $banReason['BanReason']['id'])).'
			</td>
			<td>
			'.$banReason['ReportBanReason']['name'].'
			</td>
			<td>
			'.implode(', ', array_map(function ($entry) {
				  return $entry['name'];
				}, $banReason['ProductionType'])).'
			</td>
			<td>'.$this->Html->link('<span class="glyphicon glyphicon-remove"></span>', array(
					'action' => 'delete', $banReason['BanReason']['id']),
					array(
						'escape'=>false
					)).'
			</td>
		</tr>';
	}
	?>
</table>
<?php echo $this->Paginator->pagination(array(
	'ul' => 'pagination pagination-sm'
)); ?>