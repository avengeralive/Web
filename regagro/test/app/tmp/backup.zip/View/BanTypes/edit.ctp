<?php echo $this->Form->create('BanType', array(
	'inputDefaults' => array(
		'div' => 'form-group',
		'wrapInput' => false,
		'class' => 'form-control'
	),
	'class' => 'well'
)); ?>
	<fieldset>
		<legend><?php echo $title_for_layout ?></legend>
		<?php 
		echo $this->Form->input('name', array('label'=>'Название'));
		echo $this->Form->input('report_ban_type_id', array('label'=>'Снято с реализации (отчет)'));
		//echo $this->Form->input('ProductionType', array('size'=>8,'after' => '<span class="help-block">Используйте ctrl или shift для выбора нескольких видов продукции.</span>'));
		echo $this->Form->input('ProductionType', array('label'=>'Виды продукции',
														'type' => 'select',
														'multiple' => 'checkbox'));
		echo $this->Form->submit('Сохранить', array(
			'div' => 'form-group',
			'class' => 'btn btn-default'
		));?>
	</fieldset>
<?php echo $this->Form->end(); ?>