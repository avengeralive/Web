<div class="row">
	<div class="col-md-3">
		<h4>Снято с реализации</h4>
	</div>
	<div class="col-md-9">
		<?php echo $this->Form->create('BanType', array(
			'action'=> 'add',
			'inputDefaults' => array(
				'div' => 'form-group',
				'label' => false,
				'wrapInput' => false,
				'class' => 'form-control'
			),
			'class' => 'form-inline text-right'
		)); ?>
				<?php 
				echo $this->Form->input('name', array(
					'placeholder' => 'Название...',
					'div' => 'form-group'
				));
				?>
				<?php
				echo $this->Form->input('report_ban_type_id');
				echo $this->Form->input('ProductionType');
				?>
				<?php
				echo $this->Form->submit('Добавить', array(
					'div' => 'form-group',
					'class' => 'btn btn-primary'
				));?>
		<?php echo $this->Form->end(); ?>
	</div>
</div>
<?php echo $this->Paginator->pagination(array(
	'ul' => 'pagination pagination-sm'
)); ?>
<table class="table">
	<tr>
		<th>Название</th>
		<th>Название (отчет)</th>
		<th>Виды продукции</th>
		<th>Удалить</th>
	</tr>
	<? 
	foreach ($banTypes as $banType)
	{
		echo '
		<tr>
			<td>'.$this->Html->link($banType['BanType']['name'], array(
					'action' => 'edit', $banType['BanType']['id'])).'
			</td>
			<td>
			'.$banType['ReportBanType']['name'].'
			</td>
			<td>
			'.implode(', ', array_map(function ($entry) {
				  return $entry['name'];
				}, $banType['ProductionType'])).'
			</td>
			<td>'.$this->Html->link('<span class="glyphicon glyphicon-remove"></span>', array(
					'action' => 'delete', $banType['BanType']['id']),
					array(
						'escape'=>false
					)).'
			</td>
		</tr>';
	}
	?>
</table>
<?php echo $this->Paginator->pagination(array(
	'ul' => 'pagination pagination-sm'
)); ?>