<?php echo $this->Form->create('Ban', array(
	'inputDefaults' => array(
		'div' => 'form-group',
		'wrapInput' => false,
		'class' => 'form-control'
	),
	'class' => 'well'
)); ?>
	<fieldset>
		<legend><?php echo $title_for_layout ?></legend>
		<?php 
		echo $this->Form->input('expertise_id', array('label'=>'Экспертиза'));
		//echo $this->Form->input('production_id', array('label'=>'Продукция ('.$registration['ProductionType']['name'].')'));
		echo $this->Form->input('ban_type_id', array('type'=>'radio','legend'=>'Снятая продукция','required'=>false));
		echo $this->Form->input('weight', array('label'=>'Вес снятой продукции в кг (объем в л, яйцо в шт.)', 'step'=>0.01));
		echo $this->Form->input('ban_reason_id', array('label'=>'Причины',
													  'empty' => 'не указано'));
		echo $this->Form->input('note', array('label'=>'Примечание'));
		echo $this->Form->input('use_order_id', array('type'=>'radio','legend'=>'Порядок использования','required'=>false));
		echo $this->Form->input('rules_item', array('label'=>'Пункт правил ВСЭ'));
		echo $this->Form->submit('Сохранить', array('formnovalidate' => true,
			'div' => 'form-group',
			'class' => 'btn btn-default'
		));?>
	</fieldset>
<?php echo $this->Form->end(); ?>

<?php
$this->start('css');?>
<link rel="stylesheet" href="/css/selectize.css">
<link rel="stylesheet" href="/css/selectize.bootstrap3.css">
<?php $this->end(); ?>

<?php
$this->start('script');?>
<script src="/js/selectize.min.js"></script>
<script type="text/javascript">
$(function () {
	$('select').selectize({
		plugins: ['restore_on_backspace'],
		create: false,
		selectOnTab: true,
		onInitialize: function() {this.selected_value = this.getValue();},
		onChange: function(value) {value=value==0?this.selected_value:value;this.selected_value=value;},
		onDropdownClose: function($dropdown) { 
			if(this.getValue()==0) {
				this.setValue(this.selected_value ); 
			}
		}
	});
});
</script>
<?php $this->end(); ?>