<div class="panel panel-default">
	<div class="panel-heading">
		<?php echo $this->Form->create('Detection', array(
			'action'=> 'add',
			'inputDefaults' => array(
				'div' => 'form-group',
				'label' => false,
				'wrapInput' => false,
				'class' => 'form-control',
				'style' => 'width:350px;height:100%'
			),
			'class' => 'form-inline text-right'
		)); ?>
		<div class="row">
			<div class="col-md-2"><h3 class="panel-title">Выявления</h3></div>
			<div class="col-md-5">
				<fieldset>
				<?php 
				echo $this->Form->input('name', array(
					'placeholder' => 'Название...',
					'div' => 'form-group'
				));?>
				
				<?php 
				echo $this->Form->input('detection_type_id', array(
					'div' => 'form-group'
				));?>
				
				<?php 
				echo $this->Form->input('report_detection_id', array(
					'div' => 'form-group'
				));?>
				</fieldset>
			</div>
			<div class="col-md-5">
				<?php
				echo $this->Form->input('ProductionType', array('size'=>5,
											'style' => 'width:250px'));
				?>
				
				<?php
				echo $this->Form->submit('Добавить', array(
					'div' => 'form-group',
					'class' => 'btn btn-primary'
				));?>
			</div>
		</div>
		<?php echo $this->Form->end(); ?>
	</div>
	<?php echo $this->Paginator->pagination(array(
		'ul' => 'pagination pagination-sm'
	)); ?>
	<table class="table">
		<tr>
			<th>Название</th>
			<th>Вид выявления</th>
			<th>Выявление (отчет)</th>
			<th>Виды продукции</th>
			<th>Удалить</th>
		</tr>
		<? 
		foreach ($detections as $detection)
		{
			echo '
			<tr>
				<td>'.$this->Html->link($detection['Detection']['name'], array(
						'action' => 'edit', $detection['Detection']['id'])).'
				</td>
				<td>'.$detection['DetectionType']['name'].'
				</td>
				<td>'.$detection['ReportDetection']['name'].'
				</td>
				<td>
				'.implode(', ', array_map(function ($entry) {
					  return $entry['name'];
					}, $detection['ProductionType'])).'
				</td>
				<td>'.$this->Html->link('<span class="glyphicon glyphicon-remove"></span>', array(
						'action' => 'delete', $detection['Detection']['id']),
						array(
							'escape'=>false
						)).'
				</td>
			</tr>';
		}
		?>
	</table>
	<?php echo $this->Paginator->pagination(array(
		'ul' => 'pagination pagination-sm'
	)); ?>
</div>

<?php
$this->start('script');?>
<script type="text/javascript">
<?php

$this->Js->get('#DetectionDetectionTypeId');
$data = $this->Js->serializeForm(array(
			'isForm' => true,
			'inline' => true
			));
$request = $this->Js->request(
			array(
				'controller'=>'report_detections',
				'action'=>'getByDetectionType'
			),
			array(
				'update'=>'#DetectionReportDetectionId',
				'async' => true,
				'method' => 'post',
				'dataExpression'=>true,
				'data'=> $data.'.replace(\'%5BDetection%5D\',\'\')'
			)
		);
$this->Js->event('change', $request);
	
echo $request; //first request
?>
</script>
<?php $this->end(); ?>