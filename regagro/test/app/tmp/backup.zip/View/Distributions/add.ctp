<div class="alert alert-warning alert-dismissible" role="alert">
  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Закрыть</span></button>
  <strong>Внимание!</strong> Не привысьте допустимый вес по выбранным экспертизам.
  <table class="table table-condensed table-hover">
	<tr>
		<th>Экспертиза</th>
		<th>Макс. вес</th>
		<th>Распределено</th>
	</tr>
	<?php
	foreach ($expertises as $id=>$name)
	{
		echo 
		'<tr>
			<td>'.$name.'</td>
			<td>'.$totals[$id]['conclusion_weight'].'</td>
			<td>'.(isset($distributed[$id])?$distributed[$id]['weight']:0).'</td>
		</tr>';
	}
	?>
  </table>
</div>
<?php 
echo $this->Form->create('Distribution', array(
	'inputDefaults' => array(
		'div' => 'form-group',
		'wrapInput' => false,
		'class' => 'form-control',
		'label'=>false
	),
	'class' => 'well'
)); ?>
	<fieldset>
		<legend><?php echo $title_for_layout ?></legend>
		<?php echo $this->Form->input('distributor', array('label'=>'Торгующему')); ?>
	<div class="row">
		<div class="col-xs-1"><span class="glyphicon glyphicon-remove"></span></div>
		<div class="col-xs-2">
			Экспертиза
		</div>
		<!--div class="col-xs-2">
			Продукция
		</div-->
		<div class="col-xs-2">
			Количество туш (тушек, партий, т/мест)
		</div>
		<div class="col-xs-2">
			Вес в кг (объем в л, яйцо в шт.)
		</div>
		<div class="col-xs-2">
			Количество мест
		</div>
		<div class="col-xs-3">
			Примечание
		</div>
	</div>
	<div class="row" id="formRow0">
		<?php echo $this->Form->input('0.distributor', array('type'=>'hidden'));?>
		<?php echo $this->Form->input('0.registration_id', array('type'=>'hidden', 'value'=>$registration['Registration']['id']));?>		
		<div class="col-xs-1">
			<button type="button" id="removeBtnRow0" class="btn btn-primary btn"><span class="glyphicon glyphicon-minus"></span></button>
		</div>	
		<div class="col-xs-2">
			<?php echo $this->Form->input('0.expertise_id', array());?>
		</div>
		<!--div class="col-xs-2">
			<?php //echo $this->Form->input('0.production_id', array());?>
		</div-->
		<div class="col-xs-2">
			<?php echo $this->Form->input('0.count', array());?>
		</div>
		<div class="col-xs-2">
			<?php echo $this->Form->input('0.weight', array('step'=>0.01));?>
		</div>
		<div class="col-xs-2">
			<?php echo $this->Form->input('0.places', array());?>
		</div>
		<div class="col-xs-3">
			<?php echo $this->Form->input('0.note', array());?>
		</div>
	</div>
	<div class="row" id="addRowRow">
		<div class="col-xs-12 text-center">
			<button type="button" id="addRow" class="btn btn-primary btn-sm">Добавить</button>
		</div>
	</div>
		<?php
		echo $this->Form->submit('Сохранить', array(
			'div' => 'form-group',
			'class' => 'btn btn-default'
		));?>
	</fieldset>
<?php echo $this->Form->end(); ?>

<?php
$this->start('css');?>
<link rel="stylesheet" href="/css/selectize.css">
<link rel="stylesheet" href="/css/selectize.bootstrap3.css">
<?php $this->end(); ?>

<?php
$this->start('script');?>
<script type="text/javascript">
var currentRowsCount = 1;
var formRowHtml = $('#formRow0').html();
var notes = {
		<?foreach ($expertises_notes as $id => $note):?>
		<? echo $id?>:'<? echo $note?>',
		<?endforeach;?>
	};
$(function () {
	
	// $('#DistributionAddForm').submit(function () {

		// var name = $.trim($('#log').val());

		// if (name  === '') {
			// alert('Text-field is empty.');
			// return false;
		// }
	// });
	
	
	$('#Distribution0ExpertiseId').change(function() {
		$('#Distribution0Note').val(notes[$(this).val()]);
	});
	$('#Distribution0ExpertiseId').change();
	
	$('#removeBtnRow0').click(function() {
		$('#formRow0').remove();
	});
	
	$('#addRow').unbind('click').click(function(evt){
		var rowHtml = formRowHtml.replace(/data\[Distribution\]\[0\]/g,'data[Distribution]['+currentRowsCount+']')
								 .replace(/Distribution0/g,'Distribution'+currentRowsCount)
								 .replace(/removeBtnRow0/g,'removeBtnRow'+currentRowsCount);
		var html = '<div class="row" id="formRow'+currentRowsCount+'">'+rowHtml+'</div>';
		$('#addRowRow').before(html);
		
		$('input[id$=Distributor]').val($('#DistributionDistributor').val());
		
		$('#removeBtnRow'+currentRowsCount).click(function() {
			$(this).parent().parent().remove();
		});
		
		var note = $('#Distribution'+currentRowsCount+'Note');
		$('#Distribution'+currentRowsCount+'ExpertiseId').change(function() {
			note.val(notes[$(this).val()]);
		});
		$('#Distribution'+currentRowsCount+'ExpertiseId').change();
		
		currentRowsCount++;
	});
	
	$('#DistributionDistributor').change(function(){
		$('input[id$=Distributor]').val($('#DistributionDistributor').val());
	});
	
});
</script>
<?php $this->end(); ?>