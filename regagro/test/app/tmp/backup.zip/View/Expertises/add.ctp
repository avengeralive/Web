<?php echo $this->Form->create('Expertise', array(
	'inputDefaults' => array(
		'div' => 'form-group',
		'wrapInput' => false,
		'class' => 'form-control'
	),
	'class' => 'well'
)); ?>
	<fieldset>
		<legend><?php echo $title_for_layout ?></legend>
		<?php 
		echo $this->Form->input('production_id', array('label'=>'Продукция ('.$registration['ProductionType']['name'].')',
													  'empty' => 'не указано'));
		echo $this->Form->input('manufacturer', array('label'=>'Изготовитель/маркировка'));
		echo $this->Form->input('count', array('label'=>'Количество экспертиз'));
		echo $this->Form->input('viscera', array('label'=>'Наличие внутренних органов','div'=>'checkbox', 'class'=>'checkbox'));
		echo $this->Form->input('thermal_state', array('label'=>'Термическое состояние', 'type'=>'select', 'empty' => 'не указано', 'options'=>array('парное'=>'парное', 'охлажденное'=>'охлажденное', 'замороженное'=>'замороженное', 'остывшее'=>'остывшее')));
		echo $this->Form->input('domestic_weight', array('label'=>'Общий вес отечественной продукции в кг (объем в л, яйцо в шт.)', 'step'=>0.01));
		echo $this->Form->input('foreign_weight', array('label'=>'Общий вес зарубежной продукции в кг (объем в л, яйцо в шт.)', 'step'=>0.01));
		echo $this->Form->input('samples_weight', array('label'=>'Количество отработанного лабораторного материала', 'step'=>0.01));
		echo $this->Form->input('Detection', array('label'=>'Выявления (болезни)',
													  'empty' => 'не указано'));
		echo '<div class="row"><div class="col-md-6">';
		echo $this->Form->input('price', array('label'=>'Оказано платных услуг на сумму (руб.)','step'=>0.01));
		echo '</div>';
		echo '<div class="col-md-6">';
		echo $this->Form->input('check_number', array('label'=>'№ чека (квитанции)'));
		echo '</div></div>';
		echo $this->Form->input('state_price', array('label'=>'Оказано услуг по госзаданию на сумму (руб.)', 'step'=>0.01));
		?>
		<div class="panel panel-info">
			<div class="panel-heading" role="tab" id="conclusionHeadinng">
			  <h4 class="panel-title">
				<a class="collapsed" data-toggle="collapse" href="#collapseConclusion" aria-expanded="false" aria-controls="collapseConclusion">
				  Отбор проб и отправка на исследование для подтверждения
				</a>
			  </h4>
			</div>
			<div id="collapseConclusion" class="panel-collapse collapse" role="tabpanel" aria-labelledby="conclusionHeadinng">
			  <div class="panel-body">
		<?
		echo $this->Form->input('samples_count', array('label'=>'Количество проб'));
		echo $this->Form->input('conclusion_date', array(
													'label'=>'Дата заключения', 
													'id'=> 'datetimepicker_conclusion_date',
													'type'=>'text',
													'data-date-format'=>'YYYY-MM-DD',
													'beforeInput' => '<div class="input-group">',
													'afterInput' => '<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span></div>'
													));
		echo $this->Form->input('conclusion_number', array('label'=>'Номер заключения'));
		echo $this->Form->input('conclusion_id', array('type'=>'radio','legend'=>'Заключение',
													   'empty' => 'не указано'));
		//echo $this->Form->input('conclusion_weight', array('label'=>'Выпущено без ограничений', 'step'=>0.01));
		?>
				</div>
			</div>
		</div>
		<?
		echo $this->Form->input('note', array('label'=>'Примечание','type' => 'textarea', 'escape' => false,'rows' => '4', 'cols' => '100'));
		echo $this->Form->submit('Сохранить', array('formnovalidate' => true,
			'div' => 'form-group',
			'class' => 'btn btn-default'
		));?>
	</fieldset>
<?php echo $this->Form->end(); ?>


<?php
$this->start('css');?>
<link rel="stylesheet" href="/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css">
<link rel="stylesheet" href="/css/selectize.css">
<link rel="stylesheet" href="/css/selectize.bootstrap3.css">
<?php $this->end(); ?>

<?php
$this->start('script');?>
<script src="/js/moment.min.js"></script>
<script src="/js/moment.ru.js"></script>
<script src="/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js"></script>
<script src="/js/selectize.min.js"></script>
<script type="text/javascript">
$(function () {
	$('#datetimepicker_conclusion_date').datetimepicker({
		language: 'ru',
		pickTime: false
		//defaultDate: new Date()
	});
	
	$('#ExpertiseProductionId').selectize({
		plugins: ['restore_on_backspace'],
		create: false,
		selectOnTab: true,
		onInitialize: function() {this.selected_value = this.getValue();},
		onChange: function(value) {value=value==0?this.selected_value:value;this.selected_value=value;},
		onDropdownClose: function($dropdown) { 
			if(this.getValue()==0) {
				this.setValue(this.selected_value ); 
			}
		}
	});
	
	$('#DetectionDetection').selectize({
		//plugins: ['restore_on_backspace'],
		create: false,
		persist: false,
		selectOnTab: true,
		/*onInitialize: function() {this.selected_value = this.getValue();},
		onChange: function(value) {value=value==0?this.selected_value:value;this.selected_value=value;},
		onDropdownClose: function($dropdown) { 
			if(!this.getValue()) {
				this.setValue(0); 
			}
		}*/
	});
});
</script>

<?php $this->end(); ?>