<?php echo $this->Form->create('Lab', array(
	'inputDefaults' => array(
		'div' => 'form-group',
		'wrapInput' => false,
		'class' => 'form-control'
	),
	'class' => 'well'
)); ?>
	<fieldset>
		<legend><?php echo $title_for_layout ?></legend>
		<?php 
		echo $this->Form->input('name', array('label'=>'Название'));
		echo $this->Form->input('institution_id', array('label'=>'Учреждение ветиринарии'));
		echo $this->Form->input('region_id', array('label'=>'Регион'));
		echo $this->Form->input('market_name', array('label'=>'Имя рынка'));
		echo $this->Form->input('market_address', array('label'=>'Адрес рынка'));
		echo $this->Form->input('phone', array('label'=>'Телефон'));
		echo $this->Form->submit('Сохранить', array(
			'div' => 'form-group',
			'class' => 'btn btn-default'
		));?>
	</fieldset>
<?php echo $this->Form->end(); ?>