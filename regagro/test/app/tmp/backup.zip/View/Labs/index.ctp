<div class="row">
	<div class="col-md-2">
		<h4>Лаборатории</h4>
	</div>
	<div class="col-md-10">
		<?php /*echo $this->Form->create('Lab', array(
			'action'=> 'add',
			'inputDefaults' => array(
				'div' => 'form-group',
				'label' => false,
				'wrapInput' => false,
				'class' => 'form-control'
			),
			'class' => 'form-inline text-right'
		)); ?>
				<?php 
				echo $this->Form->input('name', array(
					'placeholder' => 'Название...',
					'div' => 'form-group'
				));?>
				
				<?php 
				echo $this->Form->input('region_id', array(
					'div' => 'form-group'
				));?>
				
				<?php
				echo $this->Form->submit('Добавить', array(
					'div' => 'form-group',
					'class' => 'btn btn-primary'
				));?>
		<?php echo $this->Form->end(); */?>
		<?php echo $this->Html->link('<span class="glyphicon glyphicon-plus"></span> Добавить',
						array('controller'=>'labs', 'action'=>'add'),
						array('escape'=>false, 'class'=>'btn btn-primary'))?>
	</div>
</div>
<?php echo $this->Paginator->pagination(array(
	'ul' => 'pagination pagination-sm'
)); ?>
<table class="table">
	<tr>
		<th>Название</th>
		<th>Учреждение</th>
		<th>Регион</th>
		<th>Рынок</th>
		<th>Адрес</th>
		<th>Телефон</th>
		<th>Удалить</th>
	</tr>
	<? 
	foreach ($labs as $lab)
	{
		echo '
		<tr>
			<td>'.$this->Html->link($lab['Lab']['name'], array(
					'action' => 'edit', $lab['Lab']['id'])).'
			</td>
			<td>'.$this->Html->link($lab['Institution']['name'], array('controller'=>'institutions',
					'action' => 'edit', $lab['Institution']['id'])).'</td>
			<td>'.$lab['Region']['name'].'</td>
			<td>'.$lab['Lab']['market_name'].'</td>
			<td>'.$lab['Lab']['market_address'].'</td>
			<td>'.$lab['Lab']['phone'].'</td>
			<td>'.$this->Html->link('<span class="glyphicon glyphicon-remove"></span>', array(
					'action' => 'delete', $lab['Lab']['id']),
					array(
						'escape'=>false
					)).'
			</td>
		</tr>';
	}
	?>
</table>
<?php echo $this->Paginator->pagination(array(
	'ul' => 'pagination pagination-sm'
)); ?>