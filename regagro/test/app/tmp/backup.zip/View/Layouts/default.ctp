<?php 
$user = $this->Session->read('Auth.User');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>
		ЛВСЭ -
		<?php echo $title_for_layout; ?>
	</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">

	<!--link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css"-->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">

	<style>
	body {
		padding-top: 70px; /* 70px to make the container go all the way to the bottom of the topbar */
	}
	.affix {
		position: fixed;
		top: 60px;
		width: 220px;
	}
		
	.form-group.required label:after { 
		color: #d00;
		content: "*";
		position: absolute;
		margin-left: 1px;
		margin-top:2px;
		font-family: 'Glyphicons Halflings';
		font-weight: normal;
		font-size: 8px;
	}
	</style>

	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

	<?php
	echo $this->fetch('meta');
	echo $this->fetch('css');
	?>
</head>

<body>
	<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
		<!--div class="container"-->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<?php echo $this->Html->link('ЛВСЭ', array(
					'controller' => 'pages',
					'action' => 'home'
				), array('class' => 'navbar-brand')); ?>
			</div>

			<div class="collapse navbar-collapse navbar-ex1-collapse">
				<ul class="nav navbar-nav">
					<?php
						if (isset($userActions))
						{
							foreach ($userActions as $a)
							{
								echo '
								<li>
									'.$this->Html->link($a['title'], $a['url']).'
								</li>';
							}
						}
					?>
				</ul>
				<? if(!empty($user)) {
                    echo '
					<small class="navbar-text navbar-right" style="margin-right:10px">
						'.$user['displayname'].' ['.$user['role'].']
						('.$this->Html->link('выход', array(
						'controller' => 'users',
						'action' => 'logout'
						), array(
						'class'=>'navbar-link')).')
					</small>';
                } else {
					echo '
					<p class="navbar-text navbar-right" style="margin-right:10px">
						'.$this->Html->link('вход', array(
						'controller' => 'users',
						'action' => 'login'
						), array(
						'class'=>'navbar-link')).'
					</p>';
				}?>
			</div>
		<!--/div-->
	</nav>

	<div class="container">
		<section id="alerts">
			<?php echo $this->Session->flash('success'); ?>
			<?php echo $this->Session->flash('info'); ?>
			<?php echo $this->Session->flash('warning'); ?>
			<?php echo $this->Session->flash('danger'); ?>
		</section>
		<?php echo $this->fetch('content'); ?>
	</div><!-- /container -->

	<!-- Placed at the end of the document so the pages load faster -->
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<!--script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script-->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
	<script src="//google-code-prettify.googlecode.com/svn/loader/run_prettify.js"></script>
	<!-- scripts_for_layout -->
	<?php echo $this->fetch('script'); ?>
	<?php //echo $scripts_for_layout; ?>
	<!-- Js writeBuffer -->
	<?php
	if (class_exists('JsHelper') && method_exists($this->Js, 'writeBuffer')) echo $this->Js->writeBuffer();
	// Writes cached scripts
	?>

</body>
</html>
