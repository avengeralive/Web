<?php echo $this->Form->create('Organ', array(
	'inputDefaults' => array(
		'div' => 'form-group',
		'wrapInput' => false,
		'class' => 'form-control'
	),
	'class' => 'well'
)); ?>
	<fieldset>
		<legend><?php echo $title_for_layout ?></legend>
		<?php 
		echo $this->Form->input('name', array('label'=>'Название'));
		echo $this->Form->input('order_type', array('label'=>'Распорядительный документ','options'=>array('приказ'=>'приказ','распоряжение'=>'распоряжение')));
		echo $this->Form->input('order_date', array('label'=>'Дата распорядительного документа',
													'id'=> 'datetimepicker_order_date',
													'type'=>'text',
													'data-date-format'=>'YYYY-MM-DD',
													'readonly'=>false,
													'beforeInput' => '<div class="input-group">',
													'afterInput' => '<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span></div>'));
		echo $this->Form->input('order_num', array('label'=>'Номер распорядительного документа'));
		echo $this->Form->submit('Сохранить', array(
			'div' => 'form-group',
			'class' => 'btn btn-default'
		));?>
	</fieldset>
<?php echo $this->Form->end(); ?>

<?php
$this->start('css');?>
<link rel="stylesheet" href="/css/selectize.css">
<link rel="stylesheet" href="/css/selectize.bootstrap3.css">
<link rel="stylesheet" href="/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css">
<?php $this->end(); ?>

<?php
$this->start('script');?>
<script src="/js/moment.min.js"></script>
<script src="/js/moment.ru.js"></script>
<script src="/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js"></script>
<script src="/js/selectize.min.js"></script>
<script type="text/javascript">
$(function () {
	$('#datetimepicker_order_date').datetimepicker({
		language: 'ru',
		pickTime: false,
		defaultDate: '<?php echo $organ['Organ']['order_date']?>'
	});
});
</script>
<?php $this->end();?>