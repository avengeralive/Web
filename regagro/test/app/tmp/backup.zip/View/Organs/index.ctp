<div class="row">
	<div class="col-md-6">
		<h4>Органы управления ветеринарии</h4>
	</div>
	<div class="col-md-6">
		<?php echo $this->Form->create('Organ', array(
			'action'=> 'add',
			'inputDefaults' => array(
				'div' => 'form-group',
				'label' => false,
				'wrapInput' => false,
				'class' => 'form-control'
			),
			'class' => 'form-inline text-right'
		)); ?>
				<?php 
				echo $this->Form->input('name', array(
					'placeholder' => 'Название...',
					'div' => 'form-group',
					'style' => 'width:250px'
				));?>
				
				<?php 
				echo 
					$this->Form->input('order_type', array(
					'options'=>array('приказ'=>'приказ','распоряжение'=>'распоряжение'),
					'div' => 'form-group',
					'style' => 'width:250px'
				));?>
				
				<?php 
				echo 
					$this->Form->input('order_date', array(
					'id'=> 'datetimepicker_order_date',
					'type'=>'text',
					'data-date-format'=>'YYYY-MM-DD',
					'readonly'=>false,
					'beforeInput' => '<div class="input-group">',
					'afterInput' => '<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span></div>',
					'div' => 'form-group',
					'style' => 'width:211px'
				));?>
				
				<?php 
				echo $this->Form->input('order_num', array(
					'placeholder' => 'Номер...',
					'div' => 'form-group',
					'style' => 'width:250px'
				));?>
				
				<?php
				echo $this->Form->submit('Добавить', array(
					'div' => 'form-group',
					'class' => 'btn btn-primary'
				));?>
		<?php echo $this->Form->end(); ?>
	</div>
</div>
<?php echo $this->Paginator->pagination(array(
	'ul' => 'pagination pagination-sm'
)); ?>
<table class="table">
	<tr>
		<th>Название</th>
		<th></th>
		<th></th>
		<th></th>
		<th>Удалить</th>
	</tr>
	<? 
	foreach ($organs as $organ)
	{
		echo '
		<tr>
			<td>'.$this->Html->link($organ['Organ']['name'], array(
					'action' => 'edit', $organ['Organ']['id'])).'
			</td>
			<td>'.$organ['Organ']['order_type'].'</td>
			<td>'.$organ['Organ']['order_date'].'</td>
			<td>'.$organ['Organ']['order_num'].'</td>
			<td>'.$this->Html->link('<span class="glyphicon glyphicon-remove"></span>', array(
					'action' => 'delete', $organ['Organ']['id']),
					array(
						'escape'=>false
					)).'
			</td>
		</tr>';
	}
	?>
</table>
<?php echo $this->Paginator->pagination(array(
	'ul' => 'pagination pagination-sm'
)); ?>