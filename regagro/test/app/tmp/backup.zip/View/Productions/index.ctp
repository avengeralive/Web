<div class="row">
	<div class="col-md-1">
		<h4>Продукция</h4>
	</div>
	<div class="col-md-11">
		<?php echo $this->Form->create('Production', array(
			'action'=> 'add',
			'inputDefaults' => array(
				'div' => 'form-group',
				'label' => false,
				'wrapInput' => false,
				'class' => 'form-control'
			),
			'class' => 'form-inline text-right'
		)); ?>
				<?php 
				echo $this->Form->input('name', array(
					'placeholder' => 'Название...',
					'div' => 'form-group'
				));
				echo $this->Form->input('production_type_id', array(
					'div' => 'form-group'
				));
				echo $this->Form->input('report_production_id', array(
					'div' => 'form-group'
				));
				echo $this->Form->input('measure_id', array(
					'div' => 'form-group'
				));?>
				<?php
				echo $this->Form->submit('Добавить', array(
					'div' => 'form-group',
					'class' => 'btn btn-primary'
				));?>
		<?php echo $this->Form->end(); ?>
	</div>
</div>
<?php echo $this->Paginator->pagination(array(
	'ul' => 'pagination pagination-sm'
)); ?>
<table class="table">
	<tr>
		<th>Название</th>
		<th>Вид продкции</th>
		<th>Для отчета</th>
		<th>Ед. измерения</th>
		<th>Удалить</th>
	</tr>
	<? 
	foreach ($productions as $production)
	{
		echo '
		<tr>
			<td>'.$this->Html->link($production['Production']['name'], array(
					'action' => 'edit', $production['Production']['id'])).'
			</td>
			<td>
			'.$production['ProductionType']['name'].'
			</td>
			<td>
			'.$production['ReportProduction']['name'].'
			</td>
			<td>
			'.$production['Measure']['name'].'
			</td>
			<td>'.$this->Html->link('<span class="glyphicon glyphicon-remove"></span>', array(
					'action' => 'delete', $production['Production']['id']),
					array(
						'escape'=>false
					)).'
			</td>
		</tr>';
	}
	?>
</table>
<?php echo $this->Paginator->pagination(array(
	'ul' => 'pagination pagination-sm'
)); ?>