<?php echo $this->Form->create('Region', array(
	'inputDefaults' => array(
		'div' => 'form-group',
		'wrapInput' => false,
		'class' => 'form-control'
	),
	'class' => 'well'
)); ?>
	<fieldset>
		<legend><?php echo $title_for_layout ?></legend>
		<?php 
		echo $this->Form->input('name', array(
		));
		echo $this->Form->submit('Сохранить', array(
			'div' => 'form-group',
			'class' => 'btn btn-default'
		));?>
	</fieldset>
<?php echo $this->Form->end(); ?>

<div class="row">
	<div class="col-md-4">
		<h4>Районы</h4>
	</div>
	<div class="col-md-8">
		<?php echo $this->Form->create('District', array(
			'action'=> 'add',
			'inputDefaults' => array(
				'div' => 'form-group',
				'label' => false,
				'wrapInput' => false,
				'class' => 'form-control'
			),
			'class' => 'form-inline text-right'
		)); ?>
				<?php 
				echo $this->Form->input('name', array(
					'placeholder' => 'Название района...',
					'div' => 'form-group'
				));?>
				
				<?php
				echo $this->Form->input('region_id', array('value'=>$region['Region']['id'], 'type'=>'hidden'));
				echo $this->Form->submit('Добавить', array(
					'div' => 'form-group',
					'class' => 'btn btn-primary'
				));?>
		<?php echo $this->Form->end(); ?>
	</div>
</div>
<table class="table">
	<tr>
		<th>Название</th>
		<th>Удалить</th>
	</tr>
	<? 
	foreach ($region['District'] as $district)
	{
		echo '
		<tr>
			<td>'.$this->Html->link($district['name'], array('controller' => 'districts',
					'action' => 'edit', $district['id'])).'
			</td>
			<td>'.$this->Html->link('<span class="glyphicon glyphicon-remove"></span>', array('controller' => 'districts',
					'action' => 'delete', $district['id']),
					array(
						'escape'=>false
					)).'
			</td>
		</tr>';
	}
	?>
</table>