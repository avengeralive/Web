<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title">Регионы</h3>
	<?php echo $this->Form->create('Region', array(
			'action'=> 'add',
			'inputDefaults' => array(
				'div' => 'form-group',
				'label' => false,
				'wrapInput' => false,
				'class' => 'form-control'
			),
			'class' => 'form-inline text-right'
		)); ?>
				<?php 
				echo $this->Form->input('name', array(
					'placeholder' => 'Название региона...',
					'div' => 'form-group'
				));?>
				
				<?php
				echo $this->Form->submit('Добавить', array(
					'div' => 'form-group',
					'class' => 'btn btn-primary'
				));?>
		<?php echo $this->Form->end(); ?>
  </div>
      <?php echo $this->Paginator->pagination(array(
		'ul' => 'pagination pagination-sm'
	)); ?>
	<table class="table table-hover">
		<tr>
			<th>Название</th>
			<th>Удалить</th>
		</tr>
		<? 
		foreach ($regions as $region)
		{
			echo '
			<tr>
				<td>'.$this->Html->link($region['Region']['name'], array('controller' => 'regions',
						'action' => 'edit', $region['Region']['id'])).'
				</td>
				<td>'.$this->Html->link('<span class="glyphicon glyphicon-remove"></span>', array('controller' => 'regions',
						'action' => 'delete', $region['Region']['id']),
						array(
							'escape'=>false
						)).'
				</td>
			</tr>';
		}
		?>
	</table>
	<?php echo $this->Paginator->pagination(array(
		'ul' => 'pagination pagination-sm'
	)); ?>
</div>