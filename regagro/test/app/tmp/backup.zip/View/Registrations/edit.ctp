<?php echo $this->Form->create('Registration', array(
	'inputDefaults' => array(
		'div' => 'form-group',
		'wrapInput' => false,
		'class' => 'form-control'
	),
	'class' => 'well'
)); ?>
	<fieldset>
		<legend>Общие данные</legend>
		<?php 
		echo $this->Form->input('id', array());
		echo //$this->Form->input('date', array('class'=>''));
		'<div class="form-group">
			<label for="RegistrationDate">Дата</label>
			<input type="text" id="datetimepicker_date" name="data[Registration][date]" class="form-control" 
				data-date-format="YYYY-MM-DD HH:mm" readonly>
		</div>';
		
		echo $this->Form->input('user_id', array('label'=>'Сотрудник', 'readonly'=>true));
		echo $this->Form->input('lab_id', array('label'=>'Лаборатория', 'readonly'=>true));
		echo $this->Form->input('production_type_id', array('label'=>'Вид продукции'));
		echo $this->Form->input('industrial', array('label'=>'Промышленная продукция','div'=>'checkbox', 'class'=>'checkbox'));
		echo $this->Form->input('transport_condition', array('label'=>'Состояние транспорта','options'=>array('не указано'=>'не указано','удовлетворительное'=>'удовлетворительное', 'неудовлетворительное'=>'неудовлетворительное')));
		?>
	</fieldset>
	<fieldset>
		<legend>Сопроводительный документ</legend>
		<?php 
		echo $this->Form->input('doc_form', array('label'=>'Название','options'=>array('не указано'=>'не указано', 'ВСД ф.№2'=>'ВСД ф.№2', 'ВСД ф.№3'=>'ВСД ф.№3', 'ВСД ф.№4'=>'ВСД ф.№4', 'Накладная'=>'Накладная')));
		echo $this->Form->input('doc_num', array('label'=>'Номер'));
		echo //$this->Form->input('doc_date', array());
		'<div class="form-group">
			<label for="RegistrationDate">Дата</label>
			<div class="input-group">
				<input type="text" id="datetimepicker_doc_date" name="data[Registration][doc_date]" class="form-control"
					data-date-format="YYYY-MM-DD" readonly>
				<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
			</div>
		</div>';
		?>
	</fieldset>
	<fieldset>
		<legend>Данные о происхождении продукции</legend>
		<?php 
		echo $this->Form->input('owner', array('label'=>'Владелец'));
		echo $this->Form->input('region_id', array('label'=>'Регион'));
		echo $this->Form->input('district_id', array('label'=>'Район'));
		echo $this->Form->input('locality', array('label'=>'Населенный пункт'));
		?>
	</fieldset>
	<?php
			echo $this->Form->submit('Сохранить', array(
			'div' => 'form-group',
			'class' => 'btn btn-default'
		));?>
		
<?php echo $this->Form->end(); ?>



<?php
$this->start('css');?>
<link rel="stylesheet" href="/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css">
<link rel="stylesheet" href="/css/selectize.css">
<link rel="stylesheet" href="/css/selectize.bootstrap3.css">
<?php $this->end(); ?>

<?php
$this->start('script');?>
<script src="/js/moment.min.js"></script>
<script src="/js/moment.ru.js"></script>
<script src="/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js"></script>
<script src="/js/selectize.min.js"></script>
<script type="text/javascript">
$(function () {
	$('#datetimepicker_date').datetimepicker({
		language: 'ru',
		pickTime: true,
		defaultDate: '<?php echo $registration['Registration']['date']?>'//new Date()
	});
	// $('#datetimepicker_date').on("dp.show",function (e) {
		// $('#datetimepicker_date').data("DateTimePicker").hide();
	// });
	$('#datetimepicker_doc_date').datetimepicker({
		language: 'ru',
		pickTime: false,
		defaultDate: '<?php echo $registration['Registration']['doc_date']?>'//new Date()
	});
	
	var xhr;
	var select_region, $select_region;
	var select_district, $select_district;
	
	$select_region = $('#RegistrationRegionId').selectize({
		plugins: ['restore_on_backspace'],
		create: false,
		selectOnTab: true,
		onInitialize: function() {this.selected_value = this.getValue();},
		onDropdownClose: function($dropdown) { 
			if(this.getValue()==0) {
				this.setValue(this.selected_value ); 
			}
		},
		onChange: function(value) {
			value=value==0?this.selected_value:value;this.selected_value=value;
			if (!value.length) return;
			select_district.disable();
			select_district.clearOptions();
			select_district.load(function(callback) {
				xhr && xhr.abort();
				xhr = $.ajax({
					type: 'post',
					data: 'data[region_id]='+select_region.selected_value,
					url: '<?php echo $this->Html->url(array('controller'=>'districts','action'=>'getByRegion', 'ext'=>'json'));?>',
					success: function(results) {
						select_district.enable();
						callback(results);
					},
					error: function() {
						callback();
					}
				})
			});
		}
	});

	$select_district = $('#RegistrationDistrictId').selectize({
		valueField: 'id',
		labelField: 'name',
		searchField: ['name'],
		plugins: ['restore_on_backspace'],
		create: false,
		selectOnTab: true,
		onInitialize: function() {this.selected_value = this.getValue();},
		onChange: function(value) {value=value==0?this.selected_value:value;this.selected_value=value;},
		onDropdownClose: function($dropdown) { 
			if(this.getValue()==0) {
				this.setValue(this.selected_value ); 
			}
		}
	});
	
	select_district  = $select_district[0].selectize;
	select_region = $select_region[0].selectize;

	//select_district.disable();
});

<?php

/*$this->Js->get('#RegistrationRegionId');
$data = $this->Js->serializeForm(array(
			'isForm' => true,
			'inline' => true
			));
$request = $this->Js->request(
			array(
				'controller'=>'districts',
				'action'=>'getByRegion'
			),
			array(
				'update'=>'#RegistrationDistrictId',
				'async' => true,
				'method' => 'post',
				'dataExpression'=>true,
				'data'=> $data.'.replace(\'%5BRegistration%5D\',\'\')'
			)
		);
$this->Js->event('change', $request);
	
//echo $request; //first request*/
?>
</script>

<?php $this->end(); ?>