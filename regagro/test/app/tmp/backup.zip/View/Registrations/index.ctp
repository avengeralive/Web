<div class="col-xs-2" style="padding:0 4px 0 0;width:110px;">
	<div class='input-group'>
		<input type="text" data-date-format="YYYY-MM-DD" id="pick_doc_date" class="form-control input-sm small" style="height:22px;">
		<span class="input-group-addon" style="height:22px;padding:0 2px 0 2px"><span class="glyphicon glyphicon-calendar"></span>
		</span>
	</div>
</div>

<?php
echo $this->Html->link('<span class="glyphicon glyphicon-floppy-open"></span> Журнал',
				array('controller'=>'registrations', 'action'=>'daily_registrations_xml'),
				array('escape'=>false, 'class'=>'btn btn-primary btn-xs', 'id'=>'daily_registrations_link'));
?> 
<?
echo $this->Html->link('<span class="glyphicon glyphicon-floppy-open"></span> Акт денатурации (мясо, рыба)',
				array('controller'=>'registrations', 'action'=>'denaturation_doc', 'meat_fish'),
				array('escape'=>false, 'class'=>'btn btn-primary btn-xs', 'id'=>'denaturation_meat_fish_link'));
?> 
<?
echo $this->Html->link('<span class="glyphicon glyphicon-floppy-open"></span> Акт денатурации (пищевые продукты)',
				array('controller'=>'registrations', 'action'=>'denaturation_doc', 'other'),
				array('escape'=>false, 'class'=>'btn btn-primary btn-xs', 'id'=>'denaturation_other_link'));
?>
<br/>
<?
echo $this->Paginator->pagination(array(
	'ul' => 'pagination pagination-sm'
)); ?>

<table class="table table-hover table-bordered small">
	<tr>
		<th colspan="3">Общие данные</th>
		<th colspan="3">Сопроводительный документ</th>
		<th colspan="5">Данные о происхождении продукции</th>
		<th rowspan="2">Удалить</th>
	</tr>
	<tr>
		<th>Код</th>
		<th>Дата экспертизы</th>
		<th>Сотрудник</th>
		<th>Название</th>
		<th>Номер</th>
		<th>Дата</th>
		<th>Владелец</th>
		<th>Вид продукции</th>
		<th>Регион</th>
		<th>Район</th>
		<th>Нас. пункт</th>
	</tr>
	<?
	foreach ($registrations as $reg)
	{
		$delete = '';
		if(AuthComponent::user('role')!='Администратор' && $reg['Registration']['date']<date('Y-m-d'))
		{
			$delete = '<span class="glyphicon glyphicon-remove"></span>';
		} else {
			$delete = $this->Html->link('<span class="glyphicon glyphicon-remove"></span>', array('controller' => 'registrations',
					'action' => 'delete', $reg['Registration']['id']),
					array(
						'escape'=>false
					));
		}
		echo '
		<tr>
			<td>'.$this->Html->link($reg['Registration']['code'], array('controller' => 'registrations',
					'action' => 'overview', $reg['Registration']['id'])).'
			</td>
			<td>'.date_format(date_create($reg['Registration']['date']), 'd.m.Y').'</td>
			<td>'.$reg['User']['displayname'].'</td>
			<td>'.$reg['Registration']['doc_form'].'</td>
			<td>'.$reg['Registration']['doc_num'].'</td>
			<td>'.date_format(date_create($reg['Registration']['doc_date']), 'd.m.Y').'</td>
			<td>'.$reg['Registration']['owner'].'</td>
			<td>'.$reg['ProductionType']['name'].'</td>
			<td>'.$reg['Region']['name'].'</td>
			<td>'.$reg['District']['name'].'</td>
			<td>'.$reg['Registration']['locality'].'</td>
			<td>'.$delete.'
			</td>
		</tr>';
	}
	?>
</table>
<?php echo $this->Paginator->pagination(array(
	'ul' => 'pagination pagination-sm'
)); ?>


<?php
$this->start('css');?>
<link rel="stylesheet" href="/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css">
<?php $this->end(); ?>

<?php
$this->start('script');?>
<script src="/js/moment.min.js"></script>
<script src="/js/moment.ru.js"></script>
<script src="/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
$(function () {

	$('#pick_doc_date').datetimepicker({
		language: 'ru',
		pickTime: false,
		defaultDate: new Date()
	});
	
	$('#pick_doc_date').on('dp.change',function (e) {
		$('#daily_registrations_link').attr('href', '<?php echo $this->Html->url(array('controller'=>'registrations', 'action'=>'daily_registrations_xml'))?>/'+$('#pick_doc_date').val());
		$('#denaturation_meat_fish_link').attr('href', '<?php echo $this->Html->url(array('controller'=>'registrations', 'action'=>'denaturation_doc', 'meat_fish'))?>/'+$('#pick_doc_date').val());
		$('#denaturation_other_link').attr('href', '<?php echo $this->Html->url(array('controller'=>'registrations', 'action'=>'denaturation_doc', 'other'))?>/'+$('#pick_doc_date').val());
	});
});
</script>

<?php $this->end(); ?>
