<div class="row small">
	<div class="col-md-4">
		<u>Общие данные</u><br/>
		Код: <?php echo $registration['Registration']['code']?><br/>
		Дата: <?php echo date_format(date_create($registration['Registration']['date']), 'd.m.Y H:i')?><br/>
		Сотрудник: <?php echo $registration['User']['displayname']?><br/>
		Состояние транспорта: <?php echo $registration['Registration']['transport_condition']?><br/>
	</div>
	<div class="col-md-4">
		<u>Сопроводительный документ</u><br/>
		Название: <?php echo $registration['Registration']['doc_form']?><br/>
		Номер: <?php echo $registration['Registration']['doc_num']?><br/>
		Дата: <?php echo $registration['Registration']['doc_date']?><br/>
	</div>
	<div class="col-md-4">
		<u>Данные о происхождении продукции</u><br/>
		Владелец: <?php echo $registration['Registration']['owner']?><br/>
		Регион: <?php echo $registration['Region']['name']?><br/>
		Район: <?php echo $registration['District']['name']?><br/>
		Нас. пункт: <?php echo $registration['Registration']['locality']?><br/>
	</div>
</div>

<ul class="nav nav-tabs" role="tablist">
  <li class="active"><a href="#expertises" role="tab" data-toggle="tab">Экспертизы</a></li>
  <li><a href="#researches" role="tab" data-toggle="tab">Исследования</a></li>
  <li><a href="#bans" role="tab" data-toggle="tab">Снято с реализации</a></li>
  <li><a href="#distributions" role="tab" data-toggle="tab">Распределено по точкам</a></li>
  <li><a href="#samples" role="tab" data-toggle="tab">Отбор проб</a></li>
</ul>
<?php $this->start('css');?>
<style>

table#expertisesTable {
	table-layout:fixed;
	word-wrap:break-word;
}

</style>
<?php $this->end();?>
<div class="tab-content">
	<div class="tab-pane fade in active" id="expertises">
		<table id="expertisesTable" class="table table-condensed table-hover table-bordered small tablesorter">
			<thead>
				<tr>
					<th style="width:60px">№</th>
					<th style="width:100px">Продукция</th>
					<th style="width:65px">Ед. измер.</th>
					<th style="width:60px">Кол-во экспертиз</th>
					<th style="width:60px">Наличие внутренних органов</th>
					<th style="width:95px">Термическое состояние</th>
					<th style="width:80px">Общий вес в кг (объем в л, яйцо в шт.)</th>
					<th style="width:60px">Отработанный материал</th>
					<th style="width:100px">Выявления</th>
					<th style="width:65px">Сумма (руб.)</th>
					<th style="width:60px">№ чека</th>
					<th style="width:60px">Количество проб</th>
					<th style="width:95px">Дата заключения</th>
					<th style="width:60px">Номер заключения</th>
					<th style="width:60px">Заключение</th>
					<th style="width:60px">Выпущено без ограничений</th>
					<th style="width:60px">Примечание</th>
					<th style="width:30px" class="sorter-false">Удалить</th>
				</tr>
			</thead>
			<?php
				foreach ($registration['Expertise'] as $exp)
				{
					echo '
					<tr>
						<td>'.$this->Html->link($registration['Registration']['code'].'/'.$exp['num'], array('controller'=>'expertises', 'action'=>'edit', $exp['id'])).'</td>
						<td><span>'.$exp['Production']['name'].'<br/>
						Изготовитель: '.$exp['manufacturer'].'
						<span></td>
						<td>'.$exp['Production']['Measure']['name'].'</td>
						<td>'.$exp['count'].'</td>
						<td>'.($exp['viscera']?'Да':'Нет').'</td>
						<td>'.$exp['thermal_state'].'</td>
						<td>Отеч. пр-я: '.$this->Number->precision($exp['domestic_weight'],2).'<br />
						Зар. пр-я: '.$this->Number->precision($exp['foreign_weight'],2).'</td>
						<td>'.$exp['samples_weight'].'</td>
						<td>'.(count($exp['Detection'])>=1?implode(', ',Hash::extract($exp['Detection'],'{n}.name')):'').'</td>
						<td>'.$this->Number->precision($exp['price'],2).'</td>
						<td>'.$exp['check_number'].'</td>
						<td>'.$exp['samples_count'].'</td>
						<td>'.(isset($exp['conclusion_date'])?date_format(date_create($exp['conclusion_date']), 'd.m.Y'):'').'</td>
						<td>'.$exp['conclusion_number'].'</td>
						<td>'.(isset($exp['Conclusion']['name'])?$exp['Conclusion']['name']:'').'</td>
						<td>'.$exp['conclusion_weight'].'</td>
						<td>'.$exp['note'].'</td>
						<td>'.$this->Html->link('<span class="glyphicon glyphicon-remove"></span>',
												array('controller'=>'expertises', 'action'=>'delete', $exp['id']),
												array('escape'=>false)).'</td>
					</tr>
					';
				}
			?>
		</table>
		<?php echo $this->Html->link('<span class="glyphicon glyphicon-plus"></span> Добавить',
						array('controller'=>'expertises', 'action'=>'add', $registration['Registration']['id']),
						array('escape'=>false, 'class'=>'btn btn-primary btn-xs'))?>
	</div>
	<div class="tab-pane fade" id="researches">
		<table class="table table-hover table-bordered small tablesorter">
			<thead>
				<tr>
					<th class="sorter-false"><span class="glyphicon glyphicon-pencil"></span></th>
					<th>Продукция</th>
					<th>Вид исследований</th>
					<th>Количество исследований</th>
					<th>Результат исследований</th>
					<th>Показатели</th>
					<th>Подтверждение лаборатории</th>
					<th class="sorter-false">Удалить</th>
				</tr>
			</thead>
			<?php
				foreach ($registration['Research'] as $res)
				{
					echo '
					<tr>
						<td>'.$this->Html->link('<span class="glyphicon glyphicon-pencil"></span>',
												array('controller'=>'researches', 'action'=>'edit', $res['id']),
												array('escape'=>false)).'</td>
						<td>'.$res['Production']['name'].'</td>
						<td>'.$res['ResearchType']['name'].'</td>
						<td>'.$res['count'].'</td>
						<td>'.$res['ResearchResult']['name'].'</td>
						<td>'.$res['indicators'].'</td>
						<td>'.($res['confirmed']?'да':'нет').'</td>
						<td>'.$this->Html->link('<span class="glyphicon glyphicon-remove"></span>',
												array('controller'=>'researches', 'action'=>'delete', $res['id']),
												array('escape'=>false)).'</td>
					</tr>';
				}
			?>
		</table>
		<?php echo $this->Html->link('<span class="glyphicon glyphicon-plus"></span> Добавить',
				array('controller'=>'researches', 'action'=>'add', $registration['Registration']['id']),
				array('escape'=>false, 'class'=>'btn btn-primary btn-xs'))?>
	</div>
	<div class="tab-pane fade" id="bans">
		<table class="table table-hover table-bordered small tablesorter">
			<thead>
				<tr>
					<th class="sorter-false"><span class="glyphicon glyphicon-pencil"></span></th>
					<th>Продукция</th>
					<th>Снятая продукция</th>
					<th>Вес снятой продукции в кг (объем в л, яйцо в шт.)</th>
					<th>Причины</th>
					<th>Примечание</th>
					<th>Порядок использования</th>
					<th class="sorter-false">Удалить</th>
				</tr>
			</thead>
			<?php
				foreach ($registration['Ban'] as $ban)
				{
					echo '
					<tr>
						<td>'.$this->Html->link('<span class="glyphicon glyphicon-pencil"></span>',
												array('controller'=>'bans', 'action'=>'edit', $ban['id']),
												array('escape'=>false)).'</td>
						<td>'.$ban['Production']['name'].'</td>
						<td>'.$ban['BanType']['name'].'</td>
						<td>'.$ban['weight'].'</td>
						<td>'.(isset($ban['BanReason']['name'])?$ban['BanReason']['name']:'').'</td>
						<td>'.$ban['note'].'</td>
						<td>'.$ban['UseOrder']['name'].'</td>
						<td>'.$this->Html->link('<span class="glyphicon glyphicon-remove"></span>',
												array('controller'=>'bans', 'action'=>'delete', $ban['id']),
												array('escape'=>false)).'</td>
					</tr>';
				}
			?>
		</table>
		<?php echo $this->Html->link('<span class="glyphicon glyphicon-plus"></span> Добавить',
				array('controller'=>'bans', 'action'=>'add', $registration['Registration']['id']),
				array('escape'=>false, 'class'=>'btn btn-primary btn-xs'))?>
		<?php echo $this->Html->link('<span class="glyphicon glyphicon-floppy-open"></span> Акт выбраковки',
				array('controller'=>'registrations', 'action'=>'ban_doc', $registration['Registration']['id'], '?'=>array('date'=>date('U'))),
				array('escape'=>false, 'class'=>'btn btn-primary btn-xs'))?>
		<br/>
		<br/>
		<a href='/files/vetsan.pps' class='btn btn-primary btn-xs'><span class="glyphicon glyphicon-floppy-open"></span> Ветсаноценка</a>
	</div>
	<div class="tab-pane fade" id="distributions">
		<table class="table table-hover table-bordered small tablesorter">
			<thead>
				<tr>
					<th class="sorter-false" style="width:140px"><span class="glyphicon glyphicon-pencil"></span></th>
					<th>Торгующему</th>
					<th>Продукция</th>
					<th>Количество туш (тушек, партий, т/мест)</th>
					<th>Вес в кг (объем в л, яйцо в шт.)</th>
					<th>Количество мест</th>
					<th>Примечание</th>
					<th class="sorter-false">Удалить</th>
				</tr>
			</thead>
			<?php
				foreach ($registration['Distribution'] as $dis)
				{
					echo '
					<tr>
						<td>'.$this->Html->link('<span class="glyphicon glyphicon-pencil"></span>',
												array('controller'=>'distributions', 'action'=>'edit', $dis['id']),
												array('escape'=>false,'class'=>'btn btn-default btn-xs')).' '.
							$this->Html->link('<span class="glyphicon glyphicon-floppy-open"></span> Заключение',
							array('controller'=>'registrations', 'action'=>'distributor_doc', $registration['Registration']['id'], $dis['distributor'], '?'=>array('date'=>date('U'))),
							array('escape'=>false, 'class'=>'btn btn-primary btn-xs')).'<br />'.
							$this->Html->link('<span class="glyphicon glyphicon-floppy-open"></span> Заключение 1',
							array('controller'=>'registrations', 'action'=>'distributor_doc', $registration['Registration']['id'], $dis['distributor'], '1', '?'=>array('date'=>date('U'))),
							array('escape'=>false, 'class'=>'btn btn-primary btn-xs', 'style'=>'margin: 4px 0 0px 0;')).
						'</td>
						<td>'.$dis['distributor'].'</td>
						<td>'.$dis['Production']['name'].'</td>
						<td>'.$dis['count'].'</td>
						<td>'.$dis['weight'].'</td>
						<td>'.$dis['places'].'</td>
						<td>'.$dis['note'].'</td>
						<td>'.$this->Html->link('<span class="glyphicon glyphicon-remove"></span>',
												array('controller'=>'distributions', 'action'=>'delete', $dis['id']),
												array('escape'=>false)).'</td>
					</tr>';
				}
			?>
		</table>
		<?php echo $this->Html->link('<span class="glyphicon glyphicon-plus"></span> Добавить',
				array('controller'=>'distributions', 'action'=>'add', $registration['Registration']['id']),
				array('escape'=>false, 'class'=>'btn btn-primary btn-xs'))?>
		
		<?php echo $this->Html->link('<span class="glyphicon glyphicon-plus"></span> Автоматически',
				array('controller'=>'distributions', 'action'=>'autofill', $registration['Registration']['id']),
				array('escape'=>false, 'class'=>'btn btn-primary btn-xs'))?>
	</div>
	<div class="tab-pane fade" id="samples">
		<table class="table table-hover table-bordered small tablesorter">
			<thead>
				<tr>
					<th style="min-width:145px">Код</th>
					<th>Продукция</th>
					<th>Вес партии</th>
					<th>Проба направляется в</th>
					<th>Нормативный документ</th>
					<th style="min-width:170px">Пробы</th>
					<th style="min-width:170px">Материалы</th>
					<th>Пробег</th>
					<th>Цель отбора проб</th>
					<th>Маркировка</th>
					<th>Хранение контрольной пробы</th>
					<th>Вид упаковки</th>
					<th>Номер печати, пломбы</th>
					<th class="sorter-false">Удалить</th>
				</tr>
			</thead>
			<?php
				foreach ($registration['Sample'] as $sam)
				{
					echo '
					<tr>
						<td>'.$this->Html->link($sam['code'],
												array('controller'=>'samples', 'action'=>'edit', $sam['id']),
												array('escape'=>false,'class'=>'btn btn-default btn-xs')).' '.
							$this->Html->link('<span class="glyphicon glyphicon-floppy-open"></span> Направление',
							array('controller'=>'registrations', 'action'=>'sample_doc', $registration['Registration']['id'], $sam['id'], '?'=>array('date'=>date('U'))),
							array('escape'=>false, 'class'=>'btn btn-primary btn-xs')).'<br/>'.
							$this->Html->link('<span class="glyphicon glyphicon-floppy-open"></span> Акт отбора проб',
							array('controller'=>'registrations', 'action'=>'sample_act_doc', $registration['Registration']['id'], $sam['id'], '?'=>array('date'=>date('U'))),
							array('escape'=>false, 'class'=>'btn btn-primary btn-xs', 'style'=>'margin: 4px 0 0px 0;')).
						'</td>
						<td>'.$sam['Production']['name'].'</td>
						<td>'.$sam['total_weight'].'</td>
						<td>'.$sam['Vetlab']['name'].'</td>
						<td>'.$sam['doc'].'</td>
						<td>
						    Кол-во: '.$sam['count'].'<br/>
							Вес: '.$sam['samples_weight'].'</td>
						<td>Сейф-пакет: '.$sam['packages'].'<br/>
							Перчатки одноразовые: '.$sam['gloves'].'<br/>
							Бутылка пластиковая: '.$sam['bottles'].'<br/>
							Пластиковый контейнер: '.$sam['containers'].'<br/>
							Прочее: '.$sam['other'].'</td>
						<td>'.$sam['auto'].'</td>
						<td>'.$sam['SamplePurpose']['name'].'</td>
						<td>'.$sam['mark'].'</td>
						<td>'.$sam['control_sample'].'</td>
						<td>'.$sam['package_type'].'</td>
						<td>'.$sam['mark_number'].'</td>
						<td>'.$this->Html->link('<span class="glyphicon glyphicon-remove"></span>',
												array('controller'=>'samples', 'action'=>'delete', $sam['id']),
												array('escape'=>false)).'</td>
					</tr>';
				}
			?>
		</table>
		<?php echo $this->Html->link('<span class="glyphicon glyphicon-plus"></span> Добавить',
				array('controller'=>'samples', 'action'=>'add', $registration['Registration']['id']),
				array('escape'=>false, 'class'=>'btn btn-primary btn-xs'))?>
	</div>
</div>

<?php $this->start('css');?>
<style>
	.tablesorter th {
		cursor: pointer;
	}	
	.tablesorter-header {
		/* black (unsorted) double arrow */
		background-image: url(data:image/gif;base64,R0lGODlhFQAJAIAAACMtMP///yH5BAEAAAEALAAAAAAVAAkAAAIXjI+AywnaYnhUMoqt3gZXPmVg94yJVQAAOw==);
		/* white (unsorted) double arrow */
		/* background-image: url(data:image/gif;base64,R0lGODlhFQAJAIAAAP///////yH5BAEAAAEALAAAAAAVAAkAAAIXjI+AywnaYnhUMoqt3gZXPmVg94yJVQAAOw==); */
		/* image */
		background-repeat: no-repeat;
		background-position: 100% 50%;
		padding: 4px 18px 4px 4px !important;
		white-space: normal;
		cursor: pointer;
		vertical-align:middle !important;
	}
	.tablesorter-headerAsc {
		background-image: url(data:image/gif;base64,R0lGODlhFQAEAIAAACMtMP///yH5BAEAAAEALAAAAAAVAAQAAAINjI8Bya2wnINUMopZAQA7);
		color: #000000;
	}
	.tablesorter-headerDesc {
		background-image: url(data:image/gif;base64,R0lGODlhFQAEAIAAACMtMP///yH5BAEAAAEALAAAAAAVAAQAAAINjB+gC+jP2ptn0WskLQA7);
		color: #000000;
	}
	
	.sorter-false {
		cursor: default !important;
		background-image: none;
		padding: 8px 8px !important;
	}
</style>
<?php $this->end(); ?>

<?php $this->start('script');?>
<script src="/js/jquery.tablesorter.min.js"></script>
<script type="text/javascript">
$(function () {
	$('table').tablesorter();
});
</script>

<?php $this->end(); ?>