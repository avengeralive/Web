<div class="row">
<?php echo $this->Form->create('Report', array(
	'inputDefaults' => array(
		'div' => 'form-group',
		'wrapInput' => false,
		'class' => 'form-control'
	)
)); 
	if (AuthComponent::user('role')=='Администратор'
		||
		(AuthComponent::user('organ_id')&&AuthComponent::user('organ_id')!=0)
		||
		(AuthComponent::user('institution_id')&&AuthComponent::user('institution_id')!=0)) 
	{
		echo $this->Form->input('institution_id', array('label'=>'Учреждение ветеринарии', 'div'=>'col-sm-10'));
		echo $this->Form->input('lab_id', array('label'=>'Лаборатория', 'div'=>'col-sm-10'));
	}
	echo $this->Form->input('date_from', array( 'label'=>'Дата от', 
												'id'=> 'datetimepicker_date_from',
												'type'=>'text',
												'data-date-format'=>'YYYY-MM-DD',
												'div'=>'col-sm-5',
												'beforeInput' => '<div class="input-group">',
												'afterInput' => '<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span></div>'
											));
	echo $this->Form->input('date_to', array(   'label'=>'Дата до', 
												'id'=> 'datetimepicker_date_to',
												'type'=>'text',
												'data-date-format'=>'YYYY-MM-DD',
												'div'=>'col-sm-5',
												'beforeInput' => '<div class="input-group">',
												'afterInput' => '<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span></div>'
											));
	echo $this->Form->submit('Сформировать', array(
			'div' => 'form-group col-sm-10',
			'class' => 'btn btn-default',
			'style' => 'margin: 15px 0px'
		));
	echo $this->Form->end(); 
?>
</div>
<div class="row">
	<?php
	if(isset($data))
	{
	?>
	<div class="panel panel-default">
	  <div class="panel-heading">
		<h3 class="panel-title">5-ВЕТ</h3>
	  </div>
	  <div class="panel-body">
	<?
		$institution_id = isset($data['Report']['institution_id'])?$data['Report']['institution_id']:'all';
		echo $this->Html->link('ОТЧЕТ 5-ВЕТ',
			array('controller'=>'registrations',
				  'action'=>'vet5_xml',
				  $institution_id,
				  $data['Report']['lab_id'],
				  $data['Report']['date_from'],
				  $data['Report']['date_to']));
		?><br/><?php
		echo $this->Html->link('Приложение 1: РАСШИФРОВКА ГРАФ «ДРУГИЕ ВИДЫ» РАЗДЕЛА III ОТЧЕТА 5-ВЕТ',
			array('controller'=>'registrations',
				  'action'=>'vet5_1_doc',
				  $institution_id,
				  $data['Report']['lab_id'],
				  $data['Report']['date_from'],
				  $data['Report']['date_to']));
		?><br/><?php
		echo $this->Html->link('Приложение 2: РАСШИФРОВКА ИНФОРМАЦИИ О КОЛИЧЕСТВЕ И РЕЗУЛЬТАТАХ ПРОВЕДЕННЫХ ИССЛЕДОВАНИЙ РАЗДЕЛА III ОТЧЕТА 5-ВЕТ',
			array('controller'=>'registrations',
				  'action'=>'vet5_2_xml',
				  $institution_id,
				  $data['Report']['lab_id'],
				  $data['Report']['date_from'],
				  $data['Report']['date_to']));
		?><br/><?php		  
		echo $this->Html->link('Приложение 3: РАСШИФРОВКА ИНФОРМАЦИИ О ВЫЯВЛЕННЫХ БОЛЕЗНЯХ РАЗДЕЛА III ОТЧЕТА 5-ВЕТ',
			array('controller'=>'registrations',
				  'action'=>'vet5_3_xml',
				  $institution_id,
				  $data['Report']['lab_id'],
				  $data['Report']['date_from'],
				  $data['Report']['date_to']));
		?><br/><?php		  
		echo $this->Html->link('Приложение 4: РАСШИФРОВКА ИНФОРМАЦИИ О СНЯТОЙ С РЕАЛИЗАЦИИ ПРОДУКЦИИ РАЗДЕЛА III ОТЧЕТА 5-ВЕТ',
			array('controller'=>'registrations',
				  'action'=>'vet5_4_xml',
				  $institution_id,
				  $data['Report']['lab_id'],
				  $data['Report']['date_from'],
				  $data['Report']['date_to']));
		?><br/><?php		  
		echo $this->Html->link('Приложение 5: РАСШИФРОВКА ГРАФЫ «ДРУГИЕ ПИЩЕВЫЕ ПРОДУКТЫ» РАЗДЕЛА IV ОТЧЕТА 5-ВЕТ',
			array('controller'=>'registrations',
				  'action'=>'vet5_5_xml',
				  $institution_id,
				  $data['Report']['lab_id'],
				  $data['Report']['date_from'],
				  $data['Report']['date_to']));
		?><br/><?php		  
		echo $this->Html->link('Приложение 6: РАСШИФРОВКА ИНФОРМАЦИИ О ПРОВЕДЕННЫХ ИССЛЕДОВАНИЯХ РАЗДЕЛА IV ОТЧЕТА 5-ВЕТ',
			array('controller'=>'registrations',
				  'action'=>'vet5_6_xml',
				  $institution_id,
				  $data['Report']['lab_id'],
				  $data['Report']['date_from'],
				  $data['Report']['date_to']));
		?><br/><?php		  
		echo $this->Html->link('Приложение 7: ИНФОРМАЦИЯ О ВЫЯВЛЕННЫХ БОЛЕЗНЯХ И НЕСООТВЕТСТВИЯХ РАЗДЕЛА IV ОТЧЕТА 5-ВЕТ',
			array('controller'=>'registrations',
				  'action'=>'vet5_7_xml',
				  $institution_id,
				  $data['Report']['lab_id'],
				  $data['Report']['date_from'],
				  $data['Report']['date_to']));
		?><br/><?php		  
		echo $this->Html->link('Приложение 8: РАСШИФРОВКА ИНФОРМАЦИИ О СНЯТОЙ С РЕАЛИЗАЦИИ ПРОДУКЦИИ РАЗДЕЛА IV ОТЧЕТА 5-ВЕТ',
			array('controller'=>'registrations',
				  'action'=>'vet5_8_xml',
				  $institution_id,
				  $data['Report']['lab_id'],
				  $data['Report']['date_from'],
				  $data['Report']['date_to']));
		  ?>
		</div>
	</div>	
	<div class="panel panel-default">
		<div class="panel-heading">
			<h3 class="panel-title">Отчеты с индексом "И"</h3>
		</div>
		<div class="panel-body">
		</div>	
	</div>
	<div class="panel panel-default">
		<div class="panel-heading">
			<h3 class="panel-title">Прочие сводные отчеты</h3>
		</div>
		<div class="panel-body">
		<?php		  
		echo $this->Html->link('СВОДНЫЕ ДАННЫЕ ПО КОЛИЧЕСТВУ ЭКСПЕРТИЗ И СУММЕ ОКАЗАННЫХ УСЛУГ',
			array('controller'=>'registrations',
				  'action'=>'expertises_prices',
				  $institution_id,
				  $data['Report']['lab_id'],
				  $data['Report']['date_from'],
				  $data['Report']['date_to']));
		  ?>
		</div>
	</div>
		  <?
	}
	?>	
</div>
<?php
$this->start('css');?>
<link rel="stylesheet" href="/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css">
<link rel="stylesheet" href="/css/selectize.css">
<link rel="stylesheet" href="/css/selectize.bootstrap3.css">
<?php $this->end(); ?>

<?php
$this->start('script');?>
<script src="/js/moment.min.js"></script>
<script src="/js/moment.ru.js"></script>
<script src="/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js"></script>
<script src="/js/selectize.min.js"></script>
<script type="text/javascript">
$(function () {

	$('#datetimepicker_date_from').datetimepicker({
		language: 'ru',
		pickTime: false,
		//defaultDate: ''
	});
	$('#datetimepicker_date_to').datetimepicker({
		language: 'ru',
		pickTime: false,
		//defaultDate: ''
	});

	var xhr;
	var select_institution, $select_institution;
	var select_lab, $select_lab;
	
	$select_institution = $('#ReportInstitutionId').selectize({
		plugins: ['restore_on_backspace'],
		create: false,
		selectOnTab: true,
		onInitialize: function() {this.selected_value = this.getValue();},
		onDropdownClose: function($dropdown) { 
			if(this.getValue()=='') {
				this.setValue(this.selected_value ); 
			}
		},
		sortField: [[]],
		onChange: function(value) {
			value=value==''?this.selected_value:value;this.selected_value=value;
			if (!value.length) return;
			select_lab.disable();
			select_lab.clearOptions();
			select_lab.load(function(callback) {
				xhr && xhr.abort();
				xhr = $.ajax({
					type: 'post',
					data: 'data[institution_id]='+select_institution.selected_value,
					url: '<?php echo $this->Html->url(array('controller'=>'labs','action'=>'getByInstitution', 'ext'=>'json'));?>',
					success: function(results) {
						select_lab.enable();
						callback(results);
						select_lab.setValue('all');
					},
					error: function() {
						callback();
					}
				})
			});
		}
	});

	$select_lab = $('#ReportLabId').selectize({
		valueField: 'id',
		labelField: 'name',
		searchField: ['name'],
		plugins: ['restore_on_backspace'],
		create: false,
		selectOnTab: true,
		sortField: [[]],
		onInitialize: function() {this.selected_value = 'all';},//this.getValue();},
		onChange: function(value) {
			value=value==''?'all':value;
			value=value=='all'?this.selected_value:value;
			this.selected_value=value;
		},
		onDropdownClose: function($dropdown) { 
			if(this.getValue()=='') {
				this.setValue('all');
			}
		}
	});
	
	select_lab  = $select_lab[0].selectize;
	select_institution = $select_institution[0].selectize;

	//select_lab.disable();
	
});
</script>

<?php $this->end(); ?>