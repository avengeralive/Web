<?php 
use PhpOffice\PhpWord\Autoloader;
use PhpOffice\PhpWord\Settings;
use PhpOffice\PhpWord\IOFactory;

error_reporting(E_ALL);
define('CLI', (PHP_SAPI == 'cli') ? true : false);
define('EOL', CLI ? PHP_EOL : '<br />');
define('SCRIPT_FILENAME', basename($_SERVER['SCRIPT_FILENAME'], '.php'));
define('IS_INDEX', SCRIPT_FILENAME == 'index');

require_once __DIR__ . '../../../Vendor/PhpWord/Autoloader.php';
Autoloader::register();
Settings::loadConfig();

// Set writers
$writers = array('Word2007' => 'docx', 'ODText' => 'odt', 'RTF' => 'rtf', 'HTML' => 'html', 'PDF' => 'pdf');
try{
$phpWord = new \PhpOffice\PhpWord\PhpWord();
$document = $phpWord->loadTemplate(APP.'/docTemplates/sample.docx');
$document->setValue('registration_code', $registration['Registration']['code']);
$document->setValue('sample_code', $registration['Sample'][0]['code']);
$document->setValue('registration_date', date_format(date_create($registration['Registration']['date']),'d.m.Y'));
$document->setValue('lab_name', $registration['Lab']['name']);
$document->setValue('institution_name', $registration['Lab']['Institution']['name']);
$document->setValue('organ_name', $registration['Lab']['Institution']['Organ']['name']);
$document->setValue('vetlab_name', $registration['Sample'][0]['Vetlab']['name']);
$document->setValue('lab_market_name', $registration['Lab']['market_name']?$registration['Lab']['market_name']:'');
$document->setValue('lab_market_address', $registration['Lab']['market_address']?$registration['Lab']['market_address']:'');
$document->setValue('lab_phone', $registration['Lab']['phone']?$registration['Lab']['phone']:'');
$document->setValue('job_name', isset($registration['User']['Job']['name'])?$registration['User']['Job']['name']:'');
$document->setValue('user_displayname', $registration['User']['displayname']);
$document->setValue('registration_owner', $registration['Registration']['owner']);
$document->setValue('region_name', $registration['Region']['name']);
$document->setValue('district_name', $registration['District']['name']);
$document->setValue('registration_locality', $registration['Registration']['locality']);
$document->setValue('registration_doc_date', date_format(date_create($registration['Registration']['doc_date']),'d.m.Y'));
$document->setValue('registration_doc_num', $registration['Registration']['doc_num']);
$document->setValue('registration_doc_form', $registration['Registration']['doc_form']);
$document->setValue('production_name', $registration['Sample'][0]['Production']['name']);
$document->setValue('sample_reason', $registration['Sample'][0]['SamplePurpose']['name']);
$document->setValue('sample_purpose_category', $registration['Sample'][0]['SamplePurpose']['category']);
$document->setValue('sample_total_weight', $registration['Sample'][0]['total_weight']);
$document->setValue('sample_count', $registration['Sample'][0]['count']);
$document->setValue('sample_samples_weight', $registration['Sample'][0]['samples_weight']);
$document->setValue('sample_mark', $registration['Sample'][0]['mark']);
$document->setValue('sample_packages', $registration['Sample'][0]['packages']);
$document->setValue('sample_mark_number', $registration['Sample'][0]['mark_number']);
$document->setValue('sample_order_date', date_format(date_create($registration['Lab']['Institution']['Organ']['order_date']),'d.m.Y'));
$document->setValue('sample_order_num', $registration['Lab']['Institution']['Organ']['order_num']);
$document->setValue('sample_order_type', $registration['Lab']['Institution']['Organ']['order_type']);
$document->setValue('sample_date', date_format(date_create($registration['Sample'][0]['mark_number']),'d.m.Y'));
$document->setValue('sample_time', date_format(date_create($registration['Sample'][0]['mark_number']),'H:i'));


$file = 'Направление.docx';
$document->saveAs($file);
header("Content-Description: File Transfer");
header('Content-Disposition: attachment; filename="' . urlencode($file) . '"');
header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
header('Content-Transfer-Encoding: binary');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Expires: 0');
readfile($file);
unlink($file);
} catch (Exception $e)
{
	echo 'Выброшено исключение: ',  $e->getMessage(), "\n";
}
?>