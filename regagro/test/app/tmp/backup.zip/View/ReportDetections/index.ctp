<div class="row">
	<div class="col-md-4">
		<h4>Выявления (отчет)</h4>
	</div>
	<div class="col-md-8">
		<?php echo $this->Form->create('ReportDetection', array(
			'action'=> 'add',
			'inputDefaults' => array(
				'div' => 'form-group',
				'label' => false,
				'wrapInput' => false,
				'class' => 'form-control'
			),
			'class' => 'form-inline text-right'
		)); ?>
				<?php 
				echo $this->Form->input('name', array(
					'placeholder' => 'Название...',
					'div' => 'form-group'
				));?>
				
				<?php 
				echo $this->Form->input('detection_type_id', array(
					'div' => 'form-group'
				));?>
				
				<?php
				echo $this->Form->submit('Добавить', array(
					'div' => 'form-group',
					'class' => 'btn btn-primary'
				));?>
		<?php echo $this->Form->end(); ?>
	</div>
</div>
<?php echo $this->Paginator->pagination(array(
	'ul' => 'pagination pagination-sm'
)); ?>
<table class="table">
	<tr>
		<th>Название</th>
		<th>Вид выявления</th>
		<th>Удалить</th>
	</tr>
	<? 
	foreach ($reportDetections as $reportDetection)
	{
		echo '
		<tr>
			<td>'.$this->Html->link($reportDetection['ReportDetection']['name'], array(
					'action' => 'edit', $reportDetection['ReportDetection']['id'])).'
			</td>
			<td>'.$reportDetection['DetectionType']['name'].'
			</td>
			<td>'.$this->Html->link('<span class="glyphicon glyphicon-remove"></span>', array(
					'action' => 'delete', $reportDetection['ReportDetection']['id']),
					array(
						'escape'=>false
					)).'
			</td>
		</tr>';
	}
	?>
</table>
<?php echo $this->Paginator->pagination(array(
	'ul' => 'pagination pagination-sm'
)); ?>