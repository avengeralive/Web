<div class="row">
	<div class="col-md-4">
		<h4>Продукция (для отчета)</h4>
	</div>
	<div class="col-md-8">
		<?php echo $this->Form->create('ReportProduction', array(
			'action'=> 'add',
			'inputDefaults' => array(
				'div' => 'form-group',
				'label' => false,
				'wrapInput' => false,
				'class' => 'form-control'
			),
			'class' => 'form-inline text-right'
		)); ?>
				<?php 
				echo $this->Form->input('name', array(
					'placeholder' => 'Название...',
					'div' => 'form-group'
				));?>

				<?php 
				echo $this->Form->input('ProductionType', array(
					'div' => 'form-group'
				));?>
				
				<?php
				echo $this->Form->submit('Добавить', array(
					'div' => 'form-group',
					'class' => 'btn btn-primary'
				));?>
		<?php echo $this->Form->end(); ?>
	</div>
</div>
<?php echo $this->Paginator->pagination(array(
	'ul' => 'pagination pagination-sm'
)); ?>
<table class="table">
	<tr>
		<th>Название</th>
		<th>Вид продукции</th>
		<th>Удалить</th>
	</tr>
	<? 
	foreach ($reportProductions as $reportProduction)
	{
		echo '
		<tr>
			<td>'.$this->Html->link($reportProduction['ReportProduction']['name'], array(
					'action' => 'edit', $reportProduction['ReportProduction']['id'])).'
			</td>
			<td>
			'.implode(', ', array_map(function ($entry) {
				  return $entry['name'];
				}, $reportProduction['ProductionType'])).'
			</td>
			<td>'.$this->Html->link('<span class="glyphicon glyphicon-remove"></span>', array(
					'action' => 'delete', $reportProduction['ReportProduction']['id']),
					array(
						'escape'=>false
					)).'
			</td>
		</tr>';
	}
	?>
</table>
<?php echo $this->Paginator->pagination(array(
	'ul' => 'pagination pagination-sm'
)); ?>