<div class="row">
	<div class="col-md-2">
		<h4>Исследования</h4>
	</div>
	<div class="col-md-10">
		<?php echo $this->Form->create('ResearchType', array(
			'action'=> 'add',
			'inputDefaults' => array(
				'div' => 'form-group',
				'label' => false,
				'wrapInput' => false,
				'class' => 'form-control'
			),
			'class' => 'form-inline text-right'
		)); ?>
				<?php 
				echo $this->Form->input('name', array(
					'placeholder' => 'Название...',
					'div' => 'form-group'
				));?>
				<?php 
				echo $this->Form->input('report_research_id', array(
					'div' => 'form-group'
				));
				echo $this->Form->input('ProductionType');?>
				<?php
				echo $this->Form->submit('Добавить', array(
					'div' => 'form-group',
					'class' => 'btn btn-primary'
				));?>
		<?php echo $this->Form->end(); ?>
	</div>
</div>
<?php echo $this->Paginator->pagination(array(
	'ul' => 'pagination pagination-sm'
)); ?>
<table class="table">
	<tr>
		<th>Название</th>
		<th>Отчет</th>
		<th>Виды продукции</th>
		<th>Удалить</th>
	</tr>
	<? 
	foreach ($researchTypes as $researchType)
	{
		echo '
		<tr>
			<td>'.$this->Html->link($researchType['ResearchType']['name'], array(
					'action' => 'edit', $researchType['ResearchType']['id'])).'
			</td>
			<td>'.$researchType['ReportResearch']['name'].'
			</td>
			<td>
			'.implode(', ', array_map(function ($entry) {
				  return $entry['name'];
				}, $researchType['ProductionType'])).'
			</td>
			<td>'.$this->Html->link('<span class="glyphicon glyphicon-remove"></span>', array(
					'action' => 'delete', $researchType['ResearchType']['id']),
					array(
						'escape'=>false
					)).'
			</td>
		</tr>';
	}
	?>
</table>
<?php echo $this->Paginator->pagination(array(
	'ul' => 'pagination pagination-sm'
)); ?>