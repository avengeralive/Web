<div class="row">
	<div class="col-md-3">
		<h4>Цель отбора проб</h4>
	</div>
	<div class="col-md-9">
		<?php echo $this->Form->create('SamplePurpose', array(
			'action'=> 'add',
			'inputDefaults' => array(
				'div' => 'form-group',
				'label' => false,
				'wrapInput' => false,
				'class' => 'form-control'
			),
			'class' => 'form-inline text-right'
		)); ?>
				<?php 
				echo $this->Form->input('name', array(
					'placeholder' => 'Название...',
					'div' => 'form-group',
					'style' => 'width:500px'
				));?>
				
				<?php 
				echo $this->Form->input('category', array(
											'options'=>array('Госуслуга'=>'Госуслуга','Показания'=>'Показания'),
											'default' => 'Показания',
											'div' => 'form-group',
											'style' => 'width:135px'
				));?>
				
				<?php
				echo $this->Form->submit('Добавить', array(
					'div' => 'form-group',
					'class' => 'btn btn-primary'
				));?>
		<?php echo $this->Form->end(); ?>
	</div>
</div>
<?php echo $this->Paginator->pagination(array(
	'ul' => 'pagination pagination-sm'
)); ?>
<table class="table">
	<tr>
		<th>Название</th>
		<th>Категория исследования</th>
	</tr>
	<? 
	foreach ($samplePurposes as $item)
	{
		echo '
		<tr>
			<td>'.$this->Html->link($item['SamplePurpose']['name'], array(
					'action' => 'edit', $item['SamplePurpose']['id'])).'
			</td>
			<td>'.$item['SamplePurpose']['category'].'</td>
			<td>'.$this->Html->link('<span class="glyphicon glyphicon-remove"></span>', array(
					'action' => 'delete', $item['SamplePurpose']['id']),
					array(
						'escape'=>false
					)).'
			</td>
		</tr>';
	}
	?>
</table>
<?php echo $this->Paginator->pagination(array(
	'ul' => 'pagination pagination-sm'
)); ?>