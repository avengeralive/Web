<?php echo $this->Form->create('Sample', array(
	'inputDefaults' => array(
		'div' => 'form-group',
		'wrapInput' => false,
		'class' => 'form-control'
	),
	'class' => 'well'
)); ?>
	<fieldset>
		<legend><?php echo $title_for_layout ?></legend>
		<?php 
		echo $this->Form->input('expertise_id', array('label'=>'Экспертиза'));
		//echo $this->Form->input('production_id', array('label'=>'Продукция ('.$registration['ProductionType']['name'].')'));
		echo $this->Form->input('total_weight', array('label'=>'Вес партии', 'step'=>0.01));
		echo $this->Form->input('vetlab_id', array('label'=>'Проба направляется в'));
		echo $this->Form->input('doc', array('label'=>'Нормативный документ'));
		echo $this->Form->input('count', array('label'=>'Количество проб'));
		echo $this->Form->input('samples_weight', array('label'=>'Вес проб', 'step'=>0.01));
		echo $this->Form->input('packages', array('label'=>'Сейф-пакет'));
		echo $this->Form->input('gloves', array('label'=>'Перчатки одноразовые'));
		echo $this->Form->input('bottles', array('label'=>'Бутылка пластиковая'));
		echo $this->Form->input('containers', array('label'=>'Контейнер пластиковый'));
		echo $this->Form->input('other', array('label'=>'Прочее'));
		echo $this->Form->input('auto', array('label'=>'Пробег в км с указанием марки и г/н автомобиля'));
		echo $this->Form->input('sample_purpose_id', array('label'=>'Цель отбора проб'));
		echo $this->Form->input('mark', array('label'=>'Маркировка'));
		echo $this->Form->input('control_sample', array('label'=>'Хранение контрольной пробы'));
		echo $this->Form->input('package_type', array('label'=>'Вид упаковки'));
		echo $this->Form->input('mark_number', array('label'=>'Номер печати, пломбы'));
		echo $this->Form->submit('Сохранить', array(
			'div' => 'form-group',
			'class' => 'btn btn-default'
		));?>
	</fieldset>
<?php echo $this->Form->end(); ?>

<?php
$this->start('css');?>
<link rel="stylesheet" href="/css/selectize.css">
<link rel="stylesheet" href="/css/selectize.bootstrap3.css">
<?php $this->end(); ?>

<?php
$this->start('script');?>
<script src="/js/selectize.min.js"></script>
<script type="text/javascript">
$(function () {
	$('select').selectize({
		plugins: ['restore_on_backspace'],
		create: false,
		selectOnTab: true,
		onInitialize: function() {this.selected_value = this.getValue();},
		onChange: function(value) {value=value==0?this.selected_value:value;this.selected_value=value;},
		onDropdownClose: function($dropdown) { 
			if(this.getValue()==0) {
				this.setValue(this.selected_value ); 
			}
		}
	});
});
</script>

<?php $this->end(); ?>