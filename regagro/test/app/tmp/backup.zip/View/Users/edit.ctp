<?php echo $this->Form->create('User', array(
	'inputDefaults' => array(
		'div' => 'form-group',
		'wrapInput' => false,
		'class' => 'form-control'
	),
	'class' => 'well'
)); ?>
	<fieldset>
		<legend>Добавление нового пользователя</legend>
		<?php 
		echo $this->Form->input('username', array(
			'label' => 'Имя пользователя',
			'placeholder' => 'Имя для авторизации в системе...'
		));
		echo $this->Form->input('changepass', array(
			'id' => 'changePass',
			'type' => 'checkbox',
			'label' => 'Поменять пароль',
			'default' => true,
			'class' => false
		));
		echo $this->Form->input('password', array(
			'label' => 'Пароль',
			'placeholder' => 'Не меньше 6 символов...'
		));
		echo $this->Form->input('password_confirm', array(
			'label' => 'Проверка пароля',
			'type'=> 'password',
			'placeholder' => 'Повторите пароль для проверки...'
		));
		echo $this->Form->input('displayname', array(
			'label' => 'ФИО',
			'placeholder' => 'Полное ФИО...'
		));
		echo $this->Form->input('lab_id', array(
			'label' => 'Лаборатория',
			'empty' => array(0 => '-не указано-')
		));
		echo $this->Form->input('institution_id', array(
			'label' => 'Учреждение ветеринарии',
			'empty' => array(0 => '-не указано-')
		));
		echo $this->Form->input('organ_id', array(
			'label' => 'Орган управления ветеринарии',
			'empty' => array(0 => '-не указано-')
		));
		echo $this->Form->input('job_id', array(
			'label' => 'Должность',
			'empty' => array(0 => '-не указано-')
		));
		echo $this->Form->input('role', array(
			'label' => 'Роль',
			'options' => array('Администратор'=>'Администратор', 
							   'Сотрудник'=>'Сотрудник'), 
			'default' => 'Сотрудник'
		));
		echo $this->Form->submit('Сохранить', array(
			'div' => 'form-group',
			'class' => 'btn btn-default'
		)); 
		?>
	</fieldset>
<?php echo $this->Form->end(); 
$this->start('script');?>
<script type="text/javascript">
$('#changePass').click(function() {
	$("[name*='password']").each(function(){
		this.disabled = !this.disabled;
	});
})
$('#changePass').click();
</script>
<?php $this->end(); ?>