<div class="row">
	<div class="col-md-12">
		<?php echo $this->Form->create('User', array(
			'inputDefaults' => array(
				'div' => 'form-group',
				'wrapInput' => false,
				'label' => false,
				'class' => 'form-control'
			),
			'class' => 'form-inline text-right'
		)); ?>
		<?php echo $this->Paginator->pagination(array(
			'ul' => 'pagination pagination-sm'
		)); ?>
		
		<?php 
			echo $this->Form->input('displayname', array(
				'placeholder' => 'Имя...',
				'div' => 'form-group',
				'required'=>false
			));
		?>
		
		<?php
		echo $this->Form->submit('Поиск', array(
			'div' => 'form-group',
			'class' => 'btn btn-primary'
		));?>
		<?php echo $this->Form->end(); ?>
	</div>
</div>
<table class="table">
	<tr>
		<th>Имя</th>
		<th>Логин</th>
		<th>Роль</th>
		<th>Должность</th>
		<th>Лаборатория</th>
		<th>Учреждение</th>
		<th>Орган управления</th>
		<th>Удалить</th>
	</tr>
	<? 
	foreach ($users as $user)
	{
		echo '
		<tr>
			<td>'.$this->Html->link($user['User']['displayname'], array('controller' => 'users',
					'action' => 'edit', $user['User']['id'])).'
			</td>
			<td>'.$user['User']['username'].'</td>
			<td>'.$user['User']['role'].'</td>
			<td>'.$user['Job']['name'].'</td>
			<td>'.$user['Lab']['name'].'</td>
			<td>'.$user['Institution']['name'].'</td>
			<td>'.$user['Organ']['name'].'</td>
			<td>'.$this->Html->link('<span class="glyphicon glyphicon-remove"></span>', array('controller' => 'users',
					'action' => 'delete', $user['User']['id']),
					array(
						'escape'=>false
					)).'
			</td>
		</tr>';
	}
	?>
</table>
<?php echo $this->Paginator->pagination(array(
	'ul' => 'pagination pagination-sm'
)); ?>