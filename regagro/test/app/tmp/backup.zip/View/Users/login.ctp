<div class="row">
	<div class="col-md-6 col-md-offset-3">
<?php echo $this->Form->create('User', array(
	'inputDefaults' => array(
		'div' => 'form-group',
		'wrapInput' => false,
		'class' => 'form-control'
	),
	'class' => 'well'
)); ?>
	<fieldset>
		<legend>Вход в систему</legend>
		<?php 
		echo $this->Form->input('username', array(
			'label' => 'Имя пользователя',
			
			'placeholder' => 'логин...'
		));
		echo $this->Form->input('password', array(
			'label' => 'Пароль',
			'placeholder' => 'пароль...'
		));
		echo $this->Form->submit('Войти', array(
			'div' => 'form-group',
			'class' => 'btn btn-default'
		)); 
		?>
	</fieldset>
<?php echo $this->Form->end(); ?>
	</div>
</div>