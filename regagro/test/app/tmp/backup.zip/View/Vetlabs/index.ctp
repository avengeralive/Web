<div class="row">
	<div class="col-md-3">
		<h4>Ветеринарные лаборатории</h4>
	</div>
	<div class="col-md-9">
		<?php echo $this->Form->create('Vetlab', array(
			'action'=> 'add',
			'inputDefaults' => array(
				'div' => 'form-group',
				'label' => false,
				'wrapInput' => false,
				'class' => 'form-control'
			),
			'class' => 'form-inline text-right'
		)); ?>
				<?php 
				echo $this->Form->input('name', array(
					'placeholder' => 'Название...',
					'div' => 'form-group',
					'style' => 'width:635px'
				));?>
				
				<?php 
				echo $this->Form->input('organ_id', array(
					'div' => 'form-group'
				));?>
				
				<?php
				echo $this->Form->submit('Добавить', array(
					'div' => 'form-group',
					'class' => 'btn btn-primary'
				));?>
		<?php echo $this->Form->end(); ?>
	</div>
</div>
<?php echo $this->Paginator->pagination(array(
	'ul' => 'pagination pagination-sm'
)); ?>
<table class="table">
	<tr>
		<th>Название</th>
		<th>Орган управления</th>
		<th>Удалить</th>
	</tr>
	<? 
	foreach ($vetlabs as $vetlab)
	{
		echo '
		<tr>
			<td>'.$this->Html->link($vetlab['Vetlab']['name'], array(
					'action' => 'edit', $vetlab['Vetlab']['id'])).'
			</td>
			<td>'.$vetlab['Organ']['name'].'</td>
			<td>'.$this->Html->link('<span class="glyphicon glyphicon-remove"></span>', array(
					'action' => 'delete', $vetlab['Vetlab']['id']),
					array(
						'escape'=>false
					)).'
			</td>
		</tr>';
	}
	?>
</table>
<?php echo $this->Paginator->pagination(array(
	'ul' => 'pagination pagination-sm'
)); ?>