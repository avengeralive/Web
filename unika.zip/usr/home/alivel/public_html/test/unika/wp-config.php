<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'hostingdata');

/** MySQL database username */
define('DB_USER', 'hostingdata');

/** MySQL database password */
define('DB_PASSWORD', 'gDdRtUh9Tf3eRBiz');

/** MySQL hostname */
define('DB_HOST', 'sql439.your-server.de');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'JJ<S||?Kw!5pHVHPW|Wc:Gq)#c)IKt{VT)m?I:bEl94se],aJxQr+YaP;q&MBu!C');
define('SECURE_AUTH_KEY',  '5FA][y*}YHp37q+vdG_uU(hB$<sAP1*Q7R}zXZ!D-4+t[<^l?Qf9Oqfd_{ythA4x');
define('LOGGED_IN_KEY',    'nx=i`PzLE^v).O>H@ToUe#fcKqL%SI>9P{gH#eWiH(=~<z=ZI%M+<D7nv3:e^3kY');
define('NONCE_KEY',        'u1(`wtehUCK[4Vh?!8p#McJ8-d>JuoIy6# $_|-ag-u-P2yFdAJKDO+O5=%M@}ZE');
define('AUTH_SALT',        '$6Aj*5cD>|i_e+o.#<Pi8@pd}>S,HXLmWFdlom]y&8b<.m`dZQ!-bR+^XwxCE_Ih');
define('SECURE_AUTH_SALT', 'd7<>zix;1KoT87fnBs!M7&{nl-^c9U5ob2R6{z~gl:p<1*6pl NGN46w6ers0eo,');
define('LOGGED_IN_SALT',   'H[#-?j3($13Y,t|K;L3LoLJ?nZew0GwsO}4[vb:WEwm}0zo3_(t5,bx)<Md``wrD');
define('NONCE_SALT',       'vAF>1#I1|b?L09IyG3?t&6I7T^i)(js*p>a&TqDuiynZsqM5sm6@;OI2?$u8b/@(');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'un_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
