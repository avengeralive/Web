$(document).ready(function(){
    $(".owl-carousel").owlCarousel({
        items: 4,
        dots: true,
        loop: true,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            768: {
                items: 3
            },
            1024: {
                items: 4
            }
        }
    });
    $('.burger').on('click', function(){
        $('body').addClass('menu-active');
    });
    $('.menu-close').on('click', function(){
        $('body').removeClass('menu-active');
    });
});