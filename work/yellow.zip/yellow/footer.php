		<footer>
			<div class="container">
				<div class="row big">
					<div class="col-md-4 col-lg-4">
						<img src="<? echo get_template_directory_uri(); ?>/assets/img/YCIcon.svg">
					</div>
					<div class="col-md-4 col-lg-2 yc_menu">
						<p>Yellow Connection</p>
						<ul>
							<li><a href="#">Team</a></li>
							<li><a href="#">Contacts</a></li>
							<li><a href="#">Documents</a></li>
						</ul>
					</div>
					<div class="col-md-4 col-lg-2 company_menu">
						<p>Company</p>
						<ul>
							<li><a href="#">About</a></li>
							<li><a href="#">Services</a></li>
							<li><a href="#">Testimonials</a></li>
							<li><a href="#">Projects</a></li>
							<li><a href="#">Blog</a></li>
						</ul>
					</div>
					<div class="col-lg-4">
						<p>Yellow Connection is a 360° digital branding and marketing agency which provides a wide spectrum of internet marketing services to enhance the online presence of all kinds of businesses. We offer global solutions of digital marketing and communication through classifieds, web portals, social media networks, advertising channels and search engines.</p>
					</div>
				</div>
			</div>
			<section class="copy">
				<div class="container">
					<div class="row">
						<div class="col-lg-6 copy_menu">
							<ul>
								<li>&copy; 2019 Yellow Connection</li>
								<li><a href="">Terms & Conditions</a></li>
								<li><a href="">Privacy Policy</a></li>
							</ul>
						</div>
						<div class="col-lg-6 social_menu">
							<ul>
								<li><a href=""><img src="<? echo get_template_directory_uri(); ?>/assets/img/facebook.svg"></a></li>
								<li><a href=""><img src="<? echo get_template_directory_uri(); ?>/assets/img/twitter.svg"></a></li>
								<li><a href=""><img src="<? echo get_template_directory_uri(); ?>/assets/img/linkedin.svg"></a></li>
								<li><a href=""><img src="<? echo get_template_directory_uri(); ?>/assets/img/instagram.svg"></a></li>
							</ul>
						</div>
					</div>
				</div>
			</section>
		</footer>
		<script src="<? echo get_template_directory_uri(); ?>/assets/js/script.js"></script>
		<script src="<? echo get_template_directory_uri(); ?>/assets/js/bootstrap.min.js"></script>
		<? wp_footer(); ?>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5d0ab6a536eab9721118475a/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
	</body>
</html>