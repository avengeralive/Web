<? get_header(); ?>
		<main>
			<div class="container">
				<div class="row">
					<div class="col-lg-1">
					</div>
					<div class="col-lg-8">
						<h1 class="wow fadeInLeft">Yellow <span>Connection</span></h1>
						<h2 class="wow fadeInDown">Website design and Digital marketing agency</h2>
					</div>
					<div class="col-lg-3">
						<div class="sq_box">
							<div class="sq1 wow fadeInRightBig"></div>
							<div class="sq2 wow fadeInDownBig"></div>
							<div class="sq3 wow fadeInUpBig"></div>
						</div>
					</div>
				</div>
			</div>
		</main>
		<section>
			<div class="container">
				<div class="row bg-1">
					<div class="col-lg-1 bg-y">
					</div>
					<div class="col-md-6 col-lg-5 square wow fadeIn">
					</div>
					<div class="col-md-6 col-lg-5 bg-y block-text wow fadeIn">
						<h2>Explore with us</h2>
						<p>Business results are what matter, and that's exactly what we will deliver by connecting you to your potential customers.</p>
					</div>
					<div class="col-lg-1 bg-y">
					</div>
				</div>
				<div class="row bg-2">
					<div class="col-lg-1 bg-y">
					</div>
					<div class="col-md-6 col-lg-5 bg-y block-text wow fadeIn">
						<h2>Make your business a ‘Brand’</h2>
						<p>We help making your business grow within the digital space, be it website development, brand development using strategies like content marketing, social media marketing, email marketing and many more.</p>
					</div>
					<div class="col-md-6 col-lg-5 square wow fadeIn">
					</div>
					<div class="col-lg-1 bg-y">
					</div>
				</div>
			</div>
		</section>
		<section class="projects">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 text-center">
						<h2>Our projects build<br>the better world for connection</h2>
					</div>
				</div>
				<div class="row">
					<div class="col-md-4 col-lg-4">
						<div class="project_block">
							<img src="<? echo get_template_directory_uri(); ?>/assets/img/1.jpg">
							<h3>Project one</h3>
							<p>Solacexis Solicitors was looking to improve communication between the company and its clients. We helped them develop a portal, where clients...</p>
							<a href="#" class="more"><img src="<? echo get_template_directory_uri(); ?>/assets/icon/arrow-right-lite.svg"></a>
						</div>
					</div>
					<div class="col-md-4 col-lg-4">
						<div class="project_block">
							<img src="<? echo get_template_directory_uri(); ?>/assets/img/2.jpg">
							<h3>Project two</h3>
							<p>CH, a company that manufactures smart home accessories – lights, switches, and more – needed to improve their existing solution... </p>
							<a href="#" class="more"><img src="<? echo get_template_directory_uri(); ?>/assets/icon/arrow-right-lite.svg"></a>
						</div>
					</div>
					<div class="col-md-4 col-lg-4">
						<div class="project_block">
							<img src="<? echo get_template_directory_uri(); ?>/assets/img/3.jpg">
							<h3>Project three</h3>
							<p>CD, a start up business working in the fresh food industry wishes to reach their targeted customers for the niche product they are selling. We worked with them to….</p>
							<a href="#" class="more"><img src="<? echo get_template_directory_uri(); ?>/assets/icon/arrow-right-lite.svg"></a>
						</div>
					</div>
					<div class="col-lg-12 text-center">
						<a href="" class="projects_all">See all projects</a>
					</div>
				</div>
			</div>
		</section>
		<section class="testimonials">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 text-center">
						<h2>Testimonials</h2>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12">
						<div class="testimonials_slider">
						  	<div class="testimonials_slider_container">
						  		<div class="testimonials_slider_container_inner">
							  		<img src="<? echo get_template_directory_uri(); ?>/assets/img/left-quote.png">
							  		<p>Everything was very cool! Dealing with these guys is a pleasure. They are professionals and this means only one thing to me – I can see new leads coming every day.</p>
							  		<time>11 april, 2019</time>
						  		</div>
						  		<div class="testimonials_slider_container_image">
						  			<table>
						  				<tr>
						  					<td><img src="<? echo get_template_directory_uri(); ?>/assets/img/author.jpg"></td>
						  					<td>Kylee, Manchester</td>
						  				</tr>
						  			</table>
						  		</div>
						  	</div>
						  	<div class="testimonials_slider_container">
						  		<div class="testimonials_slider_container_inner">
							  		<img src="<? echo get_template_directory_uri(); ?>/assets/img/left-quote.png">
							  		<p>Everything was very cool! Dealing with these guys is a pleasure. They are professionals and this means only one thing - further close cooperation.</p>
							  		<time>11 april, 2019</time>
						  		</div>
						  		<div class="testimonials_slider_container_image">
						  			<table>
						  				<tr>
						  					<td><img src="<? echo get_template_directory_uri(); ?>/assets/img/author.jpg"></td>
						  					<td>Kylee</td>
						  				</tr>
						  			</table>
						  		</div>
						  	</div>
						</div>
					</div>
					<div class="col-lg-12 text-right">
						<div class="testimonials_all">
							<a href="">See all testimonialss</a>
						</div>
					</div>
				</div>
			</div>
		</section>
		<section class="why">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 text-center">
						<h2>Why choose us</h2>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-1"></div>
					<div class="col-md-4 col-lg-3 text-center">
						<img src="<? echo get_template_directory_uri(); ?>/assets/img/Fast.png">
						<p>Fast</p>
					</div>
					<div class="col-md-4 col-lg-4 text-center">
						<img src="<? echo get_template_directory_uri(); ?>/assets/img/Swag.png">
						<p>Simple</p>
					</div>
					<div class="col-md-4 col-lg-3 text-center">
						<img src="<? echo get_template_directory_uri(); ?>/assets/img/Simple.png">
						<p>Reliable</p>
					</div>
					<div class="col-lg-1"></div>
				</div>
			</div>
		</section>
		<section class="bc">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 text-center">
						<h2>Build connection</h2>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-3"></div>
					<div class="col-lg-6 text-center">
						<p>We understand what it's like to go from a small company to a big business, so we can give advice on how to get the best results from digital marketing, no matter what your budget is. We also help providing custom teams or technical resources to scale your business with software development, design, and digital marketing capabilities.</p>
						<form>
							<input type="text" placeholder="Email or phone">
							<button>Contact us</button>
						</form>
					</div>
					<div class="col-lg-3 text-center">
					</div>
				</div>
			</div>
		</section>
<? get_footer(); ?>