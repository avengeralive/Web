<!DOCTYPE html>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="<? echo get_template_directory_uri(); ?>/assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="<? echo get_template_directory_uri(); ?>/assets/css/animate.css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
		<link rel="stylesheet" type="text/css" href="<? echo get_template_directory_uri(); ?>/assets/slick/slick.css"/>
		<link rel="stylesheet" type="text/css" href="<? echo get_template_directory_uri(); ?>/assets/slick/slick-theme.css"/>
		<link rel="stylesheet" href="<? echo get_template_directory_uri(); ?>/assets/css/style.css">
		<? wp_head(); ?>
	</head>
	<body>
		<header>
			<div class="container">
				<div class="row">
					<div class="col-6 col-lg-2">
						<a href="/">
							<img src="<? echo get_template_directory_uri(); ?>/assets/img/logo.svg" class="logo wow fadeIn" alt="Yellow Connection LTD">
						</a>
					</div>
					<div class="col-6 col-lg-10 menublock">
						<button class="openmenu"><i class="fas fa-bars"></i></button>
						<div class="menu_div">
							<a href="/">
								<img src="<? echo get_template_directory_uri(); ?>/assets/img/logo.svg" class="logo" alt="Yellow Connection LTD">
							</a>
							<button class="closemenu"><i class="fas fa-times"></i></button>
							<ul class="menu">
								<? $menu = wp_get_nav_menu_items('Menu'); ?>
				                <? foreach ($menu as $elem) { $x = 0.1; ?>
				                <li><a class="wow fadeIn" data-wow-delay="<? echo $x; $x += 0.15; ?>s" href="<? echo $elem->url; ?>"><? echo $elem->title; ?></a></li>
				                <? } ?>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="yellow-label"><div class="inners"></div></div>
		</header>