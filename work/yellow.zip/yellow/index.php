<? get_header(); ?>
<section id="blog_heading">
	<div class="container">
		<div class="row">
			<div class="col-12 text-center">
				<img src="<? echo get_template_directory_uri(); ?>/assets/img/YCIcon.svg">
				<h1>Yellow Connection’s Blog</h1>
				<p>The most interesting and useful materials from experts of the digital market</p>
			</div>
		</div>
	</div>
</section>
<section id="blog_list">
	<div class="container">
		<div class="row">
			<? while (have_posts()) { the_post(); ?>
			<div class="col-12 col-md-6">
				<div class="blog-item">
					<div class="img_div">
						<img src="<? echo get_the_post_thumbnail_url(get_the_ID(), 'full'); ?>">
					</div>
					<div class="row">
						<div class="col-6 category">
							<a href="<? echo get_category_link(get_the_category(get_the_ID())[0]->term_id); ?>"><? echo get_the_category(get_the_ID())[0]->name; ?></a>
						</div>
						<div class="col-6 date">
							<time><? the_date(); ?></time>
						</div>
						<div class="col-12">
							<h2><a href="<? the_permalink(); ?>"><? the_title(); ?></a></h2>
							<p><? echo get_field('excerpt', get_the_ID()); ?></p>
							<span class="created">by <a href="#">Christian Bason</a></span>
						</div>
					</div>

				</div>
			</div>
			<? } ?>
		</div>
	</div>
</section>
<? get_footer(); ?>