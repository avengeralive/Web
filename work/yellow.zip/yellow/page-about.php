<? 
/*
Template name: About
*/
get_header(); the_post();  ?>
<section id="about">
	<div class="container">
		<div class="row">
			<div class="col-12 text-left">
				<h1>About us</h1>
				<? the_content(); ?>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<hr class="del">
			</div>
		</div>
		<div class="row">
			<div class="col-12 text-left">
				<h2>Team</h2>
			</div>
			<? $team = get_field('team', get_the_ID()); 
			foreach ($team as $item) { ?>
			<div class="col-md-6 col-lg-3 teamitem">
				<img src="<? echo $item['photo']; ?>">
				<h3><? echo $item['name']; ?></h3>
				<p><? echo $item['profession']; ?></p>
			</div>
			<? } ?>
		</div>
		<div class="row">
			<div class="col-12">
				<hr class="del">
			</div>
		</div>
	</div>
</section>
<? get_footer(); ?>