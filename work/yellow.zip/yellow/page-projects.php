<? 
/*
Template name: Projects
*/
get_header(); the_post();  ?>
<section id="projects_heading">
	<div class="container">
		<div class="row">
			<div class="col-lg-3"></div>
			<div class="col-lg-6 text-center">
				<h1>Recent projects</h1>
				<hr class="smallhr">
				<p>We create technology solutions for startups, small and medium-sized businesses, and enterprises.</p>
			</div>
			<div class="col-lg-3"></div>
		</div>
	</div>
</section>
<section id="projects">
	<div class="container">
		<div class="row">
			<div class="col-12 project">
				<div class="row">
					<div class="col-md-6">
						<div class="projimg">
							
						</div>
					</div>
					<div class="col-md-6">
						<h2>Project one</h2>
						<h3>An app for the global environmental event against waste</h3>
						<p>Company was looking to improve communication
between the company and its clients. We helped
Company design and develop a mobile portal where
clients can contact consultants or request a callback
from a particular specialist in real time, depending on
the nature of their question.</p>
						<a href="#" class="projmore">More about project</a>
						<hr class="borderedhr">
					</div>
				</div>
			</div>
			<div class="col-12 project">
				<div class="row">
					<div class="col-md-6">
						<h2>Project one</h2>
						<h3>An app for the global environmental event against waste</h3>
						<p>Company was looking to improve communication
between the company and its clients. We helped
Company design and develop a mobile portal where
clients can contact consultants or request a callback
from a particular specialist in real time, depending on
the nature of their question.</p>
						<a href="#" class="projmore">More about project</a>
						<hr class="borderedhr">
					</div>
					<div class="col-md-6">
						<div class="projimg">
							
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<? get_footer(); ?>