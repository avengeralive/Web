<? 
/*
Template name: Testimonials
*/
get_header(); the_post();  ?>
<section id="testimonials_heading">
	<div class="container">
		<div class="row">
			<div class="col-12 text-center">
				<img src="<? echo get_template_directory_uri(); ?>/assets/img/YCIcon.svg">
				<h1>Testimonials</h1>
			</div>
		</div>
	</div>
</section>
<section id="testimonials">
	<div class="container">
		<div class="row">
			<? $testimonials = get_field('testimonials', get_the_ID()); 
			foreach ($testimonials as $item) { ?>
			<div class="col-md-6 testimonial">
				<div class="text">
					<img src="<? echo get_template_directory_uri(); ?>/assets/icon/left-quote.svg" class="nhov">
					<img src="<? echo get_template_directory_uri(); ?>/assets/icon/left-quote_formed.svg" class="hov">
					<? echo $item['testimonial']; ?>
				</div>
				<a href="<? echo $item['link']; ?>"><? echo $item['name']; ?></a>
			</div>
			<? } ?>
		</div>
		<div class="row">
			<div class="col-lg-3"></div>
			<div class="col-lg-6">
				<div class="row">
					<div class="col-12">
						<hr class="del">
					</div>
					<div class="col-12 text-center info">
						<h3>Want to share your emotions with world?</h3>
						<p>We’d love to hear more about successful work connections that have
formed via Yellow Connection. Feel free to contact us here
at online headquarters.</p>
					</div>
				</div>
			</div>
			<div class="col-lg-3"></div>
		</div>
	</div>
</section>
<? get_footer(); ?>