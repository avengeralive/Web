<? 
/*
Template name: Services Item
*/
get_header(); the_post();  ?>
		<section id="services_item_1">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<h1 class="text-center"><? the_title(); ?></h1>
						<? the_content(); ?>
						<? $competences = get_field('competences', get_the_ID()); 
						if (count($competences) != 0) {
						?>
						<!--<h2 class="text-center">Competences</h2>
						<ul>
							<? foreach ($competences as $item) { ?>
							<li><? echo $item['item']; ?></li>
							<? } ?>
						</ul>-->
						<? } ?>
					</div>
					<div class="col-12">
						<button class="contact-us">Contact us</button>
					</div>
				</div>
			</div>
		</section>
<? get_footer(); ?>