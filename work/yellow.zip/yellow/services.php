<? 
/*
Template name: Services
*/
get_header(); the_post();  ?>
		<section id="services_1">
			<div class="container">
				<div class="row">
					<div class="col-lg-2"></div>
					<div class="col-lg-8 text-center">
						<h1>The best service suite</h1>
						<p>We offer a full range of didgital services. We have all the
expertise you need to produce a fully fledged, stable,
and scalable product, for marketing research. </p>
					</div>
					<div class="col-lg-2"></div>
				</div>
			</div>
		</section>
		<section id="services_2">
			<div class="container">
				<div class="row">
					<? $services = get_field('servicces', get_the_ID()); 
					foreach ($services as $key => $service) { ?>
					<div class="col-12 col-sm-6 col-md-6 service_block">
						<a href="<? echo $service['link']; ?>">
							<div>
								<img src="<? echo get_template_directory_uri(); ?>/assets/icon/si<? echo $key+1; ?>.svg">
								<p><? echo $service['title']; ?></p>
							</div>
						</a>
					</div>
					<? } ?>
				</div>
			</div>
		</section>
		<section id="services_3">
			<div class="container">
				<div class="row">
					<div class="col-lg-2"></div>
					<div class="col-lg-8 text-center">
						<h2>How we work</h2>
						<p>At Yellow Connection, we build strong relationships with our clients by
doing three things: being accountable for our projects, making our
processes transparent, and delivering excellent results.</p>
					</div>
					<div class="col-lg-2"></div>
					<div class="col-lg-12 progress_line">
						<div class="row">
							<div class="col-lg-4">
								<p>Flexible methodologies</p>
							</div>
							<div class="col-lg-4">
								<p>Regular communications</p>
							</div>
							<div class="col-lg-4">
								<p>Great result</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<section id="services_4">
			<div class="container">
				<div class="row">
					<div class="col-lg-2"></div>
					<div class="col-lg-8 text-center">
						<h2>Got a project in mind?</h2>
						<p>Tell us about the idea for your project and, together, we can develop
the perfect solution for your business.</p>
					</div>
					<div class="col-lg-2"></div>
				</div>
			</div>
		</section>
<? get_footer(); ?>