<? get_header(); the_post(); ?>
<section id="post">
	<div class="container">
		<div class="row">
			<div class="col-lg-1"></div>
			<div class="col-lg-5 post-heading">
				<a href="<? echo get_category_link(get_the_category(get_the_ID())[0]->term_id); ?>" class="category_link"><? echo get_the_category(get_the_ID())[0]->name; ?></a>
				<h1><? the_title(); ?></h1>
				<p class="exceprt"><? echo get_field('excerpt', get_the_ID()); ?></p>
			</div>
			<div class="col-lg-5">
				<div class="img_div">
					<img src="<? echo get_the_post_thumbnail_url(get_the_ID(), 'full'); ?>">
					<p class="imagecredit">Image credit: <span>Patric leger</span></p>
				</div>
			</div>
			<div class="col-lg-1"></div>
		</div>
		<div class="row post-line2">
			<div class="col-lg-1"></div>
			<div class="col-lg-10">
				<p class="author">
					<img src="<? echo get_template_directory_uri(); ?>/assets/img/YCIcon.svg" class="icon">
					by <a href="#">Christian Bason</a>, <time><? the_date(); ?></time>
				</p>
				<hr class="del">
			</div>
			<div class="col-lg-1"></div>
		</div>
		<div class="row">
			<div class="col-lg-1"></div>
			<div class="col-lg-10 post-content">
				<? the_content(); ?>
			</div>
			<div class="col-lg-1"></div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<hr class="del">
			</div>
		</div>
	</div>
</section>
<section id="related-posts">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<h2><b>Keep reading:</b> Related collaboration topics</h2>
			</div>
			<? $posts = get_posts(array('post_type' => 'post', 'numberposts' => 3)); 
			foreach ($posts as $post) {
			?>
			<div class="col-md-4 related">
				<a href="<? echo get_category_link(get_the_category($post->ID)); ?>" class="category_link"><? echo get_the_category($post->ID)[0]->name; ?></a>
				<h3><? echo $post->post_title; ?></h3>
				<p><? echo get_field('excerpt', $post->ID); ?></p>
				<span class="created">by <a href="#">Christian Bason</a></span>
				<p class="sharep"><a class="share"><img src="<? echo get_template_directory_uri(); ?>/assets/icon/share.svg"> Share</a></p>
			</div>
			<?
			}
			?>
		</div>
		<div class="row">
			<div class="col-12 text-center moreblock">
				<a class="morelink" href="#"><img src="<? echo get_template_directory_uri(); ?>/assets/icon/chevron-down.svg"> More related topics</a>
			</div>
		</div>
	</div>
</section>
<? get_footer(); ?>