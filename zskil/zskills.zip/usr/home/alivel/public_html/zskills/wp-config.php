<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('DB_NAME', 'libera');

/** Имя пользователя MySQL */
define('DB_USER', 'libera');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', 'gAh3fiF8AN6HsCYY');

/** Имя сервера MySQL */
define('DB_HOST', 'sql514.your-server.de');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8mb4');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ',rC~XP#r0:}2T3:zi>lcTuK{!DRrx#gca:twW4Luy_R[e.W4s0~ZitT-a5p_xOOu');
define('SECURE_AUTH_KEY',  'y>`OZE`l2Fd5k1 TPposd@sk`PEW]01,p(R]NNBfi9+_6(l<l+ FLgMw%0XMYUrL');
define('LOGGED_IN_KEY',    'OkpPT3v/tJxbK^C#}t`H}Kjh+^e7t_J^v;bn*2q<(UQZ ;|+Y3i|P5u]ptl[R@YB');
define('NONCE_KEY',        'k_0Dk$h@jLlgP<a?&NMWK)S.Ma3C4PaQhzLn,XVf<|8=,wC(B<nYK[{H=Piq`:zn');
define('AUTH_SALT',        'MN{h_5vIU49`sZAn.KmG<CjO!<QiRx`-K8Sq0@,P *Y~*oqc=*(x8tU2De6{f;fA');
define('SECURE_AUTH_SALT', '%5)*t.CY/.bH7D>$j6.]cev?%C8CQnA&a~?$VxV3lj}r_(vXBgBn@]]krgs 6@g|');
define('LOGGED_IN_SALT',   'cRzd`uw28woH$ QT?wy&-8Cx{P7m8CKMIw0mwh*#ES12PskbGl;F{^;#Qiq&9)0e');
define('NONCE_SALT',       'cwS#gN<2tz.<2#o]);F9([o k=vQB^hP=R3m=ws#9Z8EgW/{#Tq;XZl^XEL]MFQ%');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
